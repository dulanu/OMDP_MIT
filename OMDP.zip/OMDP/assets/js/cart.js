 $('.add_cart').click(function(){
  	var med_item_id = $(this).data("productid");
  	var med_item_name = $(this).data("productname");
  	var med_unit_price = $(this).data("price");
   // var med_unit_image = $(this).data("price");
   var quantity = $('#' + med_item_id).val();

   if(quantity != '' && quantity > 0)
   {
   	$.ajax({
   		url:"<?php echo base_url(); ?>shop_controller/add_to_cart",
   		method:"POST",
   		data:{med_item_id:med_item_id, med_item_name:med_item_name, med_unit_price:med_unit_price, quantity:quantity},
   		success:function(data)
   		{
   			alert("Product Added into Cart");
   			$('#cart_details').html(data);
   			$('#' + med_item_id).val('');
   		}
   	});
   }else{
   	alert("Please enter quantity!");
   }


});

// loac cart 
$('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_cart");