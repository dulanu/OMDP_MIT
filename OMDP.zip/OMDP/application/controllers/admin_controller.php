  <?php
  defined('BASEPATH') OR exit('No direct script access allowed');

  class admin_controller extends CI_Controller {  

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *    http://example.com/index.php/welcome
     *  - or -
     *    http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */



    function __construct()
    {
      parent::__construct();
      $this->load->helper('url');
    }

    public function  login()
    {
      $this->load->view('admin_login');
    }


    public function  test()
    {
     $this->load->view('new_test');
   }


// update session table after logout
   public function logout()
   {
     $this->load->model('user_model');
     $sessionId=$this->uri->segment(3);
     $userId=$this->uri->segment(4);
     $logoutTime= date('Y-m-d H:i:s');
     if($this->user_model->completeLogOut($sessionId,$userId,$logoutTime)){
      $this->session->set_flashdata('msg','Sucessfully Logged Out of OMDP!');
      return redirect('admin_controller/login');
    }else
    {
      echo "Failed to Logout!";
    }
  }


// upload function
  public function uploadPic($profile){
     // $config['upload_path']          = base_url('uploads/');
    $config['upload_path']          = './uploads/';
    $config['allowed_types']        = 'gif|jpg|png|jppeg';
    $config['max_size']             = 200;
    $config['max_width']            = 200;
    $config['max_height']           = 200;

    $this->load->library('upload', $config);
    $this->upload->initialize($config);

    if ($this->upload->do_upload($profile))
    {
      $info=$this->upload->data();
      $path=base_url("uploads/".$info['file_name']);
    }
    else
    {
      // $path=base_url('uploads/null.jpg');
      $path = $this->upload->display_errors();
      
    }
    return $path;
  }


// Pharmacy upload path





  public function main_inner_content_admin()
  {
   $this->load->view('main_inner');
 }

// Load Pharmacy Registration in Admin Home
 public function pharm_reg()
 {

  $this->load->view('pharm_registration');
}


// Load Edit Pharmacy  in Admin Home
public function pharm_edit()
{

  $this->load->view('update_pharm');
}


  // Load Delet Pharmacy  in Admin Home
public function del_pharm()
{

  $this->load->view('pharm_del');
}

// Load user regsitration in Admin Home
public function user_reg()
{

  $this->load->view('user_reg');
}

// Load Edit user in Admin Home
public function user_edit()
{

  $this->load->view('update_user');
}


  // Load Delete user in Admin Home
public function user_del()
{

  $this->load->view('del_user');
}

// Load Admin Register Form
public function registration()
{
  $this->load->view('admin_registration');
}


public function open_close(){
  $pharm_id=$this->uri->segment(3);
  $this->load->model('admin_model');
  $data['query']=$this->admin_model->view_pharm_profile($pharm_id);
  $this->load->view('open_close',$data);

}

// Register Any User
public function register_validator()

{
  $this->form_validation->set_rules('fname','First Name','required');
  $this->form_validation->set_rules('lname','Last Name','required');
  $this->form_validation->set_rules('email','Email','required|valid_email');
  $this->form_validation->set_rules('mobile','Mobile','required');
  $this->form_validation->set_rules('nic','Valid NIC','required');

  if ($this->form_validation->run() )
  {
      // $data=$this->input->post();
    $encrypted_password=md5($this->input->post('password'));
      // unset($data['submit']);
    $this->load->model('user_model');
    $data = array(
      'fName'  => $this->input->post('fname'),
      'lName'  => $this->input->post('lname'),
      'userEmail'  => $this->input->post('email'),
      'userMobile'  => $this->input->post('mobile'),
      'userNIC'  => $this->input->post('nic'),
      'password' => $encrypted_password,    
      'gender' => $this->input->post('gender'),
      'userType' => $this->input->post('type'),
      'profile'=> $this->uploadPic('profile')
    );


      // return $data;
    if($this->user_model->regsiter_user($data)){

      $this->session->set_flashdata('msg','Admin Regsitered Successfully!');
              // return $data;

    }
    else{

      $this->session->set_flashdata('msg','Admin Registration Failed!');

    } 
    return redirect('admin_controller/registration');  



  }
  else {
    $this->load->view('admin_registration');

  }



}



// Register User in Admin Portal
public function pharm_admin_reg_validator()

{
  $this->form_validation->set_rules('fname','First Name','required');
  $this->form_validation->set_rules('lname','Last Name','required');
  $this->form_validation->set_rules('email','Email','required|valid_email');
  $this->form_validation->set_rules('mobile','Mobile','required');
  $this->form_validation->set_rules('nic','Valid NIC','required');

  if ($this->form_validation->run() )
  {
      // $data=$this->input->post();
    $encrypted_password=md5($this->input->post('password'));
      // unset($data['submit']);
    $this->load->model('user_model');
    $data = array(
      'fName'  => $this->input->post('fname'),
      'lName'  => $this->input->post('lname'),
      'userEmail'  => $this->input->post('email'),
      'userMobile'  => $this->input->post('mobile'),
      'userNIC'  => $this->input->post('nic'),
      'password' => $encrypted_password,    
      'gender' => $this->input->post('gender'),
      'userType' => $this->input->post('type'),
      'profile'=> $this->uploadPic('profile')
    );


      // return $data;
    if($this->user_model->regsiter_user($data)){

      $this->session->set_flashdata('msg','Admin Regsitered Successfully!');
              // return $data;

    }
    else{

      $this->session->set_flashdata('msg','Admin Registration Failed!');

    } 
    return redirect('admin_controller/user_reg');  



  }
  else {
    $this->load->view('user_reg');

  }



}





  // Regsiter Pharmacy
public function register_pharm_validator()

{
  $this->form_validation->set_rules('pharm_name','Pharmacy Name','required');
  $this->form_validation->set_rules('pharm_email','Pharmacy Email','required|valid_email');
  $this->form_validation->set_rules('pharm_phone','Pharmacy Phone','required');
  $this->form_validation->set_rules('pharm_registration_no','Pharmacy Registration','required');
  $this->form_validation->set_rules('address_line1','Pharmacy Address','required');
  $this->form_validation->set_rules('address_line2','Pharmacy Address','required');
  $this->form_validation->set_rules('address_line3','Pharmacy Address','required');

  if ($this->form_validation->run() )
  {
      // $data=$this->input->post();
    // $encrypted_password=md5($this->input->post('password'));
      // unset($data['submit']);
    $this->load->model('user_model');
    $data = array(
      'pharm_name'  => $this->input->post('pharm_name'),
      'pharm_email'  => $this->input->post('pharm_email'),
      'pharm_phone'  => $this->input->post('pharm_phone'),
      'pharm_registration_no'  => $this->input->post('pharm_registration_no'),
      'address_line1'  => $this->input->post('address_line1'),
      'address_line2'  => $this->input->post('address_line2'),
      'address_line3' => $this->input->post('address_line3'),
      'manager_id' => $this->input->post('manager_id'),
      // 'password' => $encrypted_password,         
      'pharm_logo'=> $this->uploadPic('profile')
    );


      // return $data;
    if($this->user_model->regsiter_pharmacy($data)){

      $this->session->set_flashdata('msg','Admin Regsitered Successfully!');
              // return $data;

    }
    else{

      $this->session->set_flashdata('msg','Admin Registration Failed!');

    } 
    return redirect('admin_controller/pharm_reg');  



  }
  else {
      // $this->load->view('admin_home');
    $this->load->view('pharm_registration');
      // return redirect('admin_controller/pharm_reg'); 

  }



}


  // Fetch Pharmacy Data Live
public function fetch_pharm(){

  $output = '';
  $query = '';
  $this->load->model('user_model');
  if($this->input->post('query')){
    $query=$this->input->post('query');
  }
  $data=$this->user_model->fetch_live_pharm($query);
  $output .= '
  <div class="notify-text">Search Results</div>
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Pharmacy Logo</th>
  <th>Pharmacy Name</th>
  <th>Pharmacy Email</th>
  <th>Pharmacy Phone</th>
  <th>Address Line 1</th>
  <th>Address Line 2</th>  
  <th>Address Line 3</th>
  <th>Action</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><img  class="mv-icon" src="'.$row->pharm_logo.'"></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->pharm_email.'</td>
      <td>'.$row->pharm_phone.'</td>
      <td>'.$row->address_line1.'</td> 
      <td>'.$row->address_line2.'</td> 
      <td>'.$row->address_line3.'</td> 
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'edit_pharm/'.$row->pharm_id.'\')" class="bg-success text-white">Modify</a></td> 

      </tr> 
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;



}



  // Fetch Pharmacy for delete admin module

public function fetch_pharm_del(){

  $output = '';
  $query = '';
  $this->load->model('user_model');
  if($this->input->post('query')){
    $query=$this->input->post('query');
  }
  $data=$this->user_model->fetch_live_pharm($query);
  $output .= '
  <div class="notify-text">Search Results</div>
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Pharmacy Logo</th>
  <th>Pharmacy Name</th>
  <th>Pharmacy Email</th>
  <th>Pharmacy Phone</th>
  <th>Address Line 1</th>
  <th>Address Line 2</th>  
  <th>Address Line 3</th>
  <th>Action</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><img  class="mv-icon" src="'.$row->pharm_logo.'"></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->pharm_email.'</td>
      <td>'.$row->pharm_phone.'</td>
      <td>'.$row->address_line1.'</td> 
      <td>'.$row->address_line2.'</td> 
      <td>'.$row->address_line3.'</td> 
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'admin_pharm_del/'.$row->pharm_id.'\')" class="bg-danger text-white">Delete</a></td> 

      </tr> 
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;



}


  // Delete pharmacy from admin module
public function admin_pharm_del($pharm_id){
  $this->load->model('user_model');
  if($this->user_model->removePharmAdmin($pharm_id))
  {

    $this->session->set_flashdata('msg','Pharmacy Deleted Successfully!');

  }
  else{

    $this->session->set_flashdata('msg','Pharmacy Delete Failed!');

  } 
  return redirect('admin_controller/del_pharm');  
}



// get info for pharmacy edit
public function edit_pharm(){
  $this->load->model('user_model');
  $data=$this->user_model->getPharmEdit($this->uri->segment(3));

  $this->load->view('edit_pharm',['data'=>$data]);

}


// get sales report
// get sale report 
public function get_sales_report(){
      // pharm_id
  $data['pharm_id']=$this->uri->segment(3);
      // $this->load->model('admin_model');
  $this->load->view('sales_report',$data);


}


// get item report
public function get_item_report(){
  $data['pharm_id']=$this->uri->segment(3);
      // $this->load->model('admin_model');
  $this->load->view('item_sales',$data);

}

  // Remove user in admin module
public function admin_user_del($userId){
  $this->load->model('user_model');
  if($this->user_model->removeUserAdmin($userId))
  {

    $this->session->set_flashdata('msg','User Deleted Successfully!');

  }
  else{

    $this->session->set_flashdata('msg','User Delete Failed!');

  } 
  return redirect('admin_controller/user_del');  
}




    // Live Data Search Medicine
public function fetch_user(){

  $output = '';
  $query = '';
  $this->load->model('user_model');
  if($this->input->post('query')){
    $query=$this->input->post('query');
  }
  $data=$this->user_model->fetch_live_user($query);
  $output .= '
  <div class="notify-text">Search Results</div>
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Profile</th>
  <th>First Name</th>
  <th>Last Brand</th>
  <th>Email Id</th>
  <th>User Type</th>  
  <th>Action</th>

  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><img  class="mv-icon" src="'.$row->profile.'"></td>
      <td>'.$row->fName.'</td>
      <td>'.$row->lName.'</td>
      <td>'.$row->userEmail.'</td>
      <td>'.$row->userType.'</td> 
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'edit_user/'.$row->userId.'\')" class="bg-success text-white">Modify</a></td> 
      
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;



}

// fetch sales report pharm
public function fetch_report_sales(){
 $output = '';
            // $query = '';
 $pharm_id=$this->uri->segment(3);
 $this->load->model('admin_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
 $data=$this->admin_model->fetch_sales_report($pharm_id);
 $output .= '
 <div class="table-responsive">
 <table class="table table-bordered table-striped" width="80%" >
 <col style="width:20%">
 <col style="width:60%">
 <tr>
 <th>Month</th>
 <th>Total Sales (LKR)</th>  
 </tr>
 ';
 if ($data->num_rows()>0) {
      # code...
  foreach($data->result() as $row)
  {
    $output .= '
    <tr>       
    <td>'.$row->month.'</td>
    <td>'.$row->sales.'</td>      
    </tr>
    ';
  }
}else{
  $output .= '<tr>
  <td colspan="2">Sorry No Data Found</td>
  </tr>';
}
$output .= '</table>';
echo $output;



}




// fetch top item report  fetch_report_items
public function fetch_report_items(){
 $output = '';
            // $query = '';
 $pharm_id=$this->uri->segment(3);
 $this->load->model('admin_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
 $data=$this->admin_model->fetch_report_items($pharm_id);
 $output .= '
 <div class="table-responsive">
 <table class="table table-bordered table-striped" width="80%" >
 <col style="width:20%">
 <col style="width:10%">
 <col style="width:40%">
 <tr>
 <th>Item Name</th>
 <th>Total Items</th> 
 <th>Total Sales (LKR)</th>  
 </tr>
 ';
 if ($data->num_rows()>0) {
      # code...
  foreach($data->result() as $row)
  {
    $output .= '
    <tr>       
    <td>'.$row->item_name.'</td>
    <td>'.$row->noof_items.'</td>
    <td>'.$row->total_sales.'</td>       
    </tr>
    ';
  }
}else{
  $output .= '<tr>
  <td colspan="3">Sorry No Data Found</td>
  </tr>';
}
$output .= '</table>';
echo $output;



}


//create pdf
public function createPDFItems(){

  $pharm_id=$this->uri->segment(3);
  $this->load->model('admin_model');

  require_once('assets/tcpdf_min/tcpdf.php');  

  $obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
  $obj_pdf->SetCreator(PDF_CREATOR);  
  $obj_pdf->SetTitle("Export HTML Table data to PDF using TCPDF in PHP");  
  $obj_pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
  $obj_pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
  $obj_pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
  $obj_pdf->SetDefaultMonospacedFont('helvetica');  
  $obj_pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
  $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);  
  $obj_pdf->setPrintHeader(false);  
  $obj_pdf->setPrintFooter(false);  
  $obj_pdf->SetAutoPageBreak(TRUE, 10);  
  $obj_pdf->SetFont('helvetica', '', 12);  
  $obj_pdf->AddPage();  
  $data=$this->admin_model->fetch_report_items($pharm_id);
  $content = '';  
  $content .= '  
  <h3 align="center">Top selling Items Past Three months</h3><br /><br />  
  <table class="table table-bordered table-striped" width="80%" >
  <col style="width:20%">
  <col style="width:10%">
  <col style="width:40%">
  <tr>
  <th>Item Name</th>
  <th>Total Items</th> 
  <th>Total Sales (LKR)</th>  
  </tr> 
  ';  
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $content .= '
      <tr>       
      <td>'.$row->item_name.'</td>
      <td>'.$row->noof_items.'</td>
      <td>'.$row->total_sales.'</td>       
      </tr>
      ';
    }
  }else{
    $content .= '<tr>
    <td colspan="3">Sorry No Data Found</td>
    </tr>';
  }
  $content .= '</table>';
// echo $content;
  // $content .= fetch_data();  
  // $content .= '</table>';  
  $obj_pdf->writeHTML($content);  
  $obj_pdf->Output('sample.pdf', 'I');  

}

// fetch user for delete Live data
public function fetch_user_del(){

  $output = '';
  $query = '';
  $this->load->model('user_model');
  if($this->input->post('query')){
    $query=$this->input->post('query');
  }
  $data=$this->user_model->fetch_live_user($query);
  $output .= '
  <div class="notify-text">Search Results</div>
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Profile</th>
  <th>First Name</th>
  <th>Last Brand</th>
  <th>Email Id</th>
  <th>User Type</th>  
  <th>Action</th>

  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><img  class="mv-icon" src="'.$row->profile.'"></td>
      <td>'.$row->fName.'</td>
      <td>'.$row->lName.'</td>
      <td>'.$row->userEmail.'</td>
      <td>'.$row->userType.'</td> 
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'admin_user_del/'.$row->userId.'\')" class="bg-danger text-white">Delete</a></td> 
      
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;



}


// fetch user data to update form in admin module
public function edit_user(){
  $this->load->model('user_model');
  $data=$this->user_model->getUserEdit($this->uri->segment(3));
  $this->load->view('modify_user',['data'=>$data]);

}




  // update pharmacy info
public function update_pharm_info($pharm_id){

 $this->form_validation->set_rules('pharm_name','Pharmacy Name','required');
 $this->form_validation->set_rules('pharm_email','Pharmacy Email','required|valid_email');
 $this->form_validation->set_rules('pharm_phone','Pharmacy Phone','required');
 $this->form_validation->set_rules('pharm_registration_no','Pharmacy Registration','required');
 $this->form_validation->set_rules('address_line1','Pharmacy Address','required');
 $this->form_validation->set_rules('address_line2','Pharmacy Address','required');
 $this->form_validation->set_rules('address_line3','Pharmacy Address','required');
 if ($this->form_validation->run() )
 {

  $data=$this->input->post();
  unset($data['submit']);
  $this->load->model('user_model');

  if($this->user_model->updatePharmInfo($pharm_id,$data)){

    $this->session->set_flashdata('msg','Pharmacy Updated Successfully!');

  }
  else{

    $this->session->set_flashdata('msg','Pharmacy Update Failed!');

  } 
  return redirect('admin_controller/pharm_edit');    

}
else
{

  $this->load->view('update_pharm');   
}

}

//update user in Admin module
// update pharmacy info
public function update_user_info($userId){

  $this->form_validation->set_rules('fName','First Name','required');
  $this->form_validation->set_rules('lName','Last Name','required');
  $this->form_validation->set_rules('userEmail','Email','required|valid_email');
  $this->form_validation->set_rules('userMobile','Mobile','required');
  $this->form_validation->set_rules('userNIC','Valid NIC','required');

  if ($this->form_validation->run() )
  {

    $data=$this->input->post();
    unset($data['submit']);
    $this->load->model('user_model');

    if($this->user_model->updateUserInfo($userId,$data)){

      $this->session->set_flashdata('msg','User Updated Successfully!');

    }
    else{

      $this->session->set_flashdata('msg','User Update Failed!');

    } 
    return redirect('admin_controller/user_edit');    

  }
  else
  {

    $this->load->view('update_user');   
  }

}



// Validate user and create an entry in the login session table
public function login_validator(){
    // $this->load->view('user_login');
  $this->form_validation->set_rules('email','Email','required|valid_email');
  $this->form_validation->set_rules('password','password','required');

  if($this->form_validation->run()){

    $email=$this->input->post('email');

    $encrypted_password=md5($this->input->post('password'));

    $this->load->model('user_model');

    if ($this->user_model->can_login($email,$encrypted_password)) {

      $userData=$this->user_model->getUserAll($email);

      // $username=$this->user_model->getFName($email);
      // $userId=$this->user_model->getUid($email);
      // $profile=$this->user_model->getProPic($email);
      $username=$userData->fName;
      $userId=$userData->userId;
      $profile=$userData->profile;
      $sessionId=rand(10,100000);
      $loginTime=  date('Y-m-d H:i:s');
          // $loginTime='now()';

      $login_data = array('userId' =>$userId,
        'sessionId' =>$sessionId,
        'status' => "Active",
        'loginTime' =>  $loginTime );

      if ($this->user_model->createSession($login_data)) {
            # code...
        $data['username'] = $username;
        $data['sessionId']= $sessionId;
        $data['userId']= $userId;
        $data['profile']= $profile;

        $this->load->view('admin_home',$data);

      }else{
        $this->session->set_flashdata('msg','Cannot create session!');
        return redirect('admin_controller/login');
      }

          // echo 'Welcome to omdp '. $uname;




    }else{
     $this->session->set_flashdata('msg','Invalid Email or Password!');
     return redirect('admin_controller/login');

   }




 }
 else{
   $this->load->view('admin_login');
 }
}


// update Total registration in Admin Dashboard
public function totalRegUsers(){
  $this->load->model('admin_model');    
  $totalReg= $this->admin_model->regUserCount();
  echo $totalReg;
  

}


public function ActiveSessions(){
  $this->load->model('admin_model');    
  $totalReg= $this->admin_model->ActiveSessionCount();
  echo $totalReg;
  

}

// get total orders TotalOrders

public function TotalOrders(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');   
  $totalReg= $this->admin_model->TotalOrdersPharm($pharm_id);
  echo $totalReg;
  

}

// get total revenue
public function TotalRevenue(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->TotalRevenuePharm($pharm_id);
  echo $totalReg;

}


// get total item in stock pharmacy
public function TotalItemsPharm(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->TotalItemsPharm($pharm_id);
  echo $totalReg;

}


// in stock items
public function InStockItemsPharm(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->InStockItemsPharm($pharm_id);
  echo $totalReg;

}

//run short items
public function runShortItemsPharm(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->runShortItemsPharm($pharm_id);
  echo $totalReg;

}


// total order completed
public function TotalComplete(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->totalCompletePharm($pharm_id);
  echo $totalReg;
}


// total pending
public function TotalPending(){
 $this->load->model('admin_model'); 
 $pharm_id=$this->input->post('pharm_id');
 $totalReg= $this->admin_model->totalPendingPharm($pharm_id);
 echo $totalReg;

}


// get out of stock items
public function outofStockItemsPharm(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->outofStockItemsPharm($pharm_id);
  echo $totalReg;
}

// get total prescriptions TotalPrescription

public function TotalPrescription(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->TotalPrescriptionsPharm($pharm_id);
  echo $totalReg;

}


// get dispatched orders
public function TotalDispatched(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $totalReg= $this->admin_model->TotalDispachedPharm($pharm_id);
  echo $totalReg;
}

// get pie chart data for order %
public function getPieChartOrders(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $query= $this->admin_model->getpieChart($pharm_id);
  
  $data = array();

  foreach($query->result() as $row)
  {
    $data[] = array(
      'order_status'    =>  $row->order_status,
      'total'     =>     $row->total,
      'color'     =>  '#' . rand(100000, 999999) . ''
    );
  }

      // echo json_encode($query->result());

  echo json_encode($data);

}


// get line chart 
public function getLineChartItems(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $query= $this->admin_model->getLineChartItems($pharm_id);

  $data = array();

  foreach($query->result() as $row)
  {
    $data[] = array(
      'day'    =>  $row->day,
      'sales'     =>     $row->sales
          // 'color'     =>  '#' . rand(100000, 999999) . ''
    );
  }

      // echo json_encode($query->result());

  echo json_encode($data);

}

// get line chart orders
public function getLineChartOrders(){
 $this->load->model('admin_model'); 
 $pharm_id=$this->input->post('pharm_id');
 $query= $this->admin_model->getLineChartOrders($pharm_id);

 $data = array();

 foreach($query->result() as $row)
 {
  $data[] = array(
    'day'    =>  $row->day,
    'orders'     =>     $row->orders
          // 'color'     =>  '#' . rand(100000, 999999) . ''
  );
}

      // echo json_encode($query->result());

echo json_encode($data);

}


// get top sold items
public function getBarChartItems(){
  $this->load->model('admin_model'); 
  $pharm_id=$this->input->post('pharm_id');
  $query= $this->admin_model->getBarChartItems($pharm_id);

  $data = array();

  foreach($query->result() as $row)
  {
    $data[] = array(
      'item_name'    =>  $row->item_name,
      'total'     =>     $row->total,
      'color'     =>  '#' . rand(100000, 999999) . ''
    );
  }

      // echo json_encode($query->result());

  echo json_encode($data);

}


}

?>