 <?php  	defined('BASEPATH') OR exit('No direct script access allowed');

 class order_controller extends CI_Controller {



   public function checkout(){
    $this->load->view("checkout");

  }

  public function prescriptionCheckout(){

    $this->load->view("prescription_checkout");
  }



  public function test_payment(){
    $this->load->view("orderPaymentDetails");

  }

// place otc order
  public function placeOrder(){
    $orderId=$this->input->post('orderId');
    $order_pharm_id=$this->input->post('pharm_id');
    // $order_payment_method=$this->input->post('order_payment_method');
    // $order_final_bill=$this->input->post('order_final_bill');          
    $order_timesatmp=  date('Y-m-d H:i:s');
    $this->load->model('order_model');

    if($this->input->post('order_payment_method') and $this->input->post('order_final_bill')){
     $order_payment_method=$this->input->post('order_payment_method');
     $order_final_bill=$this->input->post('order_final_bill'); 
     

   }else{
    $order_payment_method=$this->order_model->getOrderAllNew($orderId)->order_payment_method;
    $order_final_bill=$this->order_model->getOrderAllNew($orderId)->order_final_bill;
  }


  if($this->order_model->completeOrder($orderId,$order_payment_method,$order_final_bill,$order_pharm_id,$order_timesatmp)){
    $this->session->set_flashdata('msg','Your order has been submitted to Pharmacy! You will receive an Order Creation Email Shortly');
              // send Email
    $recepient_email=$this->order_model->getOrderAllNew($orderId)->order_email;
    $recepient_name=$this->order_model->getOrderAllNew($orderId)->customer_fname;
    $order_pharm_name=$this->order_model->getOrderAllNew($orderId)->pharm_name;
          // send Email
    $this->sendOrderCreateEmail($recepient_email,$recepient_name,$orderId,$order_payment_method,$order_final_bill,$order_pharm_name,$order_timesatmp);
              // destroy shopping cart
    $this->load->library("cart");
    $this->cart->destroy();
    return redirect('user_controller/main_inner_content_cust/');
  }else
  {
    echo "Failed to Logout!";
  }



}


// send quotation to customer
public function sendQuote(){
  $orderId=$this->input->post('orderId');
  $order_pharm_id=$this->input->post('pharm_id');
  $prescription_pharm_comment=$this->input->post('prescription_pharm_comment');
  $order_final_bill=$this->input->post('order_final_bill');          
  $order_updateTimeStamp=date('Y-m-d H:i:s');
  $order_status='approved';

  $this->load->model('order_model');
  $this->load->model('shop_model');

  if($this->order_model->sendQuote($orderId,$order_pharm_id,$prescription_pharm_comment,$order_final_bill,$order_updateTimeStamp,$order_status)){
    $this->session->set_flashdata('msg','You have sent prescription quotaion to Customer! Customer will review the quotation and will provide feedback');

    $recepient_email=$this->order_model->fetch_all_order_presc_pharm($orderId)->order_email;
    $recepient_name=$this->order_model->fetch_all_order_presc_pharm($orderId)->customer_fname;
    $order_pharm_name=$this->order_model->fetch_all_order_presc_pharm($orderId)->pharm_name;
    $prescription_id=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_id;
    $prescription_name=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_name;

    $subject = "Prescription Update Mail";
    $message = "
    <br>
    <p>Dear ".$recepient_name.",</p>
    <p>Thank you for using OMDP to buy your Pharamacy Items!</p>
    <p>Please  note that  your Prescription order with ".$orderId. " has been ".$order_status." by ".$order_pharm_name."Please check the quotation using the system.</p>
    <br>    
    <div class=\"table-responsive\">
    <table class=\"table table-bordered\">
    <tr>
    <th>Order Id</th>
    <td>".$orderId."</td>
    </tr>
    <tr>
    <th>Prescription Name</th>
    <td>".$prescription_name."</td>
    </tr>
    <tr>
    <th>Order updated on</th>
    <td>".$order_updateTimeStamp."</td>
    </tr>
    <tr>
    <th>Pharmacy Name</th>
    <td>".$order_pharm_name."</td>
    </tr>
    <tr>
    <th>Order Status</th>
    <td><b>".$order_status."</b></td>
    </tr>
    </table>
    </div>

    <br>
    <p>Best Regards,</p>
    <p>OMDP Team</p>
    ";

    $this->sendEmail($recepient_email,$subject,$message);
    $this->load->library("cart");
    foreach ($this->cart->contents() as $items) {
     $data = array( 'orderId' => $orderId,
       'med_item_id' => $items["id"] ,
       'med_item_name' =>$items["name"] ,
       'pharm_id' => $items["options"]["pharm_id"],
       'order_item_quantity'=>$items["qty"],
       'order_item_subtotal'=> $items["subtotal"]);
                  // insert item to order item table
     $this->shop_model->add_order_item($data);


   }
          // send Email
      // $this->sendOrderUpdateEmail($recepient_email,$recepient_name,$orderId,$order_pharm_name,$order_timesatmp,$order_status);
              // destroy shopping cart
   
   $this->cart->destroy();




 }else
 {
  $this->session->set_flashdata('msg','Failed to Accept order');

}
return redirect('order_controller/get_ongiong_pres_pharm/'.$order_pharm_id);





}


// place prescription to pharmacyy
public function placePrescription(){
  $orderId=$this->input->post('orderId');
  $order_pharm_id=$this->input->post('order_pharm_id');
  $order_payment_method=$this->input->post('order_payment_method');
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
  $order_final_bill='';
  $order_status='submitted';         
  $order_timesatmp= date('Y-m-d H:i:s');
  $this->load->model('order_model');


  if($this->order_model->completeOrderPrecription($orderId,$order_payment_method,$order_status,$order_pharm_id,$order_timesatmp)){
    $this->session->set_flashdata('msg','Your precription has been send to pharmacy! A pharmacist wil check and validate your prescription!');
              // send Email
    $recepient_email=$this->order_model->getOrderAllNew($orderId)->order_email;
    $recepient_name=$this->order_model->getOrderAllNew($orderId)->customer_fname;
    $order_pharm_name=$this->order_model->getOrderAllNew($orderId)->pharm_name;
    $prescription_id=$this->order_model->getPrescriptionId($orderId)->prescription_id;

    $subject = "Prescription Update Mail";
    $message = "
    <br>
    <p>Dear ".$recepient_name.",</p>
    <p>Thank you for using OMDP to buy your Pharamacy Items!</p>
    <p>Please  note that  your Prescription order with ".$orderId. "  has been ".$order_status."t o ".$order_pharm_name."A pharmacist will review the prescription and get back to you soon! Please find the order details below.</p>
    <br>    
    <div class=\"table-responsive\">
    <table class=\"table table-bordered\">
    <tr>
    <th>Order Id</th>
    <td>".$orderId."</td>
    </tr>
    <tr>
    <th>Prescription Id</th>
    <td>".$prescription_id."</td>
    </tr>
    <tr>
    <th>Order updated on</th>
    <td>".$order_timesatmp."</td>
    </tr>
    <tr>
    <th>Pharmacy Name</th>
    <td>".$order_pharm_name."</td>
    </tr>
    <tr>
    <th>Order Status</th>
    <td><b>".$order_status."</b></td>
    </tr>
    </table>
    </div>

    <br>
    <p>Best Regards,</p>
    <p>OMDP Team</p>
    ";

    $this->sendEmail($recepient_email,$subject,$message);
          // send Email
      // $this->sendOrderUpdateEmail($recepient_email,$recepient_name,$orderId,$order_pharm_name,$order_timesatmp,$order_status);
              // destroy shopping cart
    $this->load->library("cart");
    $this->cart->destroy();




  }else
  {
    $this->session->set_flashdata('msg','Failed to Accept order');
  }
  return redirect('user_controller/main_inner_content_cust/');



}
  // // finish processing  finishProcess
  // public function finishProcess(){
  //   $orderId=$this->input->post('orderId');
  //   $order_pharm_id=$this->input->post('pharm_id');
  //   $order_status='dispatched'; 
  //   // $order_payment_method=$this->input->post('order_payment_method');
  //   // $order_final_bill=$this->input->post('order_final_bill');          
  //   $order_timesatmp=  date('Y-m-d H:i:s');
  //   $this->load->model('order_model');


  //   if($this->order_model->finishProcessOrder($orderId,$order_payment_method,$order_final_bill,$order_pharm_id,$order_timesatmp)){
  //     $this->session->set_flashdata('msg','Your have finished processing this order! Customer will be acknowldged! A delivery personnel will pick your order');
  //             // send Email
  //     $recepient_email=$this->order_model->getOrderAll($orderId)->order_email;
  //     $recepient_name=$this->order_model->getOrderAll($orderId)->customer_fname;
  //     $order_pharm_name=$this->order_model->getPharmAll($order_pharm_id)->pharm_name;
  //         // send Email
  //     $this->sendOrderCreateEmail($recepient_email,$recepient_name,$orderId,$order_payment_method,$order_final_bill,$order_pharm_name,$order_timesatmp);
  //             // destroy shopping cart
  //     $this->load->library("cart");
  //     $this->cart->destroy();
  //     return redirect('user_controller/main_inner_content_cust/');
  //   }else
  //   {
  //     echo "Failed to Logout!";
  //   }



  // }






// common email function





// Email functions
public function sendOrderCreateEmail($recepient_email,$recepient_name,$orderId,$order_payment_method,$order_final_bill,$order_pharm_name,$order_timesatmp){
  $subject = "Order Creation Mail";
  $message = "
  <br>
  <p>Dear ".$recepient_name.",</p>
  <p>Thank you for using OMDP to buy your Pharamacy Items!</p>
  <p>Please  note that  your Order with ".$orderId. " with ".$order_pharm_name." has been created Please find the order details below.</p>
  <br>    
  <div class=\"table-responsive\">
  <table class=\"table table-bordered\">
  <tr>
  <th>Order Id</th>
  <td>".$orderId."</td>
  </tr>
  <tr>
  <th>Total Value</th>
  <td>LKR ".$order_final_bill."</td>
  </tr>
  <tr>
  <th>Order created on</th>
  <td>".$order_timesatmp."</td>
  </tr>
  <tr>
  <th>Pharmacy Name</th>
  <td>".$order_pharm_name."</td>
  </tr>
  </table>
  </div>

  <br>
  <p>Best Regards,</p>
  <p>OMDP Team</p>
  ";
  $config['protocol']    = 'smtp';
  $config['smtp_host']    = 'ssl://smtp.googlemail.com';
  $config['smtp_port']    = '465';
  $config['smtp_timeout'] = '7';
  $config['smtp_user']    = 'dulan.dam@gmail.com';
  $config['smtp_pass']    = '92.12.04';
  $config['charset']    = 'utf-8';
  $config['newline']    = "\r\n";
    $config['mailtype'] = 'html'; // or html
    $config['validation'] = TRUE; // bool whether to validate email or not  

    $this->load->library('email', $config);
    $this->email->set_newline("\r\n");
    $this->email->from('dulan.dam@gmail.com');
    // $this->email->to($this->input->post('user_email'));
    $this->email->to($recepient_email);
    $this->email->subject($subject);
    $this->email->message($message);
    $this->email->send();
    // if($this->email->send())
    // {
    //  $this->session->set_flashdata('message', 'Check in your email for email verification mail');
    //  // redirect('/order_controller/testEmail');
    // }
    // else{
    //   $this->session->set_flashdata('message', 'Failed');
    //  // redirect('/order_controller/testEmail');
    // }
  }



  public function sendOrderUpdateEmail($recepient_email,$recepient_name,$orderId,$order_pharm_name,$order_timesatmp,$order_status){
    $subject = "Order Update Mail";
    $message = "
    <br>
    <p>Dear ".$recepient_name.",</p>
    <p>Thank you for using OMDP to buy your Pharamacy Items!</p>
    <p>Please  note that  your Order with ".$orderId. "  has been accepted. Pharmacy with ".$order_pharm_name." is currently ".$order_status." your order. Please find the order details below.</p>
    <br>    
    <div class=\"table-responsive\">
    <table class=\"table table-bordered\">
    <tr>
    <th>Order Id</th>
    <td>".$orderId."</td>
    </tr>
    <tr>
    <th>Total Value</th>
    <td>LKR ".$order_final_bill."</td>
    </tr>
    <tr>
    <th>Order updated on</th>
    <td>".$order_timesatmp."</td>
    </tr>
    <tr>
    <th>Pharmacy Name</th>
    <td>".$order_pharm_name."</td>
    </tr>
    <tr>
    <th>Order Status</th>
    <td><b>".$order_status."</b></td>
    </tr>
    </table>
    </div>

    <br>
    <p>Best Regards,</p>
    <p>OMDP Team</p>
    ";
    $config['protocol']    = 'smtp';
    $config['smtp_host']    = 'ssl://smtp.googlemail.com';
    $config['smtp_port']    = '465';
    $config['smtp_timeout'] = '7';
    $config['smtp_user']    = 'dulan.dam@gmail.com';
    $config['smtp_pass']    = '92.12.04';
    $config['charset']    = 'utf-8';
    $config['newline']    = "\r\n";
    $config['mailtype'] = 'html'; // or html
    $config['validation'] = TRUE; // bool whether to validate email or not  

    $this->load->library('email', $config);
    $this->email->set_newline("\r\n");
    $this->email->from('dulan.dam@gmail.com');
    // $this->email->to($this->input->post('user_email'));
    // $this->email->to($recepient_email);
    $this->email->to($recepient_email);
    $this->email->subject($subject);
    $this->email->message($message);
    $this->email->send();
    // if($this->email->send())
    // {
    //  $this->session->set_flashdata('message', 'Check in your email for email verification mail');
    //  // redirect('/order_controller/testEmail');
    // }
    // else{
    //   $this->session->set_flashdata('message', 'Failed');
    //  // redirect('/order_controller/testEmail');
    // }
  }

// accept order by cashier
  public function AcceptOrder(){

    $orderId=$this->uri->segment(3);
    $order_pharm_id=$this->uri->segment(4);
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
    $order_status='preparing';         
    $order_timesatmp= date('Y-m-d H:i:s');
    $this->load->model('order_model');


    if($this->order_model->updateOrderStatus($orderId,$order_status,$order_timesatmp)){
      $this->session->set_flashdata('msg','Your have accepted this order! Click the below link to start preparing the order');
              // send Email
      $recepient_email=$this->order_model->getOrderAll($orderId)->order_email;
      $recepient_name=$this->order_model->getOrderAll($orderId)->customer_fname;
      $order_pharm_name=$this->order_model->getPharmAll($order_pharm_id)->pharm_name;
          // send Email
      $this->sendOrderUpdateEmail($recepient_email,$recepient_name,$orderId,$order_pharm_name,$order_timesatmp,$order_status);
              // destroy shopping cart
          // $this->load->library("cart");
          // $this->cart->destroy();
      $this->order_model->update_inventory($orderId);




    }else
    {
      $this->session->set_flashdata('msg','Failed to Accept order');
    }
    return redirect('order_controller/get_current_order_pharm/'.$order_pharm_id);



  }



  // accept incoming prescription pharm_id
  // accept order by cashier
  public function AcceptPres(){

    $orderId=$this->uri->segment(3);
    $order_pharm_id=$this->uri->segment(4);
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
    $order_status='reviewing';         
    $order_updateTimeStamp= date('Y-m-d H:i:s');
    $this->load->model('order_model');


    if($this->order_model->updateOrderStatus($orderId,$order_status,$order_timesatmp)){
      $this->session->set_flashdata('msg','Your have accepted this prescription! Click the below link to start reviewing the order');
              // send Email
      $recepient_email=$this->order_model->fetch_all_order_presc_pharm($orderId)->order_email;
      $recepient_name=$this->order_model->fetch_all_order_presc_pharm($orderId)->customer_fname;
      $order_pharm_name=$this->order_model->fetch_all_order_presc_pharm($orderId)->pharm_name;
      $prescription_name=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_name;
      // $order_pharm_name=$this->order_model->getOrderAllNew($orderId)->pharm_name;
          // send Email
      // $this->sendOrderUpdateEmail($recepient_email,$recepient_name,$orderId,$order_pharm_name,$order_timesatmp,$order_status);
      $subject = "Prescription Update Mail";
      $message = "
      <br>
      <p>Dear ".$recepient_name.",</p>
      <p>Thank you for using OMDP to buy your Pharamacy Items!</p>
      <p>Please  note that  your Prescription order with ".$orderId. "  is being ".$order_status." by ".$order_pharm_name."The pharmacist will review and provide an update on the items and cost! Please find the order details below.</p>
      <br>    
      <div class=\"table-responsive\">
      <table class=\"table table-bordered\">
      <tr>
      <th>Order Id</th>
      <td>".$orderId."</td>
      </tr>
      <tr>
      <th>Prescription Id</th>
      <td>".$prescription_name."</td>
      </tr>
      <tr>
      <th>Order updated on</th>
      <td>".$order_updateTimeStamp."</td>
      </tr>
      <tr>
      <th>Pharmacy Name</th>
      <td>".$order_pharm_name."</td>
      </tr>
      <tr>
      <th>Order Status</th>
      <td><b>".$order_status."</b></td>
      </tr>
      </table>
      </div>

      <br>
      <p>Best Regards,</p>
      <p>OMDP Team</p>
      ";

      $this->sendEmail($recepient_email,$subject,$message);
              // destroy shopping cart
      $this->load->library("cart");
      // $this->cart->destroy();

    }else
    {
      $this->session->set_flashdata('msg','Failed to Accept order');
    }
    return redirect('order_controller/get_incoming_pres_pharm/'.$order_pharm_id);



  }



  // finish processing order by cashier
  public function finishProcess(){

    $orderId=$this->uri->segment(3);
    $order_pharm_id=$this->uri->segment(4);
    $order_status='dispatched'; 
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
    // $order_status='preparing';         
    $order_timesatmp= date('Y-m-d H:i:s');
    $this->load->model('order_model');


    if($this->order_model->finishProcessOrder($orderId,$order_status,$order_timesatmp)){
      $this->session->set_flashdata('msg','Your order is recieved by our Deliverry Personnal! You will receive your order very soon');
              // send Email
      $recepient_email=$this->order_model->getOrderAll($orderId)->order_email;
      $recepient_name=$this->order_model->getOrderAll($orderId)->customer_fname;
      $order_pharm_name=$this->order_model->getPharmAll($order_pharm_id)->pharm_name;
      $subject = "Order Update Mail";
      $message = "
      <br>
      <p>Dear ".$recepient_name.",</p>
      <p>Thank you for using OMDP to buy your Pharamacy Items!</p>
      <p>Please  note that  your Order with ".$orderId. "  has been completed processing and dispatched. Pharmacy with ".$order_pharm_name." is currently ".$order_status.". A delivery person will pick your order! Please find the order details below.</p>
      <br>    
      <div class=\"table-responsive\">
      <table class=\"table table-bordered\">
      <tr>
      <th>Order Id</th>
      <td>".$orderId."</td>
      </tr>
      <tr>
      <th>Total Value</th>
      <td>LKR ".$order_final_bill."</td>
      </tr>
      <tr>
      <th>Order updated on</th>
      <td>".$order_timesatmp."</td>
      </tr>
      <tr>
      <th>Pharmacy Name</th>
      <td>".$order_pharm_name."</td>
      </tr>
      <tr>
      <th>Order Status</th>
      <td><b>".$order_status."</b></td>
      </tr>
      </table>
      </div>

      <br>
      <p>Best Regards,</p>
      <p>OMDP Team</p>
      ";


          // send Email
      $this->sendEmail($recepient_email,$subject,$message);
              // destroy shopping cart
      $this->load->library("cart");
      $this->cart->destroy();
      $deliver_link=base_url()."order_controller/accept_package/".$orderId."/".$order_pharm_id;

      // send delivery mail
      $this->sendEmail('ddamasean@gmail.com',"Please deliver the order ".$orderId." below ",$deliver_link);


    }else
    {
      $this->session->set_flashdata('msg','Failed to Finish order');
    }
    return redirect('order_controller/get_ongoing_order_pharm/'.$order_pharm_id);



  }


  public function load_driver(){
   $orderId=$this->uri->segment(3);
   $order_pharm_id=$this->uri->segment(4);
   $this->load->model('order_model');
   $data['orderId']=$orderId;
   $data['order_pharm_id']=$order_pharm_id;
   $data['recepient_email']=$this->order_model->getOrderAll($orderId)->order_email;
   $data['recepient_name']=$this->order_model->getOrderAll($orderId)->customer_fname;
   $data['order_mobile']=$this->order_model->getOrderAll($orderId)->order_mobile;
   $data['customer_lname']=$this->order_model->getOrderAll($orderId)->customer_lname;
   $data['order_address1']=$this->order_model->getOrderAll($orderId)->order_address1;
   $data['order_address2']=$this->order_model->getOrderAll($orderId)->order_address2;
   $data['order_address3']=$this->order_model->getOrderAll($orderId)->order_address3;
   $data['order_status']=$this->order_model->getOrderAll($orderId)->order_status;

   $this->load->view("driver_page_complete",$data);

 }


 public function load_driver_completed(){
   $orderId=$this->uri->segment(3);
   $order_pharm_id=$this->uri->segment(4);
   $this->load->model('order_model');
   $data['orderId']=$orderId;
   $data['order_pharm_id']=$order_pharm_id;
   $data['recepient_email']=$this->order_model->getOrderAll($orderId)->order_email;
   $data['recepient_name']=$this->order_model->getOrderAll($orderId)->customer_fname;
   $data['order_mobile']=$this->order_model->getOrderAll($orderId)->order_mobile;
   $data['customer_lname']=$this->order_model->getOrderAll($orderId)->customer_lname;
   $data['order_address1']=$this->order_model->getOrderAll($orderId)->order_address1;
   $data['order_address2']=$this->order_model->getOrderAll($orderId)->order_address2;
   $data['order_address3']=$this->order_model->getOrderAll($orderId)->order_address3;
   $data['order_status']=$this->order_model->getOrderAll($orderId)->order_status;

   $this->load->view("driver_done_page",$data);

 }

  //deliver function
 public function accept_package(){
   $orderId=$this->uri->segment(3);
   $order_pharm_id=$this->uri->segment(4);
   $order_status='on the way'; 
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
   $this->load->model('order_model');
   $recepient_email=$this->order_model->getOrderAll($orderId)->order_email;
   $recepient_name=$this->order_model->getOrderAll($orderId)->customer_fname;
   $order_pharm_name=$this->order_model->getPharmAll($order_pharm_id)->pharm_name;
   $order_mobile=$this->order_model->getOrderAll($orderId)->order_mobile;
   $customer_lname=$this->order_model->getOrderAll($orderId)->customer_lname;
   $order_address1=$this->order_model->getOrderAll($orderId)->order_address1;
   $order_address2=$this->order_model->getOrderAll($orderId)->order_address2;
   $order_address3=$this->order_model->getOrderAll($orderId)->order_address3;
    // $order_status='preparing';         
   $order_timesatmp= date('Y-m-d H:i:s');



   if($this->order_model->acceptOrderPackeg($orderId,$order_status,$order_timesatmp)){
    $this->session->set_flashdata('msg','You have received the Package of orderId '.$orderId."! Please deliver safely to Customer");
              // send Email


    $subject = "Order Update Mail";
    $message = "
    <br>
    <p>Dear ".$recepient_name.",</p>
    <p>Thank you for using OMDP to buy your Pharamacy Items!</p> Your items have been handed over to our delivery personnel.Your order with Pharmacy  ".$order_pharm_name." is currently ".$order_status.". Please wear a face mask and sanitize yourself before and after receiving the oder.</p>
    <br>    
    <div class=\"table-responsive\">
    <table class=\"table table-bordered\">
    <tr>
    <th>Order Id</th>
    <td>".$orderId."</td>
    </tr>
    <tr>
    <th>Order updated on</th>
    <td>".$order_timesatmp."</td>
    </tr>
    <tr>
    <th>Pharmacy Name</th>
    <td>".$order_pharm_name."</td>
    </tr>
    <tr>
    <th>Order Status</th>
    <td><b>".$order_status."</b></td>
    </tr>
    </table>
    </div>

    <br>
    <p>Best Regards,</p>
    <p>OMDP Team</p>
    ";


          // send Email
    $this->sendEmail($recepient_email,$subject,$message);
              // destroy shopping cart
      // $this->load->library("cart");
      // $this->cart->destroy();
    $data['orderId']=$orderId;
    $data['order_pharm_id']=$order_pharm_id;
    $data['recepient_email']=$recepient_email;
    $data['recepient_name']=$recepient_name;
    $data['order_mobile']=$order_mobile;
    $data['customer_lname']=$customer_lname;
    $data['order_address1']=$order_address1;
    $data['order_address2']=$order_address2;
    $data['order_address3']=$order_address3;
    $data['order_status']=$this->order_model->getOrderAll($orderId)->order_status; 
    $this->load->view("driver_page",$data);




      // $this->load->view("driver_page",$data);
      // $deliver_link=base_url()."order_controller/accept_package/".$orderId."/".$order_pharm_id;

      // send delivery mail
      // $this->sendEmail('ddamasean@gmail.com',"Please deliver the order ".$orderId." below ",$deliver_link);


  }
  else
  {
    $this->session->set_flashdata('msg','Failed to accept order');
  }
    // return redirect('order_controller/get_ongoing_order_pharm/'.$order_pharm_id);


}


 //complete and handover order to customer
  //arrive function
public function arrive_location(){
 $orderId=$this->uri->segment(3);
 $order_pharm_id=$this->uri->segment(4);

 $order_status='arrived'; 
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
 $this->load->model('order_model');
 $recepient_email=$this->order_model->getOrderAll($orderId)->order_email;
 $recepient_name=$this->order_model->getOrderAll($orderId)->customer_fname;
 $order_pharm_name=$this->order_model->getPharmAll($order_pharm_id)->pharm_name;
 $order_mobile=$this->order_model->getOrderAll($orderId)->order_mobile;
 $customer_lname=$this->order_model->getOrderAll($orderId)->customer_lname;
 $order_address1=$this->order_model->getOrderAll($orderId)->order_address1;
 $order_address2=$this->order_model->getOrderAll($orderId)->order_address2;
 $order_address3=$this->order_model->getOrderAll($orderId)->order_address3;
    // $order_status='preparing';         
 $order_timesatmp= date('Y-m-d H:i:s');




 if($this->order_model->updateOrderStatus($orderId,$order_status,$order_timesatmp)){
  $this->session->set_flashdata('msg','You have arrived at the location to deliver ! We will acknowldge the customer to collect the order');
              // send Email


  $subject = "Order Update Mail";
  $message = "
  <br>
  <p>Dear ".$recepient_name.",</p>
  <p>Thank you for using OMDP to buy your Pharamacy Items!</p>.Your order with Pharmacy  ".$order_pharm_name."  has ".$order_status.". Please wear a face mask and sanitize yourself before and after receiving the order.</p>
  <br>    
  <div class=\"table-responsive\">
  <table class=\"table table-bordered\">
  <tr>
  <th>Order Id</th>
  <td>".$orderId."</td>
  </tr>
  <tr>
  <th>Order updated on</th>
  <td>".$order_timesatmp."</td>
  </tr>
  <tr>
  <th>Pharmacy Name</th>
  <td>".$order_pharm_name."</td>
  </tr>
  <tr>
  <th>Order Status</th>
  <td><b>".$order_status."</b></td>
  </tr>
  </table>
  </div>

  <br>
  <p>Best Regards,</p>
  <p>OMDP Team</p>
  ";


          // send Email
  $this->sendEmail($recepient_email,$subject,$message);
              // destroy shopping cart
      // $this->load->library("cart");
      // $this->cart->destroy();
  $data['orderId']=$orderId;
  $data['order_pharm_id']=$order_pharm_id;
  $data['recepient_email']=$recepient_email;
  $data['recepient_name']=$recepient_name;
  $data['order_mobile']=$order_mobile;
  $data['customer_lname']=$customer_lname;
  $data['order_address1']=$order_address1;
  $data['order_address2']=$order_address2;
  $data['order_address3']=$order_address3;
  $data['order_status']=$this->order_model->getOrderAll($orderId)->order_status;
      // $this->load->view("driver_page",$data);




      // $this->load->view("driver_page",$data);
      // $deliver_link=base_url()."order_controller/accept_package/".$orderId."/".$order_pharm_id;

      // send delivery mail
      // $this->sendEmail('ddamasean@gmail.com',"Please deliver the order ".$orderId." below ",$deliver_link);

  return redirect('order_controller/load_driver/'.$orderId.'/'.$order_pharm_id);
  var_dump($this->session->flashdata('msg'));
      // return redirect('order_controller/accept_package/'.$orderId.'/'.$order_pharm_id,'refresh');
}
else
{
  $this->session->set_flashdata('msg','Failed to accept order');
}
    // return redirect('','refresh');
    // return redirect('order_controller/accept_package/'.$orderId.'/'.$order_pharm_id);



}



// complete order 
public function complete_order(){
 $orderId=$this->uri->segment(3);
 $order_pharm_id=$this->uri->segment(4);

 $order_status='completed'; 
        // $order_payment_method=$this->input->post('order_payment_method');
        // $order_final_bill=$this->input->post('order_final_bill'); 
 $this->load->model('order_model');
 $recepient_email=$this->order_model->getOrderAll($orderId)->order_email;
 $recepient_name=$this->order_model->getOrderAll($orderId)->customer_fname;
 $order_pharm_name=$this->order_model->getPharmAll($order_pharm_id)->pharm_name;
 $order_mobile=$this->order_model->getOrderAll($orderId)->order_mobile;
 $customer_lname=$this->order_model->getOrderAll($orderId)->customer_lname;
 $order_address1=$this->order_model->getOrderAll($orderId)->order_address1;
 $order_address2=$this->order_model->getOrderAll($orderId)->order_address2;
 $order_address3=$this->order_model->getOrderAll($orderId)->order_address3;
    // $order_status='preparing';         
 $order_timesatmp= date('Y-m-d H:i:s');




 if($this->order_model->updateOrderStatus($orderId,$order_status,$order_timesatmp)){
  $this->session->set_flashdata('msg','You have successfully delivered your package! Thank you for working with OMDP');
              // send Email


  $subject = "Order Complete Mail";
  $message = "
  <br>
  <p>Dear ".$recepient_name.",</p>
  <p>Thank you for using OMDP to buy your Pharamacy Items!</p>.The order has been". $order_status ." delivered from  ".$order_pharm_name." . Stay healthy and stay safe.</p>
  <br>    
  <div class=\"table-responsive\">
  <table class=\"table table-bordered\">
  <tr>
  <th>Order Id</th>
  <td>".$orderId."</td>
  </tr>
  <tr>
  <th>Order updated on</th>
  <td>".$order_timesatmp."</td>
  </tr>
  <tr>
  <th>Pharmacy Name</th>
  <td>".$order_pharm_name."</td>
  </tr>
  <tr>
  <th>Order Status</th>
  <td><b>".$order_status."</b></td>
  </tr>
  </table>
  </div>

  <br>
  <p>Best Regards,</p>
  <p>OMDP Team</p>
  ";


          // send Email
  $this->sendEmail($recepient_email,$subject,$message);
              // destroy shopping cart
      // $this->load->library("cart");
      // $this->cart->destroy();
  $data['orderId']=$orderId;
  $data['order_pharm_id']=$order_pharm_id;
  $data['recepient_email']=$recepient_email;
  $data['recepient_name']=$recepient_name;
  $data['order_mobile']=$order_mobile;
  $data['customer_lname']=$customer_lname;
  $data['order_address1']=$order_address1;
  $data['order_address2']=$order_address2;
  $data['order_address3']=$order_address3;
  $data['order_status']=$this->order_model->getOrderAll($orderId)->order_status;
      // $this->load->view("driver_page",$data);




      // $this->load->view("driver_page",$data);
      // $deliver_link=base_url()."order_controller/accept_package/".$orderId."/".$order_pharm_id;

      // send delivery mail
      // $this->sendEmail('ddamasean@gmail.com',"Please deliver the order ".$orderId." below ",$deliver_link);

  return redirect('order_controller/load_driver_completed/'.$orderId.'/'.$order_pharm_id);
  var_dump($this->session->flashdata('msg'));
      // return redirect('order_controller/accept_package/'.$orderId.'/'.$order_pharm_id,'refresh');
}
else
{
  $this->session->set_flashdata('msg','Failed to accept order');
}
    // return redirect('','refresh');
    // return redirect('order_controller/accept_package/'.$orderId.'/'.$order_pharm_id);



}

  // email function
public function sendEmail($recepient_email,$subject,$message){

 $config['protocol']    = 'smtp';
 $config['smtp_host']    = 'ssl://smtp.googlemail.com';
 $config['smtp_port']    = '465';
 $config['smtp_timeout'] = '7';
 $config['smtp_user']    = 'dulan.dam@gmail.com';
 $config['smtp_pass']    = '92.12.04';
 $config['charset']    = 'utf-8';
 $config['newline']    = "\r\n";
    $config['mailtype'] = 'html'; // or html
    $config['validation'] = TRUE; // bool whether to validate email or not  

    $this->load->library('email', $config);
    $this->email->set_newline("\r\n");
    $this->email->from('dulan.dam@gmail.com');
    // $this->email->to($this->input->post('user_email'));
    // $this->email->to($recepient_email);
    $this->email->to($recepient_email);
    $this->email->subject($subject);
    $this->email->message($message);
    $this->email->send();
    // if($this->email->send())

  }


  public function testEmail(){
    $this->load->view("testMail");
  }

  public function get_current_order(){
    $data['customerId']=$this->uri->segment(3);
    $this->load->view('current_orders',$data);
  }


// get onging prescription customer   get_reviewing_order
  public function get_reviewing_prescription(){
    $data['customerId']=$this->uri->segment(3);
    $this->load->view('reviewing_prescription',$data);
  }


  // get approved prescriptions get_approved_prescription
  public function get_approved_prescription(){
    $data['customerId']=$this->uri->segment(3);
    $this->load->view('approved_prescription',$data);
  }

  public function get_submitted_order(){
    $data['customerId']=$this->uri->segment(3);
    $this->load->view('submitted_orders',$data);
  }

  public function get_current_order_pharm(){
    $data['pharm_id']=$this->uri->segment(3);
    $this->load->view('current_orders_pharm',$data);
  }

// view incoming prescription_name
  public function get_incoming_pres_pharm(){
    $data['pharm_id']=$this->uri->segment(3);
    $this->load->view('incoming_presc_pharm',$data);
  }


// get_ongoing_order_pharm
  public function get_ongoing_order_pharm(){
    $data['pharm_id']=$this->uri->segment(3);
    $this->load->view('ongoing_orders_pharm',$data);
  }


  // get_ongoing_prescriptions_pharm
  public function get_ongiong_pres_pharm(){
    $data['pharm_id']=$this->uri->segment(3);
    $this->load->view('ongoing_prescription_pharm',$data);
  }





  // get_dispatched_order
  public function get_dispatched_order(){
    $data['customerId']=$this->uri->segment(3);
    $this->load->view('dispatched_orders',$data);
  }

  public function get_current_count(){
    $this->load->model('order_model');
    $customerId=$this->uri->segment(3);    
    $totalPending= $this->order_model->curr_order_count($customerId);
    echo $totalPending;
  }


  // get submitted prescriptions
  public function get_submit_presc_count(){
    $this->load->model('order_model');
    $customerId=$this->uri->segment(3);    
    $totalPending= $this->order_model->submit_pres_count($customerId);
    echo $totalPending;
  }


  // get approved prescription count get_approve_presc_count
  public function get_approve_presc_count(){
    $this->load->model('order_model');
    $customerId=$this->uri->segment(3);    
    $totalPending= $this->order_model->approve_pres_count($customerId);
    echo $totalPending;
  }


  // get reviewing prescription count  get_review_presc_count
  public function get_review_presc_count(){
    $this->load->model('order_model');
    $customerId=$this->uri->segment(3);    
    $totalPending= $this->order_model->review_pres_count($customerId);
    echo $totalPending;
  }





// get_dispatch_count
  public function get_dispatch_count(){
    $this->load->model('order_model');
    $customerId=$this->uri->segment(3);    
    $totalPending= $this->order_model->dispatch_order_count($customerId);
    echo $totalPending;
  }


  public function get_current_count_pharm(){
    $this->load->model('order_model');
    $pharm_id=$this->uri->segment(3);    
    $totalPending= $this->order_model->curr_order_count_pharm($pharm_id);
    echo $totalPending;
  }

  // get prescription pending count
  public function get_incoming_pres_count_pharm(){
    $this->load->model('order_model');
    $pharm_id=$this->uri->segment(3);    
    $totalPending= $this->order_model->curr_pres_count_pharm($pharm_id);
    echo $totalPending;
  }




  // get reviewing prescription count pharm  get_reviewing_pres_count_pharm
  public function get_reviewing_pres_count_pharm(){
    $this->load->model('order_model');
    $pharm_id=$this->uri->segment(3);    
    $totalPending= $this->order_model->review_pres_count_pharm($pharm_id);
    echo $totalPending;
  }


// get_ongoing_count_pharm

  public function get_ongoing_count_pharm(){
    $this->load->model('order_model');
    $pharm_id=$this->uri->segment(3);    
    $totalPending= $this->order_model->ongoing_order_count_pharm($pharm_id);
    echo $totalPending;
  }


// fetch current orders customer
  public function fetch_current_order(){
    $output = '';
            // $query = '';
    $customerId=$this->uri->segment(3);
    $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
    $data=$this->order_model->fetch_current_order($customerId);
    $output .= '
    <div class="table-responsive">
    <table class="table table-bordered table-striped">
    <tr>
    <th>Order Id</th>
    <th>Pharmacy Name</th>
    <th>Payment Method</th>
    <th>Total Value (LKR)</th>
    <th>Created On</th>
    <th>Status</th>
    </tr>
    ';
    if ($data->num_rows()>0) {
      # code...
      foreach($data->result() as $row)
      {
        $output .= '
        <tr>
        <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
        <td>'.$row->pharm_name.'</td>
        <td>'.$row->order_payment_method.'</td>
        <td>'.$row->order_final_bill.'</td>                   
        <td>'.$row->order_timesatmp.'</td>
        <td> <a href="javascript:void(0)" class="bg-warning ">'.$row->order_status.'</a> </td>
        </tr>
        ';
      }
    }else{
      $output .= '<tr>
      <td colspan="5">Sorry No Data Found</td>
      </tr>';
    }
    $output .= '</table>';
    echo $output;

  }



  // fetch reviewing prescriptions
  public function fetch_reviewing_prescription(){
    $output = '';
            // $query = '';
    $customerId=$this->uri->segment(3);
    $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
    $data=$this->order_model->fetch_reviewing_presc($customerId);
    $output .= '
    <div class="table-responsive">
    <table class="table table-bordered table-striped">
    <tr>
    <th>Order Id</th>
    <th>Pharmacy Name</th>
    <th>Payment Method</th>
    <th>Prescription Name</th>
    <th>Submitted On</th>
    <th>Status</th>
    <th>Action</th>
    </tr>
    ';
    if ($data->num_rows()>0) {
      # code...

      foreach($data->result() as $row)
      {
        $output .= '
        <tr>
        <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
        <td>'.$row->pharm_name.'</td>
        <td>'.$row->order_payment_method.'</td>
        <td>'.$row->prescription_name.'</td>                   
        <td>'.$row->order_timesatmp.'</td>
        <td> <a href="javascript:void(0)" class="bg-danger text-white">'.$row->order_status.'</a> </td>
        <td><a href="" class="bg-info text-white">None</a></td>
        </tr>
        ';
      }
    }else{
      $output .= '<tr>
      <td colspan="5">Sorry No Data Found</td>
      </tr>';
    }
    $output .= '</table>';
    echo $output;

  }




  // fetch approved prescriptions customer
  public function fetch_approved_prescription(){
    $output = '';
            // $query = '';
    $customerId=$this->uri->segment(3);
    $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
    $data=$this->order_model->fetch_approved_presc($customerId);
    $output .= '
    <div class="table-responsive">
    <table class="table table-bordered table-striped">
    <tr>
    <th>Order Id</th>
    <th>Pharmacy Name</th>
    <th>Payment Method</th>
    <th>Prescription Name</th>
    <th>Submitted On</th>
    <th>Status</th>
    <th>View Quote</th>
    <th>Action</th>
    </tr>
    ';
    if ($data->num_rows()>0) {
      # code...

      foreach($data->result() as $row)
      {
        $output .= '
        <tr>
        <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
        <td>'.$row->pharm_name.'</td>
        <td>'.$row->order_payment_method.'</td>
        <td>'.$row->prescription_name.'</td>                   
        <td>'.$row->order_timesatmp.'</td>
        <td> <a href="javascript:void(0)" class="bg-warning ">'.$row->order_status.'</a> </td>
        <td><a href="javascript:void(0)" onclick="openCustomerDialog('.$row->orderId.')" class="bg-info text-white">view</a></td>      
        <td><a href="javascript:void(0)" onclick="proceedOrder('.$row->orderId.','.$row->order_pharm_id.')" class="bg-success text-white">Accept</a>   <a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'RejectOrder/'.$row->order_pharm_id.'\')" class="bg-danger text-white">Reject</a></td>
        </tr>
        ';
      }
    }else{
      $output .= '<tr>
      <td colspan="5">Sorry No Data Found</td>
      </tr>';
    }
    $output .= '</table>';
    echo $output;

  }



//load all order details
  public function fetch_modal_quote_prescription(){
    $output = '';
            // $query = '';
    $orderId=$this->input->post('orderId');
    $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }

    $query=$this->order_model->getOrderAlltoTray($orderId);
    $data=$this->order_model->fetch_all_order_presc_pharm($orderId);
    $output = '';
    $output .= '
    
    <div class="card-body">   
    <div class="table-responsive">
    <table id="modal_prescription_table" class="table table-bordered"  >
    <tr>
    <th colspan="3" text-align="left"><h4 class="header-title mb0">Quotation for : '.$data->prescription_name.' (Order Id)</h4> </th>
    
    <td><h4 class="header-title mb0"><b><i><span class="modal_prescription_orderid" >'.$orderId.'</i></b></h4></td>
    </tr>
    <tr>
    <th class="col-sm-1">Item Id</th>
    <th class="col-sm-3">Item Name</th>
    <th class="col-sm-1"> Item Quantity</th>
    <th class="col-sm-2">Sub Total Value (LKR)</th>   
    </tr>


    

    ';
    // $count = 0;
    // foreach($this->cart->contents() as $items)
    if ($query->num_rows()>0) {
      foreach ($query->result() as $row)
      {
     // $count++;
       $output .= '
       <tr> 
       <td>'.$row->med_item_id.'</td>
       <td>'.$row->med_item_name.'</td>
       <td>'.$row->order_item_quantity.'</td>
       <td>'.$row->order_item_subtotal.'</td>
       
       </tr>
       ';
     }
   }else{
    $output .= '<tr>
    <td colspan="4">Sorry No Data Found</td>
    </tr>';
  }

  $output .= '
  <tr>
  <th colspan="3" text-align="left"><h4 class="header-title mb0">Total  Value</h4> </th>

  <td><h4 class="header-title mb0"><b><i>'.$data->order_final_bill.'</i></b></h4></td>
  </tr>
  <tr>
  <th colspan="4" text-align="left"><h4 class="header-title mb0">Pharmacy Comments</h4> </th>
  </tr>
  <tr>
  <td colspan="4">'.$data->prescription_pharm_comment.'  </td>
  </tr>
  </table>
  </div>
  </div>  
  ';





   // if($count == 0)
   // {
   //   $output = '<h3 align="center">Cart is Empty</h3>';
   // }
  echo $output;

}


 // fetch prescription incoming to modal 
public function fetch_modal_view_prescription(){
  $output = '';
            // $query = '';
  $orderId=$this->input->post('orderId');
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }

  $query=$this->order_model->getOrderAlltoTray($orderId);
  $data=$this->order_model->fetch_all_order_presc_pharm($orderId);
  $output = '';
  $output .= '
  <div class="card-body">   
  <div class="table-responsive">
  <table id="modal_prescription_table" class="table table-bordered " >
  <tr>
  <th><h4 class="header-title mb0">Image</h4> </th>
  </tr>
  <tr>
  <td><div class="col-sm-6 clearfix" align="center"> 
  <img  class="mv-icon"  src="'.$data->prescription_image.'">
  </div></td>  
  </tr>
  <th><h4 class="header-title mb0">Customer Comments</h4> </th>
  <tr>
  </tr>
  <td>'.$data->order_comments.'</td>
  <tr>

  </tr>




  ';
    // $count = 0;
 
$output .= '
</table>
</div>
</div>  
';





   // if($count == 0)
   // {
   //   $output = '<h3 align="center">Cart is Empty</h3>';
   // }
echo $output;

}


// fetch_modal_incoming_order_pharm  view orders incoming modal
public function fetch_modal_incoming_order_pharm(){
  $output = '';
            // $query = '';
    $orderId=$this->input->post('orderId');
    $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }

    $query=$this->order_model->getOrderAlltoTray($orderId);
    $data=$this->order_model->getOrderAllNew($orderId);
    $output = '';
    $output .= '
    
    <div class="card-body">   
    <div class="table-responsive">
    <table id="modal_prescription_table" class="table table-bordered"  >
    <tr>
    <th colspan="3" text-align="left"><h4 class="header-title mb0">Quotation for :  (Order Id)</h4> </th>
    
    <td><h4 class="header-title mb0"><b><i><span class="modal_prescription_orderid" >'.$orderId.'</i></b></h4></td>
    </tr>
    <tr>
    <th class="col-sm-1">Item Id</th>
    <th class="col-sm-3">Item Name</th>
    <th class="col-sm-1"> Item Quantity</th>
    <th class="col-sm-2">Sub Total Value (LKR)</th>   
    </tr>


    

    ';
    // $count = 0;
    // foreach($this->cart->contents() as $items)
    if ($query->num_rows()>0) {
      foreach ($query->result() as $row)
      {
     // $count++;
       $output .= '
       <tr> 
       <td>'.$row->med_item_id.'</td>
       <td>'.$row->med_item_name.'</td>
       <td>'.$row->order_item_quantity.'</td>
       <td>'.$row->order_item_subtotal.'</td>
       
       </tr>
       ';
     }
   }else{
    $output .= '<tr>
    <td colspan="4">Sorry No Data Found</td>
    </tr>';
  }

  $output .= '
  <tr>
  <th colspan="3" text-align="left"><h4 class="header-title mb0">Total  Value</h4> </th>

  <td><h4 class="header-title mb0"><b><i>'.$data->order_final_bill.'</i></b></h4></td>
  </tr>
  <tr>
  <th colspan="4" text-align="left"><h4 class="header-title mb0">Customer Comments</h4> </th>
  </tr>
  <tr>
  <td colspan="4">'.$data->order_comments.'  </td>
  </tr>
  </table>
  </div>
  </div>  
  ';





   // if($count == 0)
   // {
   //   $output = '<h3 align="center">Cart is Empty</h3>';
   // }
  echo $output;

}

// fetch item information fetch_modal_item_description
public function fetch_modal_item_description(){
  $output = '';
            // $query = '';
  $med_item_id=$this->input->post('med_item_id');
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }

  // $query=$this->order_model->getOrderAlltoTray($orderId);
  $data=$this->order_model->fetch_all_modal_item_desc($med_item_id);

  $stock=$data->med_stock;
  
  // return $stock;
  

  $output = '';
  $output .= '
  <div class="card-body">   
  <div class="table-responsive">
  <table id="modal_prescription_table" class="table table-bordered " width="80%"  >
  <col style="width:30%">
  <col style="width:50%">
  <tr>
  </tr>
  <tr>
  <th colspan="2"><h4 class="header-title mb0">'.$data->med_item_name.'</h4> </th>
  </tr>
  <tr>
  <td colspan="2"><div class="col-sm-4 clearfix" align="center"> 
  <img  class="mv-icon"  src="'.$data->med_item_image.'">
  </div></td>  
  </tr>
  <tr>
  <th>Product Brand </th>
  <td>'.$data->med_item_brand.'</td>
  <tr>
  </tr>
  <th>Product Spec</th>
  <td>'.$data->med_item_spec.'</td>
  <tr>
  </tr>
  <th>Price </th>
  <td><p class="text-danger"><b>LKR '.$data->med_unit_price.'</b></p></td>
  <tr>
  <tr>
  <th>Sold By </th>
  <td><p class="text-primary"><b> '.$data->pharm_name.'</b></p></td>
  </tr>
  <tr>
   <th>Description</th>
  <td><b> '.$data->med_comments.'</b></td>
  </tr>
  <tr>
   <th>Date of Manufacture </th>
  <td> '.$data->med_manufact_date.'</td>
  </tr>
  <tr>
   <th>Date of Expiry </th>
  <td> '.$data->med_exp_date.'</td>
  </tr>
  <tr> <th>Availabilty</th>    
  ';

   if ($stock == 0){
    $output.="<td><h4><p class=\"text-danger\"><b>Out of Stock</b></p></h4></td>";
   }elseif($stock > 0 and $stock <=10 ) {
     # code...
    $output.="<td><h4><p class=\"text-warning\"><b>Fewer Items</b></p><h4></td>";
   }
   else{
    $output.="<td><h4><p class=\"text-success\"><b>Available</b></p><h4></td>";
   }

    // $count = 0;
   
 
$output .= '</tr>
</table>
</div>
</div>  
';


 // if($count == 0)
   // {
   //   $output = '<h3 align="center">Cart is Empty</h3>';
   // }
echo $output;

}


// fetch items for pharmacist fetch_modal_item_descr-






// fetch submitted prescription
public function fetch_submitted_order(){
  $output = '';
            // $query = '';
  $customerId=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_submitted_order($customerId);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Prescription Name</th>
  <th>Submitted On</th>
  <th>Status</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...

    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->prescription_name.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td> <a href="javascript:void(0)" class="bg-info text-white ">'.$row->order_status.'</a> </td>
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}


//get dispatched orders
public function fetch_dispatched_order(){
  $output = '';
            // $query = '';
  $customerId=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_dispatched_order($customerId);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Total Value (LKR)</th>
  <th>Created On</th>
  <th>Status</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->order_final_bill.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td> <a href="javascript:void(0)" class="bg-info text-white">'.$row->order_status.'</a> </td>
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}

// get pharmacy incoming orders
public function fetch_current_order_pharm(){
  $output = '';
            // $query = '';
  $pharm_id=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_incoming_order_pharm($pharm_id);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Total Value (LKR)</th>
  <th>Created On</th>
  <th>Status</th>
  <th>View</th>
  <th>Action</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->order_pharm_id.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->order_final_bill.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td> <a href="javascript:void(0)" class="bg-warning ">'.$row->order_status.'</a> </td>
      <td><a href="javascript:void(0)" onclick="checkItemsDialogOrderPharm('.$row->orderId.')" class="bg-info text-white">View</a> </td>
      <td>
      <a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\''.base_url().'order_controller/AcceptOrder/'.$row->orderId.'/'.$row->order_pharm_id.'\')" class="bg-success text-white">Accept</a>      <a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'RejectOrder/'.$row->order_pharm_id.'\')" class="bg-danger text-white">Reject</a></td> 
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}

//fetch_incoming_pres_pharm fetch incmoing prescription to pharmacy
public function fetch_incoming_pres_pharm(){
  $output = '';
            // $query = '';
  $pharm_id=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_incoming_presc_pharm($pharm_id);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Prescription Id</th>
  <th>Created On</th>
  <th>Comments</th>
  <th>Status</th>
  <th>View</th>
  <th>Action</th>
  </tr>
  ';  
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->prescription_id.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td>'.$row->order_comments.'</td>
      <td> <a href="javascript:void(0)" class="bg-warning ">'.$row->order_status.'</a> </td>
      <td> <a href="javascript:void(0)" onclick="viewPrescriptionDialogBox('.$row->orderId.')"class="bg-info text-white">View</a> </td>
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\''.base_url().'order_controller/AcceptPres/'.$row->orderId.'/'.$row->order_pharm_id.'\')" class="bg-success text-white">Accept</a>      <a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'RejectPres/'.$row->order_pharm_id.'\')" class="bg-danger text-white">Reject</a></td> 
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}


// fetch_current_ongoing_pharm
public function fetch_current_ongoing_pharm(){
  $output = '';
            // $query = '';
  $pharm_id=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_ongoing_order_pharm($pharm_id);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Total Value (LKR)</th>
  <th>Created On</th>
  <th>Status</th>
  <th>Action</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->order_pharm_id.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->order_final_bill.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td> <a href="javascript:void(0)" class="bg-warning ">'.$row->order_status.'</a> </td>
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\''.base_url().'order_controller/load_order_tray/'.$row->orderId.'/'.$row->order_pharm_id.'\')" class="bg-primary text-white">Start Preparing</a></td> 
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}


// fetch_current_dispatched order user

// fetch ongoing prescriptions  fetch_prescription_ongoing_pharm
public function fetch_prescription_ongoing_pharm(){
  $output = '';
            // $query = '';
  $pharm_id=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_ongoing_presc_pharm($pharm_id);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Prescription Id</th>
  <th>Created On</th>
  <th>Comments</th>
  <th>Status</th>
  <th>Action</th>
  </tr>
  ';  
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td><a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->prescription_id.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td>'.$row->order_comments.'</td>
      <td> <a href="javascript:void(0)" class="bg-danger text-white">'.$row->order_status.'</a> </td>
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\''.base_url().'order_controller/load_presc_tray/'.$row->orderId.'/'.$row->order_pharm_id.'\')" class="bg-success text-white">Start reviewing</a> 
      </td> 
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}



// live fetch items pharmacy
public function fetch_new_items()
{
        // redirect('user_controller/landing_page');
  $this->load->model('order_model');
  $pharm_id=$this->uri->segment(3);

  // if ($data -> result()->num_rows() > 0){
  if($this->input->post('query')){
    $query=$this->input->post('query');
  }
  $data=$this->order_model->fetch_live_data($query,$pharm_id);
  $this->load->view('list_items',['data'=>$data]);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


}




  // live fetch items pharmacy tray
public function fetch_new_items_tray()
{
        // redirect('user_controller/landing_page');
  $this->load->model('order_model');
  $pharm_id=$this->uri->segment(3);

  // if ($data -> result()->num_rows() > 0){
  if($this->input->post('query')){
    $query=$this->input->post('query');
  }
  $data=$this->order_model->fetch_live_data($query,$pharm_id);
  $this->load->view('list_items_tray',['data'=>$data]);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


}


 // live fetch items prescription tray


  // get_completed_order

public function get_completed_order(){
  $data['customerId']=$this->uri->segment(3);
  $this->load->view('completed_orders',$data);
}

// list completed orders of pharmacy
public function get_completed_order_pharm(){
  $data['pharm_id']=$this->uri->segment(3);
  $this->load->view('completed_orders_pharm',$data);
}





public function fetch_completed_order(){
  $output = '';
            // $query = '';
  $customerId=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_completed_order($customerId);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Total Value (LKR)</th>
  <th>Created On</th>
  <th>Status</th>
  <th>Action</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td> <a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->pharm_name.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->order_final_bill.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td> <a href="javascript:void(0)" class="bg-success text-white">'.$row->order_status.'</a> </td>
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'edit_pharm/'.$row->orderId.'\')" class="bg-primary text-white">View </a></td> 
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}


public function fetch_completed_order_pharm(){
  $output = '';
            // $query = '';
  $pharm_id=$this->uri->segment(3);
  $this->load->model('order_model');
            // if($this->input->post('query')){
            //   $query=$this->input->post('query');
            // }
  $data=$this->order_model->fetch_completed_order_pharm($pharm_id);
  $output .= '
  <div class="table-responsive">
  <table class="table table-bordered table-striped">
  <tr>
  <th>Order Id</th>
  <th>Pharmacy Name</th>
  <th>Payment Method</th>
  <th>Total Value (LKR)</th>
  <th>Created On</th>
  <th>Status</th>
  <th>Action</th>
  </tr>
  ';
  if ($data->num_rows()>0) {
      # code...
    foreach($data->result() as $row)
    {
      $output .= '
      <tr>
      <td> <a href="javascript:void(0)" class="bg-primary text-white">'.$row->orderId.'</a></td>
      <td>'.$row->order_pharm_id.'</td>
      <td>'.$row->order_payment_method.'</td>
      <td>'.$row->order_final_bill.'</td>                   
      <td>'.$row->order_timesatmp.'</td>
      <td> <a href="javascript:void(0)" class="bg-success text-white">'.$row->order_status.'</a> </td>
      <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'edit_pharm/'.$row->order_pharm_id.'\')" class="bg-primary text-white">View </a></td> 
      </tr>
      ';
    }
  }else{
    $output .= '<tr>
    <td colspan="5">Sorry No Data Found</td>
    </tr>';
  }
  $output .= '</table>';
  echo $output;

}


//go to cashier order tray to prepare order
public function load_order_tray(){
  $data['orderId']=$this->uri->segment(3);
  $data['pharm_id']=$this->uri->segment(4);
      // $this->load->model('order_model');
      // $data['query']=$this->order_model->getOrderAlltoTray($this->uri->segment(3));
      // $query=$this->order_model->getOrderAlltoTray($this->uri->segment(3));
      // $data['$query']=json_decode($query,TRUE);
  $this->load->view('cashier_order_tray',$data);
      // $this->load->view('cashier_order_tray',$data);
}


// load prescription tray
  //go to cashier order tray to prepare order
public function load_presc_tray(){
  $orderId=$this->uri->segment(3);
    // fetch_all_order_presc_pharm
  $this->load->model('order_model');
  $data['orderId']=$orderId;
  $data['prescription_id']=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_id;
  $data['pharm_id']=$this->uri->segment(4);
  $data['prescription_image']=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_image;
  $data['prescription_comments']=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_comments;
  $data['prescription_urgency']=$this->order_model->fetch_all_order_presc_pharm($orderId)->prescription_urgency;
      // $this->load->model('order_model');
      // $data['query']=$this->order_model->getOrderAlltoTray($this->uri->segment(3));
      // $query=$this->order_model->getOrderAlltoTray($this->uri->segment(3));
      // $data['$query']=json_decode($query,TRUE);
  $this->load->view('cashier_prescription_tray',$data);
      // $this->load->view('cashier_order_tray',$data);
}

// // load_items_to_tray
public function load_tray(){ 
    // $this->load->library("cart");
  $orderId=$this->uri->segment(3);
  $this->load->model('order_model');
  $query=$this->order_model->getOrderAlltoTray($orderId);
  $output = '';
  $output .= '
  <div class="card-rounded" id="div_cart" >
  <div class="card-body">   
  <div class="table-responsive">
  <table class="table table-bordered ">
  <tr>
  <th colspan="4" text-align="left"><h4 class="header-title mb0">You are Processing Order Id</h4> </th>

  <td><h4 class="header-title mb0"><b><i>'.$orderId.'</i></b></h4></td>
  </tr>
  <tr>
  <th>Item Id</th>
  <th>Item Name</th>
  <th>Item Quantity</th>
  <th>Sub Total Value (LKR)</th>
  <th>Action</th>
  </tr>



  ';
    // $count = 0;
    // foreach($this->cart->contents() as $items)
  if ($query->num_rows()>0) {
    foreach ($query->result() as $row)
    {
     // $count++;
     $output .= '
     <tr> 
     <td>'.$row->med_item_id.'</td>
     <td>'.$row->med_item_name.'</td>
     <td>'.$row->order_item_quantity.'</td>
     <td>'.$row->order_item_subtotal.'</td>
     <td> None </td>
     </tr>
     ';
   }
 }else{
  $output .= '<tr>
  <td colspan="5">Sorry No Data Found</td>
  </tr>';
}

$output .= '
</table>
</div>
</div>
</div>
';

   // if($count == 0)
   // {
   //   $output = '<h3 align="center">Cart is Empty</h3>';
   // }
echo $output;
}


//load prescription to tray
public function load_tray_prescription(){ 
    // $this->load->library("cart");
  $orderId=$this->uri->segment(3);
  $this->load->model('order_model');
  $query=$this->order_model->getOrderAlltoTray($orderId);
  $output = '';
  $output .= '
  <div class="card-rounded" id="div_cart" >
  <div class="card-body">   
  <div class="table-responsive">
  <table class="table table-bordered ">
  <tr>
  <th colspan="4" text-align="left"><h4 class="header-title mb0">You are Processing Order Id</h4> </th>

  <td><h4 class="header-title mb0"><b><i>'.$orderId.'</i></b></h4></td>
  </tr>
  <tr>
  <th>Item Id</th>
  <th>Item Name</th>
  <th>Item Quantity</th>
  <th>Sub Total Value (LKR)</th>
  <th>Action</th>
  </tr>



  ';
    // $count = 0;
    // foreach($this->cart->contents() as $items)
  if ($query->num_rows()>0) {
    foreach ($query->result() as $row)
    {
     // $count++;
     $output .= '
     <tr> 
     <td>'.$row->med_item_id.'</td>
     <td>'.$row->med_item_name.'</td>
     <td>'.$row->order_item_quantity.'</td>
     <td>'.$row->order_item_subtotal.'</td>
     <td> None </td>
     </tr>
     ';
   }
 }else{
  $output .= '<tr>
  <td colspan="5">Sorry No Data Found</td>
  </tr>';
}

$output .= '
</table>
</div>
</div>
</div>
';

   // if($count == 0)
   // {
   //   $output = '<h3 align="center">Cart is Empty</h3>';
   // }
echo $output;
}

// load_all_pharamacies

public function load_all_pharamacies(){
  $this->load->model('order_model');
  $query=$this->order_model->getAllPharm();
              // $output='';
  $output='<select name="prescription_pharm_id" id="type">';
  if($query->num_rows()>0){
    foreach($query->result() as $row)
    {
      $output .='<option id="'.$row->pharm_id.'"value="'.$row->pharm_id.'">'.$row->pharm_name.'</option>';


    }
  }
  $output .= '</select>';
  echo $output;
}


// load prescription all
public function load_my_prescription(){
  $this->load->model('order_model');
  $userId=$this->input->post('userId');
  $query=$this->order_model->getMyPrescription($userId);
              // $output='';
  $output='<select name="prescription_id" id="precription_drop">';
  if($query->num_rows()>0){
    foreach($query->result() as $row)
    {
      $output .='<option id="'.$row->prescription_id.'"value="'.$row->prescription_id.'">'.$row->prescription_name.'</option>';


    }
  }
  $output .= '</select>';
  echo $output;
}


// AUTO FILL FORM prescription
public function auto_fill_prescription(){
  $this->load->model('order_model');
  $prescription_id=$this->input->post('prescription_id');
  $query=$this->order_model->getOnePrescription($prescription_id);

  // echo $query->num_rows();

  echo json_encode($query->row());

}



public function proceedPayment(){
  $orderId=rand(10,100000);
  // $order_email=$this->input->post('order_email');
  $this->load->model('shop_model');

      		// insert items into order table

  $orderData = array('orderId' =>  $orderId, 
            // 'customerId' =>  $userId,
    'customerId'=>$this->input->post('customerId'),
    'customer_fname'  => $this->input->post('customer_fname') ,
    'customer_lname'  => $this->input->post('customer_lname') ,  
            // 'pharmacy_id'  => $this->input->post('pharmacy_id') ,
    'order_email'  => $this->input->post('order_email') , 
    'order_mobile'  => $this->input->post('order_mobile') ,
    'order_total'  => $this->cart->total(),
    'order_address1'  => $this->input->post('order_address1'), 
    'order_address2'  => $this->input->post('order_address2'),
    'order_address3'  => $this->input->post('order_address3'),
    'order_status'  => "queued",
    'order_comments'  => $this->input->post('order_comments'),
    'order_landmarks'  => $this->input->post('order_landmarks') );


  if ($this->shop_model->add_order_table($orderData)) {
             // insert cart item into order item table 
   foreach ($this->cart->contents() as $items) {
     $data = array( 'orderId' => $orderId,
       'med_item_id' => $items["id"] ,
       'med_item_name' =>$items["name"] ,
       'pharm_id' => $items["options"]["pharm_id"],
       'order_item_quantity'=>$items["qty"],
       'order_item_subtotal'=> $items["subtotal"]);
                  // insert item to order item table
     $this->shop_model->add_order_item($data);


   }

         // get pharm id 
   $this->load->model('shop_model');

         // get currently created temp order id
   $pharm_id=$this->shop_model->getPharmfromOrder($orderId);
   // $order_email=$this->input->post('order_email');




   return redirect('order_controller/orderPaymentDetails/'.$orderId.'/'.$pharm_id.'/');
 }







      			# code...
}

// proceedPrescriptionRequest - get precription request
public function proceedPrescriptionRequest(){
  $orderId=rand(10,100000);
  // $order_email=$this->input->post('order_email');
  $this->load->model('shop_model');
  $this->load->model('user_model');
  $this->load->model('order_model');
  $customerId=$this->input->post('customerId');
  $customer_fname=$this->user_model->getUserEdit($customerId)->fName ;
  $customer_lname=$this->user_model->getUserEdit($customerId)->lName;
  $order_pharm_id=$this->input->post('prescription_pharm_id');
  $prescription_id=$this->input->post('prescription_id');
          // insert items into order table


  $orderData = array('orderId' =>  $orderId, 
    'customerId'=> $customerId,
    'customer_fname'  => $customer_fname,
    'customer_lname'  => $customer_lname,     
            // 'pharmacy_id'  => $this->input->post('pharmacy_id') ,
    'order_email'  => $this->input->post('order_email') , 
    // 'order_mobile'  => $this->input->post('order_mobile') ,  
    'is_prescription'  => 'Y',
    'order_address1'  => $this->input->post('order_address1'), 
    'order_address2'  => $this->input->post('order_address2'),
    'order_address3'  => $this->input->post('order_address3'),
    'order_status'  => "requested",
    'order_comments'  => $this->input->post('prescription_comments'),
    'prescription_id'  => $this->input->post('prescription_id'),
    'order_pharm_id'  => $order_pharm_id
  );


  if ($this->shop_model->add_order_table($orderData)) {
   //           // insert cart item into order item table 
   // foreach ($this->cart->contents() as $items) {
   $data = array( 'orderId' => $orderId,
    'prescription_id' => $this->input->post('prescription_id'),
    'prescription_pharm_id' => $this->input->post('prescription_pharm_id'),
    'prescription_comments'  => $this->input->post('prescription_comments'),
    'prescription_urgency'  => $this->input->post('prescription_urgency'),
    'prescription_image'=> $this->input->post('prescription_image')
   //     'med_item_name' =>$items["name"] ,
   //     'pharm_id' => $items["options"]["pharm_id"],
   //     'order_item_quantity'=>$items["qty"],
  );
   //                // insert item to order item table
   $this->shop_model->add_prescrip_table($data);


 }

 $data['orderId']=$orderId;
 $data['order_pharm_id']=$order_pharm_id;
 $data['customer_fname']=$customer_fname;
 $data['customer_lname']=$customer_lname;
 $data['prescription_pharm_name']=$this->order_model->getOrderAllNew($orderId)->pharm_name;
 $data['order_address1']=$this->order_model->getOrderAllNew($orderId)->order_address1;
 $data['order_address2']=$this->order_model->getOrderAllNew($orderId)->order_address2;
 $data['order_address3']=$this->order_model->getOrderAllNew($orderId)->order_address3;
 $data['prescription_comments']=$this->input->post('prescription_comments');
 $data['prescription_urgency']=$this->input->post('prescription_urgency');
 $data['prescription_image']=$this->input->post('prescription_image');

 $this->load->view('prescription_checkout',$data);


   //       // get pharm id 
   // $this->load->model('shop_model');

   //       // get currently created temp order id
   // $pharm_id=$this->shop_model->getPharmfromOrder($orderId);
   // $order_email=$this->input->post('order_email');




   // return redirect('order_controller/prescriptionCheckout/'.$orderId.'/'.$order_pharm_id.'/');
}









            # code...




// public function testOrder(){
//       $orderId=rand(10,100000);
//       $this->load->model('shop_model');
//       foreach ($this->cart->contents() as $items) {
//                $data = array( 'orderId' => $orderId,
//                  'med_item_id' => $items["id"] ,
//                  'med_item_name' =>$items["name"] ,
//                  'pharm_id' => $items["options"]["pharm_id"],
//                  'order_item_quantity'=>$items["qty"],
//                  'order_item_subtotal'=> $items["subtotal"]);
//                   // insert item to order item table
//                $this->shop_model->add_order_item($data);


//          }
// }




   // send order id to payment details page
public function orderPaymentDetails(){
  $orderId['orderId']=$this->uri->segment(3);
  $orderId['pharm_id']=$this->uri->segment(4);
      // $orderId['order_email']=$this->uri->segment(5);
  $this->load->view("orderPaymentDetails",$orderId);

}




// Shopping Cart functions
             // add to shopping cart

public function add_to_cart(){ 
  $data = array(
    'id' => $this->input->post('med_item_id'), 
    'name' => $this->input->post('med_item_name'), 
    'price' => $this->input->post('med_unit_price'), 
    'qty' => $this->input->post('quantity'),
    'options' => array('pharm_id' => $this->input->post('pharm_id'))

  );
                // returns a rowid
  $this->cart->insert($data);   
                // echo $this->show_cart(); 
  echo $this->view_cart();
}

public function load_cart(){
          // $userId=$this->uri->segment(3);
  echo $this->view_cart();
}


public function load_final_bill(){
          // $userId=$this->uri->segment(3);
  echo $this->view_bill();
}



             // view cart
public function view_cart(){ 
  $this->load->library("cart");
  $output = '';
  $output .= '
  <div class="card-header">
  <div class="row">
  <div class="col-sm-6"><h4 class="header-title mb0">My Cart</h4></div>
  <div class="col-sm-1"><button  type="button" id="clear_cart" class="btn btn-warning">Clear Cart</button></div>
  </div>
  </div>
  </div><div class="table-responsive">

  <br />
  <table id="shopping_cart_table" class="table table-bordered">
  <tr>         
  <th >Name</th>
  <th >Quantity</th>
  <th >Price</th>
  <th >Total</th>
  <th >Action</th>
  </tr>

  ';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
   $count++;
   $output .= '
   <tr> 
   <td>'.$items["name"].'</td>
   <td>'.$items["qty"].'</td>
   <td>'.$items["price"].'</td>
   <td>'.$items["subtotal"].'</td>
   <td id="'.$items["options"]["pharm_id"].'"><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$items["rowid"].'">Remove</button></td>
   </tr>
   ';
 }
 $output .= '
 <tr>
 <td colspan="3" align="right"><b>Total</b></td>
 <td id="cart_total"><span class="cart_total_span">'.$this->cart->total().'</td>
 <td id="finish_button_div"><a href="javascript:void(0)" onclick="finishProcess()" id="checkout_btn" class="btn btn-info btn-lg"><span class="glyphicon glyphicon-chevron-right"></span> Finish Processing</a></td>
 </tr>

 </table>
 </div>

 ';

 if($count == 0)
 {
   $output = '<h3 align="center">Cart is Empty</h3>';
 }
 return $output;
}

// load bill at checkout
public function view_bill(){ 
  $this->load->library("cart");
  $output = '';
  $output .= '
  <div class="card-header">
  <div class="row">
  <div class="col-sm-6"><h4 class="header-title mb0">My Invoice</h4></div>
  </div>
  </div>
  </div><div class="table-responsive" >

  <br />
  <table class="table table-bordered" id="invoice_table">
  <tr>         
  <th >Item</th>
  <th >Quantity</th>
  <th >Price</th>
  <th >Total</th> 
  </tr>

  ';
  $count = 0;
  foreach($this->cart->contents() as $items)
  {
   $count++;
   $output .= '
   <tr> 
   <td>'.$items["name"].'</td>
   <td>'.$items["qty"].'</td>
   <td>'.$items["price"].'</td>
   <td>'.$items["subtotal"].'</td>
   </tr>
   ';
 }
 $output .= '
 <tr>
 <td colspan="2" align="left"><b>Total</b></td>
 <td colspan="1" align="right"></td>
 <td id="item_total_charge">'.$this->cart->total().'</td>
 </tr>
 <tr>
 <td colspan="2" align="left"><b>Discounts</b></td>
 <td colspan="1" align="right">15%</td>
 <td id="discount_charge">0</td>
 </tr>
 <tr>
 <td colspan="2" align="left"><i>Shipping Charges</i></t
 d>
 <td colspan="1" id="setDelviery" align="right"></td>
 <td ><span class="delivery_charge">50</td>
 </tr>
 <tr>
 <td colspan="2" align="left"><i>Taxes</i></td>
 <td colspan="1" align="right"></td>
 <td id="tax_charge">0</td>
 </tr>
 <tr>
 <td colspan="2" align="left"><b>Final Total</b></td>
 <td colspan="1" align="right"></td>
 <td id="grant_total_charge"><b><i></i></b></td>
 </tr>
 <tr>
 <td colspan="2" align="left"><i>Payment Method</i></td>
 <td colspan="1" align="right"></td>
 <td id="payment_meth">0</td>
 </tr>
 <tr>
 <td colspan="4"><a href="javascript:void(0)" onclick="continueShopping()" id="continue_btn" class="btn btn-info btn-md" align="right"><span class="glyphicon glyphicon-chevron-right"></span> Continue Shopping
 </a></td>
 </tr>



 </table>
 </div>

 ';

 if($count == 0)
 {
   $output = '<h3 align="center">Cart is Empty</h3>';
 }
 return $output;
}




public function view_quote(){
  echo "Test test";
}

//remove item
public function remove_cart_item()
{
  $this->load->library("cart");
  $row_id = $_POST["row_id"];
  $data = array(
   'rowid'  => $row_id,
   'qty'  => 0
 );
  $this->cart->update($data);
  echo $this->view_cart();
}

//clear cart
public function clear_cart()
{
  $this->load->library("cart");
  $this->cart->destroy();
  echo $this->view_cart();
}


}









