  <?php  	defined('BASEPATH') OR exit('No direct script access allowed');

  class shop_controller extends CI_Controller {

    		/**
    		 * Index Page for this controller.
    		 *
    		 * Maps to the following URL
    		  		http://example.com/index.php/welcome
    		 *	- or -
    		 * 		http://example.com/index.php/welcome/index
    		 *	- or -
    		 * Since this controller is set as the default controller in
    		 * config/routes.php, it's displayed at http://example.com/
    		 *
    		 * So any other public methods not prefixed with an underscore will
    		 * map to /index.php/welcome/<method_name>
    		 * @see https://codeigniter.com/user_guide/general/urls.html
    		 */
        //       public function list_all_items()
        //       {
        // // redirect('user_controller/landing_page');
        //         $this->load->model('user_model');
        //         $data['query']=$this->user_model->getMedicItems();
        //         if ($data -> num_rows() > 0){
        //           $this->load->view('list_items',$data);
        //         }else{
        //           return "<pre>No items bro </pre>";
        //         }


        //       }

            //list all item
  //             public function list_all_items()
  //             {
  //       // redirect('user_controller/landing_page');
  //               $this->load->model('shop_model');
  //               $data=$this->shop_model->getMedicItems();
  // // if ($data -> result()->num_rows() > 0){
  //               $this->load->view('list_items',['data'=>$data]);
  // // }
  // // else{
  // //   return "<pre>No items bro </pre>";
  // }





              // cashier login

              public function  login()
              {
                $this->load->view('cashier_login');
              }




              // login as manager
              // Manager Home
              public function manager_login()
              {
     // $userType['userType']="Manager";
               $this->load->view('manager_login');
             }


// main page area manager
             public function main_inner_manager(){ 

             $data['userId']=$this->uri->segment(3);  
             $data['pharm_id']=$this->uri->segment(4);  
                      
              $this->load->view('main_inner_manager',$data);
            }


      // load items to delete manager
            public function del_med_items_manager(){  
              $data['med_pharmacy_id']=$this->uri->segment(3);            
              $this->load->view('del_med_items_manager',$data);
            }

      // load items to delete manager
            public function update_item_manager(){  
              $data['med_pharmacy_id']=$this->uri->segment(3);            
              $this->load->view('update_item_manager',$data);
            }

// fetch items to delete

            // fetch user for delete Live data
            public function fetch_items_del_manager(){

              $output = '';
              $query = '';
              $med_pharmacy_id=$this->uri->segment(3);
              $this->load->model('shop_model');
              if($this->input->post('query')){
                $query=$this->input->post('query');
              }
              $data=$this->shop_model->fetch_live_items($query,$med_pharmacy_id);
              $output .= '
              <div class="notify-text">Search Results in Inventory</div>
              <div class="table-responsive">
              <table class="table table-bordered table-striped">
              <tr>
              <th>Item Image</th>
              <th>Item Name</th>
              <th>Item Brand</th>
              <th>Item Type</th>
              <th>Item Specifcation</th>
              <th>Items in Inventory</th>
              <th>Unit Price</th>  
              <th>Action</th>

              </tr>
              ';
              if ($data->num_rows()>0) {
      # code...
                foreach($data->result() as $row)
                {
                  $output .= '
                  <tr>
                  <td><img  class="mv-icon" src="'.$row->med_item_image.'"></td>
                  <td>'.$row->med_item_name.'</td>
                  <td>'.$row->med_item_brand.'</td>
                  <td>'.$row->med_item_type.'</td>
                  <td>'.$row->med_item_spec.'</td>                   
                  <td>'.$row->med_stock.'</td>
                  <td> LKR '.$row->med_unit_price.'</td>
                  <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'manager_user_del/'.$row->med_item_id.'/'.$med_pharmacy_id.'\')" class="bg-danger text-white">Delete</a></td> 

                  </tr>
                  ';
                }
              }else{
                $output .= '<tr>
                <td colspan="5">Sorry No Data Found</td>
                </tr>';
              }
              $output .= '</table>';
              echo $output;



            }


  // delete med items admin_controller
              // Remove user in admin module
            public function manager_user_del($med_item_id){
              $this->load->model('shop_model');
              $med_pharmacy_id=$this->uri->segment(4);
              if($this->shop_model->removeItemMgr($med_item_id))
              {

                $this->session->set_flashdata('msg','Inventory Item  Deleted Successfully!');

              }
              else{

                $this->session->set_flashdata('msg','Inventory Item Delete Failed!');

              } 
              return redirect('shop_controller/del_med_items_manager/'.$med_pharmacy_id);  
            }


// load item categories in add inventory

            public function load_type_item(){
              $this->load->model('shop_model');
              $query=$this->shop_model->getItemType();
              // $output='';
              $output='<select name="med_item_type" id="type">';
              if($query->num_rows()>0){
                foreach($query->result() as $row)
                {
                  $output .='<option id="'.$row->type_id.'"value="'.$row->type_name.'">'.$row->type_name.'</option>';


                }
              }
              $output .= '</select>';
              echo $output;
            }

  // load shopping cart

            // current_order
            public function current_order(){
              $this->load->view('shopping_cart');

            }


//load item subtype
            public function load_subtype_item(){
              $this->load->model('shop_model');
              $type_name=$this->input->post('itemType');
              $query=$this->shop_model->getItemsubType($type_name);
              // $output='';
              $output='<select name="med_item_subtype" id="type">';
              if($query->num_rows()>0){
                foreach($query->result() as $row)
                {
                  $output .='<option id="'.$row->subtype_id.'"value="'.$row->subtype_name.'">'.$row->subtype_name.'</option>';


                }
              }
              $output .= '</select>';
              echo $output;
            }


// list items by categories
            public function list_all_items()
            {
        // redirect('user_controller/landing_page');
              $this->load->model('shop_model');
              $data=$this->shop_model->getMedicItems();
  // if ($data -> result()->num_rows() > 0){
              $this->load->view('list_items',['data'=>$data]);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


            }




            //upload and save precriptions to system
            public function save_prescription()
            {

              $data['prescription_uid']=$this->uri->segment(3);              
              $this->load->view('save_prescription',$data);



            }


                        //upload and save precriptions to system
            public function remove_prescription()
            {

              $data['prescription_uid']=$this->uri->segment(3);              
              $this->load->view('del_prescription',$data);



            }


  // upload prescription to order
                        //upload and save precriptions to system
            public function upload_prescription()
            {
        // redirect('user_controller/landing_page');
              $this->load->model('shop_model');
              
  // if ($data -> result()->num_rows() > 0){
              $data['userId']=$this->uri->segment(3);
              $this->load->view('save_prescription_direct',$data);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


            }



            // list item types

            public function list_type_items()
            {
        // redirect('user_controller/landing_page');
              $this->load->model('shop_model');
              $med_item_type=urldecode($this->uri->segment(3));
              // $med_item_subtype=$this->uri->segment(4);
              $data=$this->shop_model->getTypeofItems($med_item_type);
  // if ($data -> result()->num_rows() > 0){
              $this->load->view('list_items',['data'=>$data]);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


            }



            // update manager 'list

                      // fetch user for delete Live data
            public function fetch_items_mod_manager(){

              $output = '';
              $query = '';
              $med_pharmacy_id=$this->uri->segment(3);
              $this->load->model('shop_model');
              if($this->input->post('query')){
                $query=$this->input->post('query');
              }
              $data=$this->shop_model->fetch_live_items($query,$med_pharmacy_id);
              $output .= '
              <div class="notify-text">Search Results in Inventory</div>
              <div class="table-responsive">
              <table class="table table-bordered table-striped">
              <tr>
              <th>Item Image</th>
              <th>Item Name</th>
              <th>Item Brand</th>
              <th>Item Type</th>
              <th>Item Specifcation</th>
              <th>Items in Inventory</th>
              <th>Unit Price</th>  
              <th>Action</th>

              </tr>
              ';
              if ($data->num_rows()>0) {
      # code...
                foreach($data->result() as $row)
                {
                  $output .= '
                  <tr>
                  <td><img  class="mv-icon" src="'.$row->med_item_image.'"></td>
                  <td>'.$row->med_item_name.'</td>
                  <td>'.$row->med_item_brand.'</td>
                  <td>'.$row->med_item_type.'</td>
                  <td>'.$row->med_item_spec.'</td>                   
                  <td>'.$row->med_stock.'</td>
                  <td> LKR '.$row->med_unit_price.'</td>
                  <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\'manager_item_edit/'.$row->med_item_id.'/'.$med_pharmacy_id.'\')" class="bg-success text-white">Modify</a></td> 

                  </tr>
                  ';
                }
              }else{
                $output .= '<tr>
                <td colspan="5">Sorry No Data Found</td>
                </tr>';
              }
              $output .= '</table>';
              echo $output;



            }


// fetch user data to update form in admin module
            public function manager_item_edit(){
              $this->load->model('shop_model');
              $med_pharmacy_id=$this->uri->segment(4);
              $data=$this->shop_model->getItemEdit($this->uri->segment(3));
              $this->load->view('modify_item',['data'=>$data,'med_pharmacy_id'=>$med_pharmacy_id]);

            }

  // submit to edit info
            public function update_item_info($med_item_id){

              $this->form_validation->set_rules('med_item_name','Item Name','required');
              $this->form_validation->set_rules('med_item_brand','Item Brand','required');
              $this->form_validation->set_rules('med_item_type','Select Item Type','required');
              $this->form_validation->set_rules('med_item_subtype','Select Item Subtype','required');
              $this->form_validation->set_rules('med_item_spec','Item Specifcation','required');
              $this->form_validation->set_rules('med_comments','Item Comments','required');
              $this->form_validation->set_rules('med_stock','Number of Units','required');
              $this->form_validation->set_rules('med_unit_price','Unit Price of Item(LKR)','required');


              if ($this->form_validation->run() )
              {

                $data=$this->input->post();
                unset($data['submit']);
                $this->load->model('shop_model');
                $med_pharmacy_id=$this->input->post('med_pharmacy_id');

                if($this->shop_model->updateItemInfo($med_item_id,$data)){

                  $this->session->set_flashdata('msg','Inventory Item Updated Successfully!');

                }
                else{

                  $this->session->set_flashdata('msg','Inventory Item Update Failed!');

                } 
                return redirect('shop_controller/update_item_manager/'.$med_pharmacy_id);    

              }
              else
              {

                $this->load->view('update_item_manager');   
              }

            }


             // validate manager
            public function mgr_login_validator(){
    // $this->load->view('user_login');
              $this->form_validation->set_rules('email','Email','required|valid_email');
              $this->form_validation->set_rules('password','password','required');

              if($this->form_validation->run()){

                $email=$this->input->post('email');

                $encrypted_password=md5($this->input->post('password'));

                $this->load->model('user_model');

                if ($this->user_model->can_login($email,$encrypted_password)) {

                  $username=$this->user_model->getFName($email);
                  $userId=$this->user_model->getUid($email);
                  $profile=$this->user_model->getProPic($email);
                  $sessionId=rand(10,100000);
                  $loginTime=  date('Y-m-d H:i:s');
          // $loginTime='now()';

                  $login_data = array('userId' =>$userId,
                    'sessionId' =>$sessionId,
                    'status' => "Active",
                    'loginTime' =>  $loginTime
                  );

                  if ($this->user_model->createSession($login_data)) {
            # code...
                    $data['username'] = $username;
                    $data['sessionId']= $sessionId;
                    $data['userId']= $userId;
                    $data['profile']= $profile;

                    $this->load->view('manager_home',$data);

                  }else{
                    $this->session->set_flashdata('msg','Cannot create session!');
                    return redirect('user_controller/manager_login');
                  }

          // echo 'Welcome to omdp '. $uname;




                }else{
                 $this->session->set_flashdata('msg','Invalid Email or Password!');
                 return redirect('user_controller/manager_login');

               }




             }
             else{
               $this->load->view('user_login');
             }
           }


           // add medicine item
           public function  add_inventory_item(){
            $data['med_pharmacy_id']=$this->uri->segment(3);
            $this->load->view('add_inventory_item',$data);


          }








  // upload function
          public function uploadPic($profile){
     // $config['upload_path']          = base_url('uploads/');
            $config['upload_path']          = './uploads/';
            $config['allowed_types']        = 'gif|jpg|png|jppeg|pdf|jpeg';
            $config['max_size']             = 1000;
            $config['max_width']            = 1000;
            $config['max_height']           = 1000;

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload($profile))
            {
              $info=$this->upload->data();
              $path=base_url("uploads/".$info['file_name']);
            }
            else
            {
      // $path=base_url('uploads/null.jpg');
              $path = $this->upload->display_errors();

            }
            return $path;
          }

  // add medicine inventory
          public function add_prescription()

          {
            $this->form_validation->set_rules('prescription_name','Prescription Name','required');
            // $this->form_validation->set_rules('prescription_image','Upload  prescription','required');
            $this->form_validation->set_rules('prescription_comments','Prescription comments','required');
            $this->form_validation->set_rules('prescription_adress1','Delivery Address Line1 :','required');
            $this->form_validation->set_rules('prescription_adress2','Delivery Address Line2 :','required');
            $this->form_validation->set_rules('prescription_adress3','Delivery Address 3','required');
            $this->form_validation->set_rules('prescription_email','Notification Email','required|valid_email');
            $this->form_validation->set_rules('prescription_urgency','Prescription Urgency','required');

            $prescription_uid=$this->uri->segment(3);

            if ($this->form_validation->run() )
            {
              $data=$this->input->post();
              
              // $userId=$this->uri->segment(3);
    // $encrypted_password=md5($this->input->post('password'));
              unset($data['submit']);
              $this->load->model('shop_model');
              $data = array(
                'prescription_name'  => $this->input->post('prescription_name'),
                'prescription_comments'  => $this->input->post('prescription_comments'),
                'prescription_adress1'  => $this->input->post('prescription_adress1'),
                'prescription_adress2'  => $this->input->post('prescription_adress2'),
                'prescription_adress3'  => $this->input->post('prescription_adress3'),
                'prescription_email'  => $this->input->post('prescription_email'),
                'prescription_urgency' => $this->input->post('prescription_urgency'),
                'prescription_createdate'=> date('Y-m-d H:i:s'),     
                'prescription_image'=> $this->uploadPic('prescription_image'),
                'prescription_uid '=>  $prescription_uid
              );


      // return $data;
              if($this->shop_model->add_prescription($data)){

                $this->session->set_flashdata('msg','Prescription added Successfully!');
              // return $data;

              }
              else{

                $this->session->set_flashdata('msg','Failed to save Prescription!');

              } 
              
              return redirect('shop_controller/save_prescription/'.$prescription_uid);  



            }
            else {
      // $this->load->view('admin_home');
              $data['prescription_uid']=$prescription_uid;
              $this->load->view('save_prescription',$data);
      // return redirect('admin_controller/pharm_reg'); 

            }



          }



  // remove prescription
                  // fetch user for delete Live data
          public function fetch_prescription_del(){

            $output = '';
            $query = '';
            $prescription_uid=$this->uri->segment(3);
            $this->load->model('shop_model');
            if($this->input->post('query')){
              $query=$this->input->post('query');
            }
            $data=$this->shop_model->fetch_live_prescips($query,$prescription_uid);
            $output .= '
            <div class="table-responsive">
            <table class="table table-bordered table-striped">
            <tr>
            <th>Prescription Name</th>
            <th>Prescription Comments</th>
            <th>Prescription Urgency</th>
            <th>Created On</th>
            <th>Prescription Email</th>
            <th>Action</th>
            </tr>
            ';
            if ($data->num_rows()>0) {
      # code...
              foreach($data->result() as $row)
              {
                $output .= '
                <tr>
                <td>'.$row->prescription_name.'</td>
                <td>'.$row->prescription_comments.'</td>
                <td>'.$row->prescription_urgency.'</td>
                <td>'.$row->prescription_createdate.'</td>                   
                <td>'.$row->prescription_email.'</td>
                <td><a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\''.base_url().'shop_controller/delete_prescription/'.$row->prescription_id.'/'.$prescription_uid.'\')" class="bg-danger text-white">Delete</a> <a href="javascript:void(0)" onclick="$(\'div#main_content_inner\').load(\''.base_url().'shop_controller/view_prescription/'.$row->prescription_id.'/'.$prescription_uid.'\')" class="bg-primary text-white">View</a></td> 

                </tr>
                ';
              }
            }else{
              $output .= '<tr>
              <td colspan="5">Sorry No Data Found</td>
              </tr>';
            }
            $output .= '</table>';
            echo $output;



          }

          


  // remove prescription

          public function delete_prescription($prescription_id){
            $this->load->model('shop_model');
            $prescription_uid=$this->uri->segment(4);
            if($this->shop_model->removePrecription($prescription_id))
            {

              $this->session->set_flashdata('msg','Precriptions  Deleted Successfully!');

            }
            else{

              $this->session->set_flashdata('msg','Precriptions  Delete Failed!');

            } 
            return redirect('shop_controller/remove_prescription/'.$prescription_uid);  
          }


    // view prescription
          public function view_prescription($prescription_id){
            $prescription_uid=$this->uri->segment(4);
            $this->load->model('shop_model');
            $data['query']=$this->shop_model->view_prescription($prescription_id,$prescription_uid);
            $this->load->view('view_prescription',$data);
          }


          // save prescription
    // add medicine inventory
          public function add_med_item_manger()

          {
            $this->form_validation->set_rules('med_item_name','Item Name','required');
            $this->form_validation->set_rules('med_item_brand','Item Brand','required');
            $this->form_validation->set_rules('med_item_type','Select Item Type','required');
            $this->form_validation->set_rules('med_item_subtype','Select Item Subtype','required');
            $this->form_validation->set_rules('med_item_spec','Item Specifcation','required');
            $this->form_validation->set_rules('med_comments','Item Comments','required');
            $this->form_validation->set_rules('med_stock','Number of Units','required');
            $this->form_validation->set_rules('med_unit_price','Unit Price of Item(LKR)','required');

            if ($this->form_validation->run() )
            {
              $data=$this->input->post();
    // $encrypted_password=md5($this->input->post('password'));
              unset($data['submit']);
              $this->load->model('admin_model');
              $data = array(
                'med_item_name'  => $this->input->post('med_item_name'),
                'med_item_brand'  => $this->input->post('med_item_brand'),
                'med_item_type'  => $this->input->post('med_item_type'),
                'med_item_subtype'  => $this->input->post('med_item_subtype'),
                'med_item_spec'  => $this->input->post('med_item_spec'),
                'med_comments'  => $this->input->post('med_comments'),
                'med_stock' => $this->input->post('med_stock'),
                'med_unit_price' => $this->input->post('med_unit_price'),
                'med_manufact_date' => $this->input->post('med_manufact_date'),
                'med_exp_date' => $this->input->post('med_exp_date'),
                'med_pharmacy_id' => $this->input->post('med_pharmacy_id'),

      // 'password' => $encrypted_password,         
                'med_item_image'=> $this->uploadPic('med_item_image')
              );


      // return $data;
              if($this->admin_model->add_inventory_item($data)){

                $this->session->set_flashdata('msg','Item added Successfully!');
              // return $data;

              }
              else{

                $this->session->set_flashdata('msg','Failed to add item to Inventory!');

              } 
              return redirect('shop_controller/add_inventory_item');  



            }
            else {
      // $this->load->view('admin_home');
              $this->load->view('add_inventory_item');
      // return redirect('admin_controller/pharm_reg'); 

            }



          }





              // validate login cashier// Validate user and create an entry in the login session table
          public function login_validator(){
    // $this->load->view('user_login');
            $this->form_validation->set_rules('email','Email','required|valid_email');
            $this->form_validation->set_rules('password','password','required');

            if($this->form_validation->run()){

              $email=$this->input->post('email');
              $type=$this->input->post('type');

              $encrypted_password=md5($this->input->post('password'));

              $this->load->model('user_model');

              if ($this->user_model->can_login($email,$encrypted_password)) {

                $userData=$this->user_model->getUserAll($email);
                // $pharm_name=$this->user_model->getManagerPharm($email)->pharm_name;
                // $pharm_id=$this->user_model->getManagerPharm($email)->pharm_id;
                if($type=='Cashier'){
                   $pharm_name=$this->user_model->getCashierPharm($email)->pharm_name;
                   $pharm_id=$this->user_model->getCashierPharm($email)->pharm_id;
                  // $this->load->view('cashier_home',$data);

                }
                else if ($type=='Manager'){
                  $pharm_name=$this->user_model->getManagerPharm($email)->pharm_name;
                  $pharm_id=$this->user_model->getManagerPharm($email)->pharm_id;         
                 // $this->load->view('manager_home',$data);
               }

               $username=$userData->fName;
               $userId=$userData->userId;
               $profile=$userData->profile;
               $userType=$userData->userType;
               $sessionId=rand(10,100000);
               $loginTime=  date('Y-m-d H:i:s');
          // $loginTime='now()';

               $login_data = array('userId' =>$userId,
                'sessionId' =>$sessionId,
                'status' => "Active",
                'loginTime' =>  $loginTime );

               if ($this->user_model->createSession($login_data)) {
            # code.

                $data['username'] = $username;
                $data['sessionId']= $sessionId;
                $data['userId']= $userId;
                $data['profile']= $profile;
                $data['pharm_name']=$pharm_name;
                $data['pharm_id']=$pharm_id;

                if($type=='Cashier'){
                  // if tyoe in the dropwdown is cashier , load thie one
                    // $pharm_name=$this->user_model->getManagerPharm($email)->pharm_name;
                    // $pharm_id=$this->user_model->getManagerPharm($email)->pharm_id;
                    // $data['pharm_name']=$pharm_name;
                    // $data['pharm_id']=$pharm_id;
                  $this->load->view('cashier_home',$data);

                }
                else if ($type=='Manager'){
                   // if tyoe in the dropwdown is Manager , load this one
                   // $pharm_name=$this->user_model->getCashierPharm($email)->pharm_name;
                   // $pharm_id=$this->user_model->getCashierPharm($email)->pharm_id;
                   // $data['pharm_name']=$pharm_name;
                   // $data['pharm_id']=$pharm_id;
                 $this->load->view('manager_home',$data);
               }else

               {
                $this->session->set_flashdata('msg','Not a valid user Type!');
                return redirect('shop_controller/login');
              }

            }else{
              $this->session->set_flashdata('msg','Cannot create session!');
              return redirect('shop_controller/login');
            }

          // echo 'Welcome to omdp '. $uname;




          }else{
           $this->session->set_flashdata('msg','Invalid Email or Password!');
           return redirect('shop_controller/login');

         }




       }
       else{
         $this->load->view('cashier_login');
       }
     }


// update session table after logout
     public function logout()
     {
       $this->load->model('user_model');
       $sessionId=$this->uri->segment(3);
       $userId=$this->uri->segment(4);
       $logoutTime= date('Y-m-d H:i:s');
       if($this->user_model->completeLogOut($sessionId,$userId,$logoutTime)){
        $this->session->set_flashdata('msg','Sucessfully Logged Out of OMDP!');
        return redirect('shop_controller/login');
      }else
      {
        echo "Failed to Logout!";
      }
    }





              //load shopping cart in customer home
    public function shopping_cart_load(){
      $this->load->view('shopping_cart');
    }



              // add to shopping cart

    public function add_to_cart(){ 
      $data = array(
        'id' => $this->input->post('med_item_id'), 
        'name' => $this->input->post('med_item_name'), 
        'price' => $this->input->post('med_unit_price'), 
        'qty' => $this->input->post('quantity'),
        'options' => array('pharm_id' => $this->input->post('pharm_id'))

      );
                // returns a rowid
      $this->cart->insert($data);   
                // echo $this->show_cart(); 
      echo $this->view_cart();
    }

    public function load_cart(){
          // $userId=$this->uri->segment(3);
      echo $this->view_cart();
    }


    public function load_final_bill(){
          // $userId=$this->uri->segment(3);
      echo $this->view_bill();
    }


    // check item stock
    public function check_item_stock(){
      $med_item_id=$this->input->post("med_item_id");
      $this->load->model('shop_model');
      $checkStock=$this->shop_model->check_item_stock($med_item_id);
      echo $checkStock;

    }


             // view cart
    public function view_cart(){ 
      $this->load->library("cart");
      $output = '';
      $output .= '
      <div class="card-header">
      <div class="row">
      <div class="col-sm-6"><h4 class="header-title mb0">My Cart</h4></div>
      <div class="col-sm-1"><button  type="button" id="clear_cart" class="btn btn-warning">Clear Cart</button></div>
      </div>
      </div>
      </div><div class="table-responsive">

      <br />
      <table class="table table-bordered">
      <tr>         
      <th >Name</th>
      <th >Quantity</th>
      <th >Price</th>
      <th >Total</th>
      <th >Action</th>
      </tr>

      ';
      $count = 0;
      foreach($this->cart->contents() as $items)
      {
       $count++;
       $output .= '
       <tr> 
       <td>'.$items["name"].'</td>
       <td>'.$items["qty"].'</td>
       <td>'.$items["price"].'</td>
       <td>'.$items["subtotal"].'</td>
       <td id="'.$items["options"]["pharm_id"].'"><button type="button" name="remove" class="btn btn-danger btn-xs remove_inventory" id="'.$items["rowid"].'">Remove</button></td>
       </tr>
       ';
     }
     $output .= '
     <tr>
     <td colspan="3" align="right"><b>Total</b></td>
     <td>'.$this->cart->total().'</td>
     <td><a href="javascript:void(0)" onclick="checkoutOrder()" id="checkout_btn" class="btn btn-info btn-lg"><span class="glyphicon glyphicon-chevron-right"></span> Checkout
     </a></td>
     </tr>

     </table>
     </div>

     ';

     if($count == 0)
     {
       $output = '<h3 align="center">Cart is Empty</h3>';
     }
     return $output;
   }

// load bill at checkout
   public function view_bill(){ 
    $this->load->library("cart");
    $output = '';
    $output .= '
    <div class="card-header">
    <div class="row">
    <div class="col-sm-6"><h4 class="header-title mb0">My Invoice</h4></div>
    </div>
    </div>
    </div><div class="table-responsive" >

    <br />
    <table class="table table-bordered" id="invoice_table">
    <tr>         
    <th >Item</th>
    <th >Quantity</th>
    <th >Price</th>
    <th >Total</th> 
    </tr>

    ';
    $count = 0;
    foreach($this->cart->contents() as $items)
    {
     $count++;
     $output .= '
     <tr> 
     <td>'.$items["name"].'</td>
     <td>'.$items["qty"].'</td>
     <td>'.$items["price"].'</td>
     <td>'.$items["subtotal"].'</td>
     </tr>
     ';
   }
   $output .= '
   <tr>
   <td colspan="2" align="left"><b>Total</b></td>
   <td colspan="1" align="right"></td>
   <td id="item_total_charge">'.$this->cart->total().'</td>
   </tr>
   <tr>
   <td colspan="2" align="left"><b>Discounts</b></td>
   <td colspan="1" align="right">15%</td>
   <td id="discount_charge">0</td>
   </tr>
   <tr>
   <td colspan="2" align="left"><i>Shipping Charges</i></t
   d>
   <td colspan="1" id="setDelviery" align="right"></td>
   <td ><span class="delivery_charge">50</td>
   </tr>
   <tr>
   <td colspan="2" align="left"><i>Taxes</i></td>
   <td colspan="1" align="right"></td>
   <td id="tax_charge">0</td>
   </tr>
   <tr>
   <td colspan="2" align="left"><b>Final Total</b></td>
   <td colspan="1" align="right"></td>
   <td id="grant_total_charge"><b><i></i></b></td>
   </tr>
   <tr>
   <td colspan="2" align="left"><i>Payment Method</i></td>
   <td colspan="1" align="right"></td>
   <td id="payment_meth">0</td>
   </tr>
   <tr>
   <td colspan="4"><a href="javascript:void(0)" onclick="continueShopping()" id="continue_btn" class="btn btn-info btn-md" align="right"><span class="glyphicon glyphicon-chevron-right"></span> Continue Shopping
   </a></td>
   </tr>



   </table>
   </div>

   ';

   if($count == 0)
   {
     $output = '<h3 align="center">Cart is Empty</h3>';
   }
   return $output;
 }

//remove item
 public function remove_cart_item()
 {
  $this->load->library("cart");
  $row_id = $_POST["row_id"];
  $data = array(
   'rowid'  => $row_id,
   'qty'  => 0
 );
  $this->cart->update($data);
  echo $this->view_cart();
}

//clear cart
public function clear_cart()
{
  $this->load->library("cart");
  $this->cart->destroy();
  echo $this->view_cart();
}


public function checkout(){
        // $userId['userId']=$this->uri->segment(3);
  $userId['userId']=$this->input->post('userId');
  $this->load->view("checkout",$userId);

}








}

