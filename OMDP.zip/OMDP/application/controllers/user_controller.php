  <?php
  defined('BASEPATH') OR exit('No direct script access allowed');

  class user_controller extends CI_Controller {  

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *    http://example.com/index.php/welcome
     *  - or -
     *    http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */


// Landing Page
    public function landing_page()
    {
      $this->load->view('landing_page');
    }

// Load Header Page
    public function header()
    {
      $this->load->view('header');
    }

    public function login()
    {
     $this->load->view('user_login');
   }


// User profile Page
   public function profile()
   {
     $this->load->view('profile');
   }

// Manager Home
   public function manager_login()
   {
     // $userType['userType']="Manager";
     $this->load->view('manager_login');
   }


   // Live Data Search Medicine
   public function fetch_med(){

    $output = '';
    $query = '';
    $this->load->model('user_model');
    if($this->input->post('query')){
      $query=$this->input->post('query');
    }
    $data=$this->user_model->fetch_live_data($query);
      $output .= '    <div class="container" onload="load_cart()">
        <br /><br />
        <div class="col-lg-14">
        <div class="table-responsive">
        <div class="row">';
    if ($data->num_rows()>0) {
      # code...
      foreach($data->result() as $row)
      { 

        $output .='<div class="col-md-3" style="padding:16px; background-color:#f1f1f1; border:1px solid #ccc; margin-bottom:16px; height:400px" align="center">
        <div class="thumb-content"> 
         
        <img src="'.$row->med_item_image.'" class="img-thumbnail" /><br />
        
        <p><b>'.$row->med_item_name.'</b></p>
        <p class="text-danger">LKR '.$row->med_unit_price.'</p>
        <p class="text-primary"> <b>'.$row->pharm_name .'</b></p>
        <div class="form-group w-75">
        <input type="number" name="quantity" maxlength="3" size="3" class="quantity form-control" placeholder="Enter quantity" id="'.$row->med_item_id.'" /><br />
          <button type="button" name="add_cart" class="btn btn-success add_cart" data-productname="'.$row->med_item_name.'" data-price="'.$row->med_unit_price.'" data-productid="'.$row->med_item_id.'" >Add to Cart</button>
        </div>
        </div>
        </div>

        ';

       
      }
    }else{
      $output .= '<tr>
      <td colspan="5">Sorry No Data Found</td>
      </tr>';
    }
     $output .='</div>

        </div>
        <!--  </div>
        </div> -->
        </div>
        </div>

        ';
    echo $output;



  }




// Load Admin Home Page
  public function admin_home()
  {
   $this->load->view('admin_home');
 }

// upload pic function
 public function uploadPic($profile){
     // $config['upload_path']          = base_url('uploads/');
  $config['upload_path']          = './uploads/';
  $config['allowed_types']        = 'gif|jpg|png|jppeg';
  $config['max_size']             = 100;
  $config['max_width']            = 150;
  $config['max_height']           = 100;

  $this->load->library('upload', $config);
  $this->upload->initialize($config);

  if ($this->upload->do_upload($profile))
  {
    $info=$this->upload->data();
    $path=base_url("uploads/".$info['file_name']);
  }
  else
  {
      // $path=base_url('uploads/null.jpg');
    $path = $this->upload->display_errors();

  }
  return $path;
}


// load regsitration Page
public function  registration()
{
  $this->load->view('user_registration');
}


// Update Login_session table
public function logout()
{
 $this->load->model('user_model');
 $sessionId=$this->uri->segment(3);
 $userId=$this->uri->segment(4);
 $logoutTime= date('Y-m-d H:i:s');
 if($this->user_model->completeLogOut($sessionId,$userId,$logoutTime)){
  $this->session->set_flashdata('msg','Sucessfully Logged Out of OMDP!');
  $this->load->library("cart");
  $this->cart->destroy();
  return redirect('user_controller/login');
}else
{
  echo "Failed to Logout!";
}
}

 // public function customer_home()
 //    {
 //     $this->load->view('customer_home');
 //   }


public function admin_dash()
{
 $this->load->view('admin_dashboard');
}


// Javascript load content customer
public function main_inner_content_cust()
{
 $this->load->view('main_inner_customer');
}

// Javascript load content admin
public function main_inner_content_admin()
{
 $this->load->view('main_inner');
}

// Validate And register user
public function register_validator()

{
  $this->form_validation->set_rules('fname','First Name','required');
  $this->form_validation->set_rules('lname','Last Name','required');
  $this->form_validation->set_rules('email','Email','required|valid_email');
  $this->form_validation->set_rules('mobile','Mobile','required');
  $this->form_validation->set_rules('nic','Valid NIC','required');



  if ($this->form_validation->run() )
  {
      // $data=$this->input->post();
    $encrypted_password=md5($this->input->post('password'));
      // unset($data['submit']);
    $this->load->model('user_model');
    


    $data = array(
      'fName'  => $this->input->post('fname'),
      'lName'  => $this->input->post('lname'),
      'userEmail'  => $this->input->post('email'),
      'userMobile'  => $this->input->post('mobile'),
      'userNIC'  => $this->input->post('nic'),
      'gender'  => $this->input->post('gender'),
      'password' => $encrypted_password,
      'userType' => "Customer",
      'profile'=> $this->uploadPic('profile')


    );


      // return $data;
    if($this->user_model->regsiter_user($data)){

      $this->session->set_flashdata('msg','Customer Regsitered Successfully!');
              // return $data;

    }
    else{

      $this->session->set_flashdata('msg','Customer Registration Failed!');

    } 
    return redirect('user_controller/registration');  



  }
  else {
    $this->load->view('user_registration');

  }



}

// view user profile in customer home
public function view_profile($userId){
  $this->load->model('user_model');
  $data['query']=$this->user_model->view_profile($userId);
  $this->load->view('profile',$data);
}


//list all item
public function list_all_items()
{
        // redirect('user_controller/landing_page');
  $this->load->model('user_model');
  $data=$this->user_model->getMedicItems();
  // if ($data -> result()->num_rows() > 0){
  $this->load->view('list_items',['data'=>$data]);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


}

//fetch new items to cart
public function fetch_new_items()
{
        // redirect('user_controller/landing_page');
  $this->load->model('user_model');

  
  // if ($data -> result()->num_rows() > 0){
  if($this->input->post('query')){
      $query=$this->input->post('query');
    }
  $data=$this->user_model->fetch_live_data($query);
  $this->load->view('list_items',['data'=>$data]);
  // }
  // else{
  //   return "<pre>No items bro </pre>";
  // }


}


// login user
public function login_validator(){
    // $this->load->view('user_login');
  $this->form_validation->set_rules('email','Email','required|valid_email');
  $this->form_validation->set_rules('password','password','required');

  if($this->form_validation->run()){

    $email=$this->input->post('email');

    $encrypted_password=md5($this->input->post('password'));

    $this->load->model('user_model');

    if ($this->user_model->can_login($email,$encrypted_password)) {

      $username=$this->user_model->getFName($email);
      $userId=$this->user_model->getUid($email);
      $profile=$this->user_model->getProPic($email);
      $sessionId=rand(10,100000);
      $loginTime=  date('Y-m-d H:i:s');
          // $loginTime='now()';

      $login_data = array('userId' =>$userId,
        'sessionId' =>$sessionId,
        'status' => "Active",
        'loginTime' =>  $loginTime
      );

      if ($this->user_model->createSession($login_data)) {
            # code...
        $data['username'] = $username;
        $data['sessionId']= $sessionId;
        $data['userId']= $userId;
        $data['profile']= $profile;

        $this->load->view('customer_home',$data);

      }else{
        $this->session->set_flashdata('msg','Cannot create session!');
        return redirect('user_controller/login');
      }

          // echo 'Welcome to omdp '. $uname;




    }else{
     $this->session->set_flashdata('msg','Invalid Email or Password!');
     return redirect('user_controller/login');

   }




 }
 else{
   $this->load->view('user_login');
 }
}




// Validate Manager Login_session// login user
public function mgr_login_validator(){
    // $this->load->view('user_login');
  $this->form_validation->set_rules('email','Email','required|valid_email');
  $this->form_validation->set_rules('password','password','required');

  if($this->form_validation->run()){

    $email=$this->input->post('email');

    $encrypted_password=md5($this->input->post('password'));

    $this->load->model('user_model');

    if ($this->user_model->can_login($email,$encrypted_password)) {

      $username=$this->user_model->getFName($email);
      $userId=$this->user_model->getUid($email);
      $profile=$this->user_model->getProPic($email);
      $sessionId=rand(10,100000);
      $loginTime=  date('Y-m-d H:i:s');
          // $loginTime='now()';

      $login_data = array('userId' =>$userId,
        'sessionId' =>$sessionId,
        'status' => "Active",
        'loginTime' =>  $loginTime
      );

      if ($this->user_model->createSession($login_data)) {
            # code...
        $data['username'] = $username;
        $data['sessionId']= $sessionId;
        $data['userId']= $userId;
        $data['profile']= $profile;

        $this->load->view('manager_home',$data);

      }else{
        $this->session->set_flashdata('msg','Cannot create session!');
        return redirect('user_controller/manager_login');
      }

          // echo 'Welcome to omdp '. $uname;




    }else{
     $this->session->set_flashdata('msg','Invalid Email or Password!');
     return redirect('user_controller/manager_login');

   }




 }
 else{
   $this->load->view('user_login');
 }
}


}

?>