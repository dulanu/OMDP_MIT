  <?php
  defined('BASEPATH') OR exit('No direct script access allowed');
  include_once('header.php');
  ?>
  

  <?php if($msg=$this-> session->flashdata('msg')): ?>
    <div class="alert alert-dismissible alert-success">  
      <?php echo $msg;?>
      <?php unset($_SESSION['msg']); ?>
      <?php echo "</br>";?>   
      <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/user_reg')">Continue Adding</a>
    </div>
  <?php endif;?>  
  <!-- <div class="container"> -->
    <br />
    <h3 align="center">Upload Your Prescription</h3>
    <br />
    <div class="panel panel-default">
     <!-- <div class="panel-heading">Register</div> -->
     <div class="panel-body">
      <?php echo form_open_multipart('',array('id' => 'myform')); ?>
      <fieldset>
        <!-- <legend>Register New User </legend> -->
 <!--        <div class="form-group">
          <label  class="col-lg-2 control-label">Prescription Name</label>
          <div class="col-lg-10">
            <input type="text" class="form-control" name="prescript_name" placeholder="Eg :Daily Diabets Dose 1">
          </div>
          <div class="col-md-5">
           
          </div>
        </div> -->
        <div class="form-group">
          <label  class="col-lg-2 control-label">Upload  prescription or</label>
          <div class="col-lg-10">
           <div class="drop-zone">
            <span class="drop-zone__prompt" >Drop file here or click to upload</span>
            <input type="file" id="drop_precript" name="prescription_image" class="drop-zone__input">
          </div>
        </div>
        <div class="col-md-5">
          
        </div>
      </div>
      <div class="form-group"> 
        <!-- <div class="container"> -->
          <div class="col-md-8">
            <div class="row">
              <div class="checkbox">
                <label> <input type="checkbox" id="toggle_precsription"> Select a prescription I have already saved</label>
              </div> <!-- checkbox .// -->
            </div>
          </div>
          <!-- </div> -->
        </div>
        <div class="form-group">
          <label  class="col-lg-3 control-label">Select Prescription</label>
          <div class="col-lg-10" id="div_prescription_name_drop">
      <!--   <select name="type" id="precription_drop">
          <option value="Minimum">Health Med Pharmacy</option>
          <option value="Moderate">Moderate</option>
          <option value="Urgent">Urgent</option>
          <option value="Critical">Critical</option>
        </select> -->
      </div>              
      <div class="col-md-5">
       
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Prescription comments</label>
      <div class="col-lg-10">
        <input type="text" id="prescription_comments" class="form-control" name="prescription_comments" placeholder="Eg : xxx@maildomain.com">
      </div>
      <div class="col-md-5">
        
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Delivery Address Line1 :</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="prescription_adress1" name="order_address1" placeholder="No 28/25,">
      </div>
      <div class="col-md-5">
       
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Delivery Address Line2 :</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="prescription_adress2" name="order_address2" placeholder="Rosmean Place">
      </div>
      <div class="col-md-5">
       
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Delivery Address 3</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" id="prescription_adress3" name="order_address3" placeholder="Colombo 7">
      </div>
      <div class="col-md-5">
    
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-2 control-label">Email Address</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="order_email"   id= "prescription_email" placeholder="Eg : sendMyorder@gmail.com">
      </div>
      <div class="col-md-5">
      
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Select Pharmacy</label>
      <div class="col-lg-10" id="div_pharm_name_drop">
 <!--        <select name="type" id="type">
          <option value="Minimum">Health Med Pharmacy</option>
          <option value="Moderate">Moderate</option>
          <option value="Urgent">Urgent</option>
          <option value="Critical">Critical</option>
        </select> -->
      </div>              
      <div class="col-md-5">
       
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Prescription Urgency</label>
      <div class="col-lg-10">
        <select name="prescription_urgency" id="prescription_urgency">
          <option value="Minimum">Minimum</option>
          <option value="Moderate">Moderate</option>
          <option value="Urgent">Urgent</option>
          <option value="Critical">Critical</option>
        </select>
      </div>              
      <div class="col-md-5">
        
      </div>  
    </div>
<!--      <div class="form-group"> 
    <div class="container">
      <div class="col-md-8">
        <div class="row">
          <div class="checkbox">
            <label> <input type="checkbox"> I hereby confirm that the precription I have uploaded is valid and issued by a registered Physician in Sri Lanka </label>
          </div> checkbox .// -->
<!--         </div>
      </div>
    </div>
  </div> --> 
  <div class="form-group"> 
    <!-- <div class="container"> -->
      <div class="col-md-8">
        <div class="row">
          <div class="checkbox">
            <label> <input type="checkbox" > I hereby confirm that the precription I have uploaded is valid and issued by a registered Physician in Sri Lanka<span id="hide_prescription_image"></span></label>
          </div> <!-- checkbox .// -->
        </div>
      </div>
      <!-- </div> -->
    </div>
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
        <?php echo form_submit(['name'=>'submit','value'=> 'Next','class'=>'btn btn-primary']);?>

        <button type="reset" class="btn btn-default">Clear</button>

      </div>
    </div>
    <div class="form-group">      
    </div>
  </fieldset>
  <?php echo form_close(); ?>
</div>
</div>
<!-- </div> -->



<script type="text/javascript">

// Override Defualt submit function - and load data in the div main container


// disable prescription list on  page load
$(document).ready(function(){

  // load my prescriptions
  var userId='<?php echo $userId; ?>';

  

  autofill_values();


  // payment method drop down


  // console.log(autofill_values());

  $.ajax({
    url:"<?php echo base_url(); ?>order_controller/load_my_prescription",
    method:"POST",
  // data:$(this).serialize(),
  data:{userId:userId},
  // dataType:"html",
  success:function(data){
    if (data!='') {
     $('#div_prescription_name_drop').html(data);
     $("#precription_drop").prop( "disabled", true );
     // $("#prescription_urgency").prop( "disabled", true );
       // getsubtypes();
     }
   }

 }); 

  



// on change drop down auto fill value
function autofill_values(){

$("#div_prescription_name_drop").change(function() {

 var prescription_id=$('#div_prescription_name_drop option:selected').val();
 
 console.log(prescription_id);

 $.ajax({
  url:"<?php echo base_url(); ?>order_controller/auto_fill_prescription",
  method:"POST",
  data:{prescription_id:prescription_id},
  dataType:"json",
  cache: false,
  success:function(data){
    if (data!='') {
             $('#prescription_comments').val(data.prescription_comments);
             $('#prescription_adress1').val(data.prescription_adress1);
             $('#prescription_adress2').val(data.prescription_adress2);
             $('#prescription_adress3').val(data.prescription_adress3);
             $('#prescription_email').val(data.prescription_email);
             // $('#prescription_adress3').val(data.prescription_adress3);
             $("#prescription_urgency").val(data.prescription_urgency);
             // console.log(data);
             get_pre_image(data.prescription_image);

             // $("#hide_prescription_image").val(data.prescription_image);
       // getsubtypes();
     }
     return data.prescription_image;
   }

    // console.log(data.prescription_image);

 }); 
  // console.log(prescription_image);
});
  
}


// get image func
var prescription_image='';

function get_pre_image(data){

  prescription_image=data;

  return prescription_image;

}


console.log(get_pre_image(prescription_image));

//if checked
$("#toggle_precsription").change(function() {

  if(this.checked!=true) {
        //Do stuff
        // alert('checked!');
        $("#precription_drop").prop( "disabled", true );
        $("#prescription_urgency").prop( "disabled", false );
        $('#drop_precript').prop( "disabled", false );
        autofill_values();
        // console.log(autofill_values());

      }else{
        
        $("#precription_drop").prop( "disabled", false );
        // $("#prescription_urgency").prop( "disabled", true );
        autofill_values();
        $('#drop_precript').prop( "disabled", true );




      }
    });




// console.log(get_pre_image(prescription_image));







// console.log(autofill_values());

// load main items of item types
$.ajax({
  url:"<?php echo base_url(); ?>order_controller/load_all_pharamacies",
  method:"POST",
  data:$(this).serialize(),
  dataType:"html",
  success:function(data){
    if (data!='') {
     $('#div_pharm_name_drop').html(data);
       // getsubtypes();
     }
   }

 }); 

//call back function




// next button
$('#myform').submit(function(e){
 e.preventDefault();  
 var fd=new FormData(this);
 fd.append('customerId','<?php echo $userId; ?>');
 fd.append('prescription_image',get_pre_image(prescription_image));
 // var prescription_id=$('#div_prescription_name_drop option:selected').val();
 console.log(get_pre_image(prescription_image));
 $.ajax({
   url:"<?php echo base_url(); ?>order_controller/proceedPrescriptionRequest/<?php echo $userId; ?>",
   method:"POST",
     // data:$(this).serialize(),
     data:fd,
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });

});


});


// submit data for the next page


</script>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<script src="<?php echo base_url(); ?>/assets/js/custom.js"></script> 
<!-- </body>
</body> -->