<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
include_once('header.php');

?>

<body onload="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->
        <!-- preloader area start -->
        <div id="preloader">
            <div class="loader"></div>
        </div>
        <!-- preloader area end -->
        <!-- page container area start -->
        <div class="page-container">
            <!-- sidebar menu area start -->
            <div class="sidebar-menu">
                <div class="sidebar-header">
                    <div class="logo">
                        <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
                    </div>
                </div>
                <div class="main-menu">
                    <div class="menu-inner">
                        <nav>
                            <ul class="metismenu" id="menu">
                                <li class="active">
                                    <a href="index.html" aria-expanded="true"><i class="ti-home"></i><span>Why Choose Us</span></a>
                                </li>
                                <li class="active">
                                    <a href="" aria-expanded="true"><i class="ti-slice"></i><span>About Us</span></a>
                                    <ul class="collapse">
                                        <li ><a href="#">xxxxxxxxxxxxx</a></li>
                                        <li><a href="#">xxxxxxxxxxxxx</a></li>
                                        <li><a href="#">xxxxxxxxxxxxx</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" aria-expanded="true"><i class="ti-receipt"></i><span>My Orders
                                    </span></a>
                                    <ul class="collapse">
                                        <li><a href="#">xxxxxxxxxxxxx</a></li>
                                        <li><a href="#">xxxxxxxxxxxxx</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Our Pharmacies</span></a>
                                    <ul class="collapse">
                                        <li><a href="#">Government</a></li>
                                        <li><a href="#">Regsitered Pharmacies</a></li>
                                    </ul>
                                </li>

                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
            <!-- sidebar menu area end -->
            <!-- main content area start -->
            <div class="main-content">
                <!-- header area start -->
                <div class="header-area">
                    <div class="row align-items-center">
                        <!-- nav and search button -->
                        <div class="col-md-6 col-sm-8 clearfix">
                            <div class="nav-btn pull-left">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
<!--                             <div class="search-box pull-left">
                                <form action="#">
                                    <input type="text" name="search" placeholder="Search Your Medicine Here" required>
                                    <i class="ti-search"></i>
                                </form>
                            </div> -->
                            <div class="row align-items-center">
                                <div class="breadcrumbs-area clearfix">
                                    <a href="<?php echo base_url(); ?>"> <h4 class="page-title pull-left">Online Medicine Delivery Portal</h4> </a>
                                </div>
                            </div>
                        </div>
                        <!-- profile info & task notification -->
                        <div class="col-md-6 col-sm-4 clearfix">
                            <ul class="notification-area pull-right">
                                <li ><button type="button" class="btn btn-link"><a href="admin_controller/login" target="_blank">Not a Customer?</a></button></li>
                                <li id="full-view"><i class="ti-fullscreen"></i></li>
                                <li id="full-view-exit"><i class="ti-zoom-out"></i></li>
                                <li class="dropdown">
                                    <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
                                        <span>x</span>
                                    </i>
                                    <div class="dropdown-menu bell-notify-box notify-box">
                                        <span class="notify-title">You have new notification <a href="#">view all</a></span>
                                        <div class="nofity-list">
                                            <a href="#" class="notify-item">
                                                <div class="notify-thumb"><i class="ti-key btn-danger"></i></div>
                                                <div class="notify-text">
                                                    <p>xxxxxxxxxxxxxx</p>
                                                    <span>xxxxxxxxx</span>
                                                </div>
                                            </a>

                                        </div>
                                    </div>
                                </li>

                                <li class="settings-btn">
                                    <i class="ti-shopping-cart"></i>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- header area end -->
                <!-- page title area start -->
                <div class="page-title-area">
                    <div class="row align-items-center">
                        <div class="col-sm-6">
                            <div class="breadcrumbs-area clearfix">
                              <!--   <a href="<?php echo base_url(); ?>"> <h4 class="page-title pull-left">Online Medicine Delivery Portal</h4> </a> -->
                              <div class="search-box pull-left">
                                <form action="#">
                                    <input type="text" name="search" placeholder="Search Your Medicine Here" required>
                                    <i class="ti-search"></i>
                                </form>
                            </div>
                        </div>


                    </div>
                    <div class="col-sm-6 clearfix">
                        <div class="card-body pull-right">
                            <!-- <img class="avatar user-thumb" src="<?php echo base_url(); ?>assets/images/author/avatar.png" alt="avatar"> -->

                            <a class="btn btn-primary btn-lg" href="<?php echo base_url(); ?>user_controller/login">Sign In</a>

                      <!--       <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Settings</a>
                                <a class="dropdown-item" href="#">Log Out</a>
                            </div> -->
                        </div>
                        <div class="card-body pull-right">
                            <!-- <img class="avatar user-thumb" src="<?php echo base_url(); ?>assets/images/author/avatar.png" alt="avatar"> -->
                            <a class="btn btn-success btn-lg" href="<?php echo base_url(); ?>user_controller/registration">Sign Up</a>

                      <!--       <div class="dropdown-menu">
                                <a class="dropdown-item" href="#">Settings</a>
                                <a class="dropdown-item" href="#">Log Out</a>
                            </div> -->
                            <!-- </div> -->
                        </div>
                        <div class="card-body pull-right">
                        <button type="button" class="btn btn-link"><a href="shop_controller/login" target="_blank">Login to My Pharmacy</a></button>
                    </div>


                        <!-- <div class="col-sm-6 clearfix"> -->

                            <!-- </div> -->





                        </div>
                    </div>
                </div>

                <!-- nav bar item categries -->
                <nav class="navbar navbar-expand-lg navbar-light bg-light">
                    <!-- <nav class="navbar navbar-dark bg-dark"> -->
                      <!-- <a class="navbar-brand" href="#">Navbar</a> -->
                      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav">
                          <li class="nav-item dropdown">
                            <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                            <a class="nav-link dropdown-toggle" href="#" id="babyCare" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Baby-Care
                            </a>
                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#"> Food and Milk Essentials</a>
                                <a class="dropdown-item" href="#">Bath and Skin Essentials</a>
                                <!-- <div class="dropdown-divider"></div> -->
                                <a class="dropdown-item" href="#">Diapers and Nappy</a>
                                <a class="dropdown-item" href="#">Baby Wipes</a>
                                <a class="dropdown-item" href="#">Baby Food</a>
                                <a class="dropdown-item" href="#">Mother Care</a>
                            </div>
                        </li>
                    <!--   <li class="nav-item active">
                        <a class="nav-link" href="#"> Diabetes<p>   </p> </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="diabeticCare" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Diabetes
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#"> Diabetes Ayurvedic</a>
                            <a class="dropdown-item" href="#">Sugar Substitutes</a>
                            <!-- <div class="dropdown-divider"></div> -->
                            <a class="dropdown-item" href="#">Nutrition Supplements</a>
                            <a class="dropdown-item" href="#">Diabetic Equipment</a>
                            <a class="dropdown-item" href="#">Diabetic Devices</a>
                        </div>
                    </li>
 <!--                    <li class="nav-item active">
                        <a class="nav-link" href="#"> Ayurvedic<p>   </p> </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="ayurvedic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Ayurvedic
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#"> Food Supplements</a>
                            <a class="dropdown-item" href="#">Immunity</a>
                            <!-- <div class="dropdown-divider"></div> -->
                            <a class="dropdown-item" href="#">Health Care</a>
                            <!-- <a class="dropdown-item" href="#">Diabetic Equipment</a> -->
                        </div>
                    </li>
            <!--         <li class="nav-item dropdown">
                        <a class="nav-link " href="#"> Health-Care<p>   </p> </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="ayurvedic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Personal Care
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#"> Hair Care</a>
                            <a class="dropdown-item" href="#">Men Care</a>
                            <!-- <div class="dropdown-divider"></div> -->
                            <a class="dropdown-item" href="#">Women Care</a>
                            <a class="dropdown-item" href="#">Oral Care</a>
                        </div>
                    </li>
<!--                     <li class="nav-item active">
                        <a class="nav-link " href="#"> Nutrition<p>   </p> </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="ayurvedic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Nutrition & Supplements
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#"> Nutrition Drinks</a>
                            <a class="dropdown-item" href="#">Multi Vitamins</a>
                            <!-- <div class="dropdown-divider"></div> -->
                            <a class="dropdown-item" href="#">Speciality Suppliments</a>
                            <a class="dropdown-item" href="#">Protein Suppliments</a>
                        </div>
                    </li>
<!--                     <li class="nav-item active">
                        <a class="nav-link " href="#"> Suppliments<p>   </p> </a>
                    </li> -->
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="ayurvedic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Covid 19 Essentials
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#"> Hand Sanitizers</a>
                            <a class="dropdown-item" href="#">Hand Washes</a>
                            <!-- <div class="dropdown-divider"></div> -->
                            <a class="dropdown-item" href="#">Masks</a>
                            <a class="dropdown-item" href="#">Gloves</a>
                             <a class="dropdown-item" href="#">Immunity Boosters</a>
                        </div>
                    </li>
 <!--                    <li class="nav-item active">
                        <a class="nav-link " href="#"> Pharmacies </a>
                    </li> -->

                </ul>
            </div>
        </nav>
        <!-- nav bar item categoried end -->
        <!-- page title area end -->
        <div class="main-content-inner" id="main_content_inner">                <!-- sales report area start -->
          <!-- loaded by javascript -->
      </div>
  </div>

</div>
<!-- </div> -->
<!-- main content area end -->
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2021. All right reserved.</a>.</p>
    </div>
</footer>
<!-- footer area end-->
</div>
<!-- page container area end -->
<!-- offset area start -->

<!-- offset area end -->
<!-- jquery latest version -->
<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/metisMenu.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.slicknav.min.js"></script>

<!-- start chart js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
<!-- start highcharts js -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<!-- start zingchart js -->
<script src="https://cdn.zingchart.com/zingchart.min.js"></script>
<script>
    $('#blogCarousel').carousel({
        interval: 5000
    });

    $('#best_seller').carousel({
        interval: 5000
    });
</script>
<!-- all line chart activation -->
<script src="<?php echo base_url(); ?>assets/js/line-chart.js"></script>
<!-- all pie chart -->
<script src="<?php echo base_url(); ?>assets/js/pie-chart.js"></script>
<!-- others plugins -->
<script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
<script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
</body>

?>