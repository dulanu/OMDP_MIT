 <?php if($msg=$this-> session->flashdata('message')): ?>
    <div class="alert alert-dismissible alert-success">  
      <?php echo $msg;?>
      <?php unset($_SESSION['message']); ?>
      <?php echo "</br>";?>   
      <?php echo anchor('/order_controller/testEmail', 'Clear',['class'=>'alert-link'])?> 
      <!-- <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')">Clear</a> -->
    </div>
    <?php endif;?>
<a href="sendOrderCreateEmail">Test Mail</a>