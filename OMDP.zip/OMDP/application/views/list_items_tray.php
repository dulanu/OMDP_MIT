 <?php 
 defined('BASEPATH') OR exit('No direct script access allowed');?>
 <!-- <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body> -->
 <!-- 	<div class="row blog mt-5 mb-5">
 	<div class="col-md-12"> -->

      <br /><br />
 		<!-- 	<div class="card">
 			<div class="card-body"> -->
 				<!-- <h4 class="header-title mb-0">All Items</h4> -->
 				<!-- <div class="col-lg-6 col-md-6"> -->
 					<div class="col-md-12">
 						<div class="table-responsive">
 							<div class="row">
 								<?php
                        echo $output='';
                        foreach($data->result() as $row)
                        {
                          $output.= '<div class="col-md-3" style="padding:16px; background-color:#f1f1f1; border:1px solid #ccc; margin-bottom:16px; height:400px" align="center">
                          <div class="thumb-content"> 

                          <a href="javascript:void(0)" onclick="openItemDetailDialog('.$row->med_item_id.')" ><img src="'.$row->med_item_image.'" class="img-thumbnail" /></a><br />

                          <p><b>'.$row->med_item_name.'</b></p>
                          <p class="text-danger">LKR '.$row->med_unit_price.'</p>
                          <p class="text-primary" id="'.$row->pharm_id.'"> <b>'.$row->pharm_name .'</b></p>
                          <div class="form-group w-75">';

                          if (($row->med_stock) == 0){
                             $output.='<h4 class="header-title mb0"><p class="text-danger"><b>Out of Stock</b></p></h4><br /> ';
                          }
                          else{
                             $output.='<input type="text" name="quantity" maxlength="3" size="3" class="form-control quantity" id="'.$row->med_item_id.'" placeholder="Enter quantity"/><br /> 
                             <button type="button" name="add_cart" id="button_'.$row->med_item_id.'" class="btn btn-success add_cart" data-productname="'.$row->med_item_name.'" data-price="'.$row->med_unit_price.'" data-productid="'.$row->med_item_id.'" >Add to Cart</button>';
                          }

                          $output.='
                                       
                          
                          </div>
                          </div>
                          </div>

                          ';
                       }

                       echo $output;
                       ?>
 							</div>
<!--  							<div class="col-lg-6 col-md-6">
 								<div id="cart_details">
 									<h3 align="center">Cart is Empty</h3>
 								</div>

 							</div> -->
 			<!-- 	</div>

 			</div> -->
 		</div>

 		<!-- shopping cart area -->

 	</div>



 	<script type="text/javascript">
 	// add items to shopping cart
 	$('.add_cart').click(function(){
 		var med_item_id = $(this).data("productid");
 		var med_item_name = $(this).data("productname");
 		var med_unit_price = $(this).data("price");
   // var med_unit_image = $(this).data("price");
      var pharm_id="<?php echo $row->pharm_id; ?>";

   var quantity = $('#' + med_item_id).val();

   if(quantity != '' && quantity > 0)
   {
   	$.ajax({
   		url:"<?php echo base_url(); ?>order_controller/add_to_cart",
   		method:"POST",
   		data:{med_item_id:med_item_id, med_item_name:med_item_name, med_unit_price:med_unit_price, quantity:quantity,pharm_id:pharm_id},
   		success:function(data)
   		{
   			alert("Product Added into Cart");
   			$('#cart_details').html(data);
   			$('#' + med_item_id).val('');
            $('#below_search').empty();
            console.log(pharm_id);
   		}
   	});
   }else{
   	alert("Please enter quantity!");
   }


});

// loac cart 
// $('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_cart");
$('#cart_details').load("<?php echo base_url(); ?>order_controller/load_cart");


//cear cart
// $(document).on('click', '#clear_cart', function(){
// 	if(confirm("Are you sure you want to clear cart?"))
// 	{
// 		$.ajax({
// 			url:"<?php echo base_url(); ?>shop_controller/clear_cart",
// 			success:function(data)
// 			{
// 				alert("Your cart has been clear...");
// 				$('#cart_details').html(data);
// 			}
// 		});
// 	}
// 	else
// 	{
// 		return false;
// 	}
// });

</script>


<!-- </body>
	</html> -->
	<!-- <div class="container"> -->
