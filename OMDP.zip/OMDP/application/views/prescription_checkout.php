 <?php 
 defined('BASEPATH') OR exit('No direct script access allowed');
 include_once('header.php');

 ?>

 
 <!-- <div class="gradiant-bg" > -->
 	
 	<div class="card-body">
 		<div class="row">

 		</div>
 	</div>
 	<div class="row">

 		<div class="col-md-6">
 			<div class="card-rounded">
 				<div class="card-header"><h4 class="header-title mb0">Enter Your Billing Details</h4></div>	
        <!-- <div class="card-header"><h4 class="header-title mb0"><?php echo $userId; ?></h4></div> -->
 				<div class="card-body" >
 					<!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
 					<!-- <div class="card-text">Test</div>	 -->
 <?php echo form_open_multipart('',array('id' => 'myform')); ?>
          <fieldset>
           <!-- <legend>Register New User </legend> -->
           <div class="form-group">
            <label  class="col-lg-4 control-label">Select Payment Type</label>
            <div class="col-lg-10" id="payment_method_type">
              <select name="med_item_subtype" id="payment_method_select">
                <!-- <option value="Cash">Cash On Delivery</option> -->
                <option value="Credit">Credit Card</option>
                <option value="Debit">Debit Card</option>
                <option value="Cash">Cash On Delivery</option>
                <!-- <option value="Admin">Equipment</option> -->
              </select>
            </div>              
            <div class="col-md-5">
              <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
            </div>  
          </div>
          <div class="form-group">
            <label  class="col-lg-3 control-label">Accepted Cards</label>
            <div class="col-lg-12">
              <i class="fa fa-cc-visa fa-lg" style="color:navy;"></i>
              <i class="fa fa-cc-amex fa-lg" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard fa-lg" style="color:red;"></i>
              <i class="fa fa-cc-discover fa-lg" style="color:orange;"></i>
            </div>
            <div class="col-md-5">
             <?php echo form_error('fname','<div class="text-danger">', '</div>');?>
           </div>
         </div>
         <div class="form-group">
          <label  class="col-lg-3 control-label">Name on Card</label>
          <div class="col-lg-12">
           <input type="text" class="form-control" name="cname" id="cname" placeholder="John Smith">
         </div>
         <div class="col-md-5">
           <?php echo form_error('lname','<div class="text-danger">', '</div>');?>
         </div>
       </div>
       <div class="form-group">
        <label  class="col-lg-4 control-label">Credit Card Number</label>
        <div class="col-lg-12">
         <input type="text" class="form-control" name="cnumber" id="cnumber"  placeholder="Eg : 1111-2222-3333-4444">
       </div>
       <div class="col-md-5">
         <?php echo form_error('email','<div class="text-danger">', '</div>');?>
       </div>  
     </div>       
     <div class="form-group">
      <label  class="col-lg-3 control-label">Expiry Month</label>
      <div class="col-lg-12">
       <input type="text" class="form-control" name="cxpirmonth" id="cxpirmonth" placeholder="Eg : 0703466551">
     </div>
     <div class="col-md-5">
       <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
     </div>  
   </div>
   <div class="form-group">
    <div class="col-lg-12">
     <div class="row">
      <div class="col-md-5">
        <label for="expyear">Exp Year</label>
        <div class="col-md-3">
          <input type="text" id="expyear" name="cexpyear"  placeholder="2018">
        </div>
      </div>
      <div class="col-md-5">
        <label for="cvv">CVV</label>
        <div class="col-md-3">
          <input type="text" id="cvv" name="ccvv"  placeholder="352">
        </div>
      </div>
    </div>
    <div class="col-md-5">
     <?php echo form_error('address_line2','<div class="text-danger">', '</div>');?>
   </div> 
 </div> 
</div>
<div class="form-group"> 
  <div class="container">
    <div class="col-md-8">
      <div class="row">
        <div class="checkbox">
          <label> <input type="checkbox"> I agree that the details I have provided are accurate to my consent </label>
        </div> <!-- checkbox .// -->
      </div>
    </div>
  </div>
</div>
<!-- <div class="form-group">
  <label  class="col-lg-3 control-label">Address : Line 3</label>
  <div class="col-lg-12">
   <input type="text" class="form-control" name="address_line3" placeholder="Eg : 0703466551">
 </div>

 <div class="col-md-5">
   <?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
 </div>  
</div>
<div class="form-group">
  <label  class="col-lg-3 control-label">Land Marks</label>
  <div class="col-lg-12">
   <input type="text" class="form-control" name="order_landmarks" placeholder="Provide some landmarks">
 </div>
 <div class="col-md-5">
   <?php echo form_error('order_landmarks','<div class="text-danger">', '</div>');?>
 </div>  
</div>
<div class="form-group">
  <label  class="col-lg-3 control-label">Additional Comments</label>
  <div class="col-lg-12">
    <input type="text" class="form-control" name="landmarks" placeholder="Eg : Near the Bauddhaloka Temple"> -->
  <!--  <textarea name="order_comments" placeholder="Eg : Near the Bauddhaloka Temple" class="form-control" required rows="8"></textarea>
 </div>
 <div class="col-md-5">
   <?php echo form_error('order_comments','<div class="text-danger">', '</div>');?>
 </div>  
</div> --> 

<div class="form-group">
  <div class="col-lg-12 col-lg-offset-2">
   <?php echo form_submit(['name'=>'submit','value'=> 'Submit to Pharmacy','class'=>'btn btn-primary btn-lg btn-block']);?>

   <!-- <button type="reset" class="btn btn-default btn-lg">Clear</button> -->

 </div>
</div>
<div class="form-group">      
</div>  
</fieldset>
<?php echo form_close(); ?>
 					
 		<!-- 			<a id="test" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/testOrder/<?php echo $userId; ?>')"  aria-expanded="true"><i class="ti-home"></i><span>Test Link</span></a> -->
 				</div>

 			</div>
 		</div>
 		<div class="col-md-6">
 			<div class="card-rounded" id="div_cart" >
        <div class="card-header"><h4 class="header-title mb0">Preview The prescription</h4></div>
 				<div class="card-body">
          <div class="dataTables_wrapper" >
            <table class="dbkit-table">
 			            <!-- <table class="trd-history-tabs"> -->

              <col style="width:20%">
              <col style="width:40%">

              
                <div class="col-sm-6 clearfix"> 
                  <img  class="mv-icon" align="center" src="<?php echo $prescription_image; ?>">
                </div>
                <tr>
                  <th >Pharamcy Name</th>
                  <td><?php echo $prescription_pharm_name; ?></td>
                </tr>
                <tr>
                  <th >Urgency</th>
                  <td><?php echo $prescription_urgency; ?></td>
                </tr>
                <tr>
                  <th >Comments</th>
                  <td><?php echo $prescription_comments; ?></td>
                </tr>
                <tr>
                  <th >Deliver Address</th>
                  <td><?php echo $order_address1.','; ?></td>
                </tr>
                <tr>
                  <!-- <th>Gender</th> -->
                  <td></td><td ><?php echo $order_address2.','; ?></td>
                </tr>
                <tr>
                  <!-- <th>National Id</th> -->
                  <td ></td><td><?php echo $order_address3; ?></td>
                </tr>
  <!--               <tr>
                  <th>User Type</th>
                  <td><?php echo $orderId; ?></td>
                </tr> -->

             
            </table>
          </div>
 					</div>
 				</div>
 			</div>
 		</div>


<!--  		<div class="col-sm-8">
 			<div class="card-rounded" id="div_cart" >
 				<div class="card-body">
 					<div class="col-sm-7">
 						<div id="cart_details">
 							<h3 align="center">Cart is Empty</h3>
 						</div>

 					</div>
 				</div>
 			</div>
 		</div> -->





 <script type="text/javascript">
	// loac cart 


// $(document).ready(function() {

 // change payment method
$('#payment_method_type').change(function() {

  // calc_bill();

  var currPayType=$("#payment_method_type option:selected").text();
  if(currPayType=='Cash On Delivery'){
    $("#cname").prop( "disabled", true );
    $("#cnumber").prop( "disabled", true );
    $("#cexpyear").prop( "disabled", true );
    $("#cxpirmonth").prop( "disabled", true );
    $("#ccvv").prop( "disabled", true );
    // $('#payment_meth').html(currPayType);

  }
  else{
   $("#cname").prop( "disabled", false );
   $("#cnumber").prop( "disabled", false );
   $("#cexpyear").prop( "disabled", false );
   $("#cxpirmonth").prop( "disabled", false );
   $("#ccvv").prop( "disabled", false );
   // $('#payment_meth').html(currPayType);

 }

 
        // Do something with val1 and val2 ...
      });
// clear items to shopping cart

// submit prescription to pharm
$('#myform').submit(function(e){
 e.preventDefault(); 
 // calc_bill(); 
 // $('#orderConfirmModel').dialog({
//   autoOpen:false;
// });

if (confirm('You are about to place the submit request.Proceed with the order?')) {


  var orderId="<?php echo $orderId; ?>";
  var order_pharm_id="<?php echo $order_pharm_id; ?>";
  // var order_final_bill=calc_bill();
  var order_payment_method=$("#payment_method_type option:selected").text();

  // console.log(pharm_id);
  var fd=new FormData(this);
   fd.append('orderId',orderId);
   fd.append('order_pharm_id',order_pharm_id);
   // fd.append('order_final_bill',order_final_bill);
   fd.append('order_payment_method',order_payment_method);


  $.ajax({

   url:"<?php echo base_url(); ?>order_controller/placePrescription",
   method:"POST",
     // data:$(this).serialize(),
     data:fd,    
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });

} else {
  // Do nothing!
  // console.log('Thing was not saved to the database.');
} 


});
 //  $('#myform').submit(function(e){
 //   e.preventDefault();  
 //   var fd=new FormData(this);




  // });
   
 // }); 





</script>

