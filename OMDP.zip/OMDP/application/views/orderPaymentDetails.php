 <?php 
 defined('BASEPATH') OR exit('No direct script access allowed');
 include_once('header.php');

 ?>

 
 <!-- <div class="gradiant-bg" > -->
 	
 	<div class="card-body" >
 		<div class="row">

 		</div>
 	</div>
 	<div class="row" id="myBill">

 		<div class="col-md-6">
 			<div class="card-rounded">
 				<div class="card-header"><h4 class="header-title mb0">Enter your Payment Information</h4></div>	
        <!-- <div class="card-header"><h4 class="header-title mb0"><?php $orderId; ?></h4></div> -->
        <div class="card-body" >
          <!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
          <!-- <div class="card-text">Test</div>	 -->
          <?php echo form_open_multipart('',array('id' => 'myform')); ?>
          <fieldset>
           <!-- <legend>Register New User </legend> -->
           <div class="form-group">
            <label  class="col-lg-4 control-label">Select Payment Type</label>
            <div class="col-lg-10" id="payment_method_type">
              <select name="med_item_subtype" id="payment_method_select">
                <!-- <option value="Cash">Cash On Delivery</option> -->
                <option value="Credit">Credit Card</option>
                <option value="Debit">Debit Card</option>
                <option value="Cash">Cash On Delivery</option>
                <!-- <option value="Admin">Equipment</option> -->
              </select>
            </div>              
            <div class="col-md-5">
              <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
            </div>  
          </div>
          <div class="form-group">
            <label  class="col-lg-3 control-label">Accepted Cards</label>
            <div class="col-lg-12">
              <i class="fa fa-cc-visa fa-lg" style="color:navy;"></i>
              <i class="fa fa-cc-amex fa-lg" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard fa-lg" style="color:red;"></i>
              <i class="fa fa-cc-discover fa-lg" style="color:orange;"></i>
            </div>
            <div class="col-md-5">
             <?php echo form_error('fname','<div class="text-danger">', '</div>');?>
           </div>
         </div>
         <div class="form-group">
          <label  class="col-lg-3 control-label">Name on Card</label>
          <div class="col-lg-12">
           <input type="text" class="form-control" name="cname" id="cname" placeholder="John Smith">
         </div>
         <div class="col-md-5">
           <?php echo form_error('lname','<div class="text-danger">', '</div>');?>
         </div>
       </div>
       <div class="form-group">
        <label  class="col-lg-4 control-label">Credit Card Number</label>
        <div class="col-lg-12">
         <input type="text" class="form-control" name="cnumber" id="cnumber"  placeholder="Eg : 1111-2222-3333-4444">
       </div>
       <div class="col-md-5">
         <?php echo form_error('email','<div class="text-danger">', '</div>');?>
       </div>  
     </div> 			
     <div class="form-group">
      <label  class="col-lg-3 control-label">Expiry Month</label>
      <div class="col-lg-12">
       <input type="text" class="form-control" name="cxpirmonth" id="cxpirmonth" placeholder="Eg : 0703466551">
     </div>
     <div class="col-md-5">
       <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
     </div>  
   </div>
   <div class="form-group">
    <div class="col-lg-12">
     <div class="row">
      <div class="col-md-5">
        <label for="expyear">Exp Year</label>
        <div class="col-md-3">
          <input type="text" id="expyear" name="cexpyear"  placeholder="2018">
        </div>
      </div>
      <div class="col-md-5">
        <label for="cvv">CVV</label>
        <div class="col-md-3">
          <input type="text" id="cvv" name="ccvv"  placeholder="352">
        </div>
      </div>
    </div>
    <div class="col-md-5">
     <?php echo form_error('address_line2','<div class="text-danger">', '</div>');?>
   </div> 
 </div> 
</div>
<div class="form-group"> 
  <div class="container">
    <div class="col-md-8">
      <div class="row">
        <div class="checkbox">
          <label> <input type="checkbox"> I agree that the details I have provided are accurate to my consent </label>
        </div> <!-- checkbox .// -->
      </div>
    </div>
  </div>
</div>
<!-- <div class="form-group">
  <label  class="col-lg-3 control-label">Address : Line 3</label>
  <div class="col-lg-12">
   <input type="text" class="form-control" name="address_line3" placeholder="Eg : 0703466551">
 </div>

 <div class="col-md-5">
   <?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
 </div>  
</div>
<div class="form-group">
  <label  class="col-lg-3 control-label">Land Marks</label>
  <div class="col-lg-12">
   <input type="text" class="form-control" name="order_landmarks" placeholder="Provide some landmarks">
 </div>
 <div class="col-md-5">
   <?php echo form_error('order_landmarks','<div class="text-danger">', '</div>');?>
 </div>  
</div>
<div class="form-group">
  <label  class="col-lg-3 control-label">Additional Comments</label>
  <div class="col-lg-12">
    <input type="text" class="form-control" name="landmarks" placeholder="Eg : Near the Bauddhaloka Temple"> -->
  <!--  <textarea name="order_comments" placeholder="Eg : Near the Bauddhaloka Temple" class="form-control" required rows="8"></textarea>
 </div>
 <div class="col-md-5">
   <?php echo form_error('order_comments','<div class="text-danger">', '</div>');?>
 </div>  
</div> --> 

<div class="form-group">
  <div class="col-lg-12 col-lg-offset-2">
   <?php echo form_submit(['name'=>'submit','value'=> 'Place Your Order','class'=>'btn btn-primary btn-lg btn-block']);?>

   <!-- <button type="reset" class="btn btn-default btn-lg">Clear</button> -->

 </div>
</div>
<div class="form-group">      
</div>  
</fieldset>
<?php echo form_close(); ?>


</div>

</div>
</div>
<!-- Modal -->

<div class="col-md-6">
  <div class="card-rounded" id="div_cart" >
   <div class="card-body">
    <!-- <div class="col-sm-8"> -->
     <div id="cart_details">
      <h3 align="center">Cart is Empty</h3>
    </div>

    <!-- </div> -->
  </div>
</div>
</div>

<!-- Modal -->
<div class="modal fade" id="orderConfirmModel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

</div>


<!--  		<div class="col-sm-8">
 			<div class="card-rounded" id="div_cart" >
 				<div class="card-body">
 					<div class="col-sm-7">
 						<div id="cart_details">
 							<h3 align="center">Cart is Empty</h3>
 						</div>

 					</div>
 				</div>
 			</div>
 		</div> -->





    <script type="text/javascript">
	// loac cart 
  $('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_final_bill");

// clear items to shopping cart

//calculate total
// calculate calc_bill
// $( "#myBill" ).load(function() {
//   // Handler for .load() called.
//    calc_bill();
// });
$(document).ready(function() {
  // calc_bill();
// });




function calc_bill(){
  var item_total = "<?php echo $this->cart->total(); ?>";
  // console.log(item_total);
  var delivery_charge=$("#invoice_table span.delivery_charge").text();
  var discount_price=parseFloat(item_total)*(0.15);
  // console.log(discount_price); 

  // discount_charge
  // $('#delivery_charge').html(discount_price);
  // 
  var delivery_charge=$("#invoice_table span.delivery_charge").text();
  $('#discount_charge').html(discount_price);
  // $('#setDelviery').html(delivery_charge);

  var final_total_bill=parseFloat(item_total) + parseFloat(delivery_charge) - parseFloat(discount_price);

  // grant_total_charge
  $('#grant_total_charge').html(final_total_bill);

  return parseFloat(final_total_bill);


}

var order_final_bill='';

// console.log(jQuery.type(calc_bill()));


// console.log(order_final_bill);


// on change payment method
$('#payment_method_type').change(function() {

  calc_bill();

  var currPayType=$("#payment_method_type option:selected").text();
  if(currPayType=='Cash On Delivery'){
    $("#cname").prop( "disabled", true );
    $("#cnumber").prop( "disabled", true );
    $("#cexpyear").prop( "disabled", true );
    $("#cxpirmonth").prop( "disabled", true );
    $("#ccvv").prop( "disabled", true );
    $('#payment_meth').html(currPayType);

  }
  else{
   $("#cname").prop( "disabled", false );
   $("#cnumber").prop( "disabled", false );
   $("#cexpyear").prop( "disabled", false );
   $("#cxpirmonth").prop( "disabled", false );
   $("#ccvv").prop( "disabled", false );
   $('#payment_meth').html(currPayType);

 }

 
        // Do something with val1 and val2 ...
      });

//place order to Pharmacy
$('#myform').submit(function(e){
 e.preventDefault(); 
 // calc_bill(); 
 // $('#orderConfirmModel').dialog({
//   autoOpen:false;
// });

if (confirm('You are about to place the submit request.Proceed with the order?')) {


  var orderId="<?php echo $orderId; ?>";
  var pharm_id="<?php echo $pharm_id; ?>";
  var order_final_bill=calc_bill();
  var order_payment_method=$("#payment_method_type option:selected").text();

  // console.log(pharm_id);
  var fd=new FormData(this);
   fd.append('orderId',orderId);
   fd.append('pharm_id',pharm_id);
   fd.append('order_final_bill',order_final_bill);
   fd.append('order_payment_method',order_payment_method);


  $.ajax({

   url:"<?php echo base_url(); ?>order_controller/placeOrder",
   method:"POST",
     // data:$(this).serialize(),
     data:fd,    
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });

} else {
  // Do nothing!
  // console.log('Thing was not saved to the database.');
} 


}); 


});
// $('#orderConfirmModel').dialog({
//   autoOpen:false;
// });

// submit order











// console.log(currPayType);







</script>

