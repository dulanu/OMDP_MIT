
 <?php if($msg=$this-> session->flashdata('msg')): ?>
 	<div class="alert alert-dismissible alert-success">  
 		<?php echo $msg;?>
 		<?php unset($_SESSION['msg']); ?>
 		<?php echo "</br>";?>   
 		<a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/update_item_manager/<?php echo $med_pharmacy_id; ?>')">Clear</a>
 	</div>
 <?php endif;?>
 <!-- <div class="row align-items-center"> -->
 	<div class="sales-report-area mt-5 mb-5">
 		<!-- <div class="row"> -->
 			<div class="col-md-6 col-sm-8 clearfix">
 				<div class="search-box pull-left" >
 					<!-- <div class="search-box " > -->
 						
 						<form action="#">
 							
 							<input type="text" name="search" id="search_text" placeholder="Search Your Inventory Here" required align="center">
 							<i class="ti-search"></i>

 						</form>
 					</div>
 				</div>
 			</div>
 		<!-- </div> -->
 		<!-- </div> -->

 		<div class="main-content-inner" id="results">

 		</div>

 		<script type="text/javascript">
 			$(document).ready(function(){

 				load_data();

 				function load_data(query)
 				{
 					$.ajax({
 						url:"<?php echo base_url(); ?>shop_controller/fetch_items_mod_manager/<?php echo $med_pharmacy_id; ?>",
 						method:"POST",
 						data:{query:query},
 						success:function(data){
 							$('#results').html(data);
 						}
 					})
 				}

 				$('#search_text').keyup(function(){
 					var search = $(this).val();
 					if(search != '')
 					{
 						load_data(search);
 					}
 					else
 					{

 					}
 				});
 			});
 		</script>
