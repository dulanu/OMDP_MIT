   

<!-- <div class="main-content-inner">   -->
    <!-- sales card area -->
    <div class="card-body">
        <div class="row">
            <h4 class="header-title mb-0">Dashboard</h4>
        </div>
    </div>
    <!-- <div class="sales-report-area mt-5 mb-5">  -->
        <div class="card">
            <div class="card-header">Overall Statistics</div>
            <div class="card-body">
                <div class="row">
                 <div class="col-md-2 mb-2">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body py-5" ><h1  id="total_orders">0</h1></div>
                        <div class="card-footer d-flex">
                           Total Orders
                           <span class="ms-auto">
                              <i class="bi bi-chevron-right"></i>
                          </span>
                      </div>
                  </div>
              </div>
              <div class="col-md-2 mb-2">
                <div class="card bg-success text-white h-100">
                  <div class="card-body py-5" ><h1  id="active_session"></h1></div>
                  <div class="card-footer d-flex">
                   Total Completed
                   <span class="ms-auto">
                      <i class="bi bi-chevron-right"></i>
                  </span>
              </div>
          </div>
      </div>
      <div class="col-md-2 mb-2">
        <div class="card bg-warning text-white h-100">
          <div class="card-body py-5"><h1  id="total_prescriptions">0</h1></div>
          <div class="card-footer d-flex">
           Total Pending 
           <span class="ms-auto">
              <i class="bi bi-chevron-right"></i>
          </span>
      </div>
  </div>
</div>
<div class="col-md-2 mb-2">
    <div class="card bg-info text-white h-100">
      <div class="card-body py-5"><h1  id="total_dispatched">0</h1></div>
      <div class="card-footer d-flex">
       Total Dispatched 
       <span class="ms-auto">
          <i class="bi bi-chevron-right"></i>
      </span>
  </div>
</div>
</div>
<div class="col-md-2 mb-2">
    <div class="card bg-danger text-white h-100">
      <div class="card-body py-5"><h1  id="total_revenue"></h1></div>
      <div class="card-footer d-flex">
        (LKR) Total Sales
        <span class="ms-auto">
          <i class="bi bi-chevron-right"></i>
      </span>
  </div>
</div>
</div>

<div class="col-md-2 mb-2">
    <div class="card bg-secondary text-white  h-100">
      <div class="card-body py-5"><h1  id="declined_order"></h1>-</div>
      <div class="card-footer d-flex">
        Declined Order
        <span class="ms-auto">
          <i class="bi bi-chevron-right"></i>
      </span>
  </div>
</div>
</div>

</div>


</div>
</div>



<!-- </div> --> 
<div class="card-body">
    <div class="row">

    </div>
</div>
<!-- Bar Chart area   -->
<div class="container-fluid">

    <div class="row">
        <div class="col-md-6 mb-6">
            <div class="card">
                <div class="card-header">Top Selling Items</div>
                <div class="card-body">
                    <canvas id="bar_chart"></canvas>
                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">Order Status</div>
                <div class="card-body">
                    <div class="chart-container pie-chart">
                        <canvas id="pie_chart"></canvas>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-2 mb-2">
            <div class="card">
                <div class="card-header">Stock Statistics</div>
                <div class="card-body">
                    <div class="chart-container pie-chart">
                        <div class="table-responsive" >
                            <table width="100%" id="stock_stats">
                                <tr>
                                    <th height="60px">Total Items</th>
                                    <td><span class="badge badge-pill badge-primary" id="total_count"></td>
                                    </tr>
                                    <tr>
                                        <th height="60px">In Stock</th>
                                        <td><span class="badge badge-pill badge-success" id="in_count"></td>
                                        </tr>
                                        <tr>
                                            <th height="60px">Run Short</th>
                                            <td><span class="badge badge-pill badge-warning" id="run_count"></td>
                                            </tr>
                                            <tr>
                                                <th height="60px">Out of stock</th>
                                                <td><span class="badge badge-pill badge-danger" id="out_count"></td>
                                                </tr>

                                            </table>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
<!--         <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">Doughnut Chart</div>
                <div class="card-body">

                </div>
            </div>
        </div> -->
    </div>

    <div class="card-body">
        <div class="row">

        </div>
    </div>

    <div class="row">
        <div class="col-md-6 mb-6">
            <div class="card">
                <div class="card-header">Sales Last 20 days</div>
                <div class="card-body">
                    <div class="chart-container pie-chart">
                        <canvas id="line_chart"></canvas>
                    </div>

                </div>
            </div>
        </div>
          <div class="col-md-6 mb-6">
            <div class="card">
                <div class="card-header">Orders Last 20 days</div>
                <div class="card-body">
                    <div class="chart-container pie-chart">
                        <canvas id="line_orders"></canvas>
                    </div>

                </div>
            </div>
        </div>
        
    </div>
</div>


<!-- sales report area start -->

<!-- sales report area end -->

<!-- overview area end -->
<!-- market value area start -->

<!-- </div> -->
<script type="text/javascript">
    // $(document).ready(function(){  

     adminDash();

     makeChart();

     function adminDash(){
        //     $.ajax({
        //         url:"<?php echo base_url(); ?>admin_controller/totalRegUsers",
        //         method:"POST",
        //     // data:totalReg,
        //     data:$(this).serialize(),
        //     success:function(data){
        //         $('#reg_users').text(data);
        //         // console.log(data);
        //     }
        // });

        // get total item count
        var pharm_id="<?php echo $pharm_id; ?>";
        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/TotalItemsPharm",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#total_count').text(data);
                // console.log(data);
            }
        });

        // get in stock items count
        var pharm_id="<?php echo $pharm_id; ?>";
        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/InStockItemsPharm",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#in_count').text(data);
                // console.log(data);
            }
        });

        // get items running short
        var pharm_id="<?php echo $pharm_id; ?>";
        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/runShortItemsPharm",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#run_count').text(data);
                // console.log(data);
            }
        });


        //get out of stock items
        var pharm_id="<?php echo $pharm_id; ?>";
        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/outofStockItemsPharm",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#out_count').text(data);
                // console.log(data);
            }
        });

        // total complete
        var pharm_id="<?php echo $pharm_id; ?>";
        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/TotalComplete",
            method:"POST",
            // data:totalReg,
            // data:$(this).serialize(),
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#active_session').text(data);
                // console.log(data);
            }
        });

        // get total orders for day
        var pharm_id="<?php echo $pharm_id; ?>";
        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/TotalOrders",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#total_orders').text(data);
                // console.log(data);
            }
        });



         // get total revenue for pharm
         var pharm_id="<?php echo $pharm_id; ?>";
         $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/TotalRevenue",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#total_revenue').text(data);
                // console.log(data);
            }
        });


         // get total Prescriptions completed
         var pharm_id="<?php echo $pharm_id; ?>";
         $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/TotalPending",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#total_prescriptions').text(data);
                // console.log(data);
            }
        });


         // get total dispatched   total_dispatched
         var pharm_id="<?php echo $pharm_id; ?>";
         $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/TotalDispatched",
            method:"POST",
            // data:totalReg,
            data:{pharm_id:pharm_id},
            success:function(data){
                $('#total_dispatched').text(data);
                // console.log(data);
            }
        });





     }


     function makeChart(){

          // create pie chart
          var pharm_id="<?php echo $pharm_id; ?>";
          $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/getPieChartOrders",
            method:"POST",
            data:{pharm_id:pharm_id},
            dataType:"JSON",
            success:function(data){
                var order_status = [];
                var total = [];
                var color = [];

                for(var count = 0; count < data.length; count++)
                {
                    order_status.push(data[count].order_status);
                    total.push(data[count].total);
                    color.push(data[count].color);
                }

                var chart_data = {
                    labels:order_status,
                    datasets:[
                    {
                        label:'Vote',
                        backgroundColor:color,
                        color:'#fff',
                        data:total
                    }
                    ]
                };

                var options = {
                    responsive:true,
                    scales:{
                        yAxes:[{
                            ticks:{
                                min:0
                            }
                        }]
                    } ,
                    legend : {
                        display : true,
                        position : "bottom"
                    }
                };

                var group_chart1 = $('#pie_chart');

                var graph1 = new Chart(group_chart1, {
                    type:"pie",
                    data:chart_data
                });

                // var group_chart2 = $('#doughnut_chart');

                // var graph2 = new Chart(group_chart2, {
                //     type:"doughnut",
                //     data:chart_data
                // });

                // var group_chart3 = $('#bar_chart');

                // var graph3 = new Chart(group_chart3, {
                //     type:'bar',
                //     data:chart_data,
                //     options:options
                // });

            }

        });


         // get bar chart data
         var pharm_id="<?php echo $pharm_id; ?>";
         $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/getBarChartItems",
            method:"POST",
            data:{pharm_id:pharm_id},
            dataType:"JSON",
            success:function(data){
                var item_name = [];
                var total = [];
                var color = [];

                for(var count = 0; count < data.length; count++)
                {
                    item_name.push(data[count].item_name);
                    total.push(data[count].total);
                    color.push(data[count].color);
                }

                var chart_data = {
                    labels:item_name,
                    datasets:[
                    {
                        label:'Number of Items',
                        backgroundColor:color,
                        color:'#fff',
                        data:total
                    }
                    ]
                };

                var options = {
                    responsive:true,
                    scales:{
                        yAxes:[{
                            ticks:{
                                min:0
                            }
                        }]
                    },
                     legend : {
                        display : true,
                        position : "bottom"
                    }
                };

                // var group_chart1 = $('#pie_chart');

                // var graph1 = new Chart(group_chart1, {
                //     type:"pie",
                //     data:chart_data
                // });

                // var group_chart2 = $('#doughnut_chart');

                // var graph2 = new Chart(group_chart2, {
                //     type:"doughnut",
                //     data:chart_data
                // });

                var group_chart3 = $('#bar_chart');

                var graph3 = new Chart(group_chart3, {
                    type:'bar',
                    data:chart_data,
                    options:options
                });

            }

        });



         // get line chart sales
         var pharm_id="<?php echo $pharm_id; ?>";
         $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/getLineChartItems",
            method:"POST",
            data:{pharm_id:pharm_id},
            dataType:"JSON",
            success:function(data){
                console.log(data);
                var day = [];
                var sales = [];
                // var color = [];

                for(var count = 0; count < data.length; count++)
                {
                    day.push(data[count].day);
                    sales.push(data[count].sales);
                    // color.push(data[count].color);
                }

                var chart_data = {
                    labels:day,
                    datasets:[
                    {
                        label:'Sales',
                        // backgroundColor:'blue',
                        // color:'#fff',
                        borderColor : "lightblue",
                        lineTension : 0,
                        pointRadius : 5,
                        data:sales
                    }
                    ]
                };

                var options = {
                    responsive:true,
                    scales:{
                        yAxes:[{
                            ticks:{
                                min:0
                            }
                        }]
                    },
                    title : {
                        display : true,
                        position : "top",
                        text : "Sales - Last 20 days",
                        fontSize : 18,
                        fontColor : "#111"
                    },
                    legend : {
                        display : true,
                        position : "bottom"
                    }
                };

                // var group_chart1 = $('#pie_chart');

                // var graph1 = new Chart(group_chart1, {
                //     type:"pie",
                //     data:chart_data
                // });

                // var group_chart2 = $('#doughnut_chart');

                // var graph2 = new Chart(group_chart2, {
                //     type:"doughnut",
                //     data:chart_data
                // });

                var group_chart3 = $('#line_chart');

                var graph3 = new Chart(group_chart3, {
                    type:'line',
                    data:chart_data,
                    options:options
                });

            }

        });




         // get line chart daily orders
          // get line chart sales
         var pharm_id="<?php echo $pharm_id; ?>";
         $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/getLineChartOrders",
            method:"POST",
            data:{pharm_id:pharm_id},
            dataType:"JSON",
            success:function(data){
                console.log(data);
                var day = [];
                var orders = [];
                // var color = [];

                for(var count = 0; count < data.length; count++)
                {
                    day.push(data[count].day);
                    orders.push(data[count].orders);
                    // color.push(data[count].color);
                }

                var chart_data = {
                    labels:day,
                    datasets:[
                    {
                        label:'Orders',
                        // backgroundColor:'blue',
                        // color:'#fff',
                        borderColor : "lightblue",
                        lineTension : 0,
                        pointRadius : 5,
                        data:orders
                    }
                    ]
                };

                var options = {
                    responsive:true,
                    scales:{
                        yAxes:[{
                            ticks:{
                                min:0
                            }
                        }]
                    },
                    title : {
                        display : true,
                        position : "top",
                        text : "Orders - Last 20 days",
                        fontSize : 18,
                        fontColor : "#111"
                    },
                    legend : {
                        display : true,
                        position : "bottom"
                    }
                };

                // var group_chart1 = $('#pie_chart');

                // var graph1 = new Chart(group_chart1, {
                //     type:"pie",
                //     data:chart_data
                // });

                // var group_chart2 = $('#doughnut_chart');

                // var graph2 = new Chart(group_chart2, {
                //     type:"doughnut",
                //     data:chart_data
                // });

                var group_chart3 = $('#line_orders');

                var graph3 = new Chart(group_chart3, {
                    type:'line',
                    data:chart_data,
                    options:options
                });

            }

        });

     }



        // refresh content every 5 seconds
        $(function() {
            setInterval(adminDash, 5000);
        });


        // load chart every 1 minute
        $(function() {
            setInterval(makeChart, 300000);
        });
// }
    // });


</script>

