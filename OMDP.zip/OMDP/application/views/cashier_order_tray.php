<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script> 

 
 <!-- <div class="gradiant-bg" > -->
 	
 	<div class="card-body" >
 		<div class="row">
      <!-- <p><?php echo $orderId; ?></p> -->

    </div>
  </div>
  <div class="row" >
    <div class="col-md-6" id="myTray">
      <!--   </div></div> -->
    </div>
    <!-- Modal -->

    <!-- shopping cart -->
    <div class="col-md-6">
      <div class="card-rounded" id="div_cart" >
       <div class="card-body">
        <!-- <div class="col-sm-8"> -->
         <div id="cart_details">
          <h3 align="center">Cart is Empty</h3>
        </div>

        <!-- </div> -->
      </div>
    </div>
  </div>

  <!-- Modal -->


</div>

<div class="row" id="below_search">
  <!-- <p><?php echo $orderId; ?></p> -->

</div>
<!--  		<div class="col-sm-8">
 			<div class="card-rounded" id="div_cart" >
 				<div class="card-body">
 					<div class="col-sm-7">
 						<div id="cart_details">
 							<h3 align="center">Cart is Empty</h3>
 						</div>

 					</div>
 				</div>
 			</div>
 		</div> -->





    <script type="text/javascript">
	// loac cart 
  $('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_cart");

  
  // console.log(pharm_id);
  // console.log(orderId);
// $.ajax({
  var orderId="<?php echo $orderId; ?>";
  $.ajax({
    url:"<?php echo base_url(); ?>order_controller/load_tray/<?php echo $orderId; ?>",
    method:"POST",
    data:{orderId:orderId},
    success:function(data){
      $('#myTray').html(data);
    }
  });
  // myTray


function finishProcess(){

  var orderId="<?php echo $orderId; ?>";
  var pharm_id="<?php echo $pharm_id; ?>";
    console.log(pharm_id);
  console.log(orderId);

  if (confirm('Please double check the items. Are you sure you want to finish  order processing? ')) {



  $.ajax({

   url:"<?php echo base_url(); ?>order_controller/finishProcess/<?php echo $orderId; ?>/<?php echo $pharm_id; ?>",
   method:"POST",
     // data:$(this).serialize(),
    data:{orderId:orderId,pharm_id:pharm_id},    
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }else{

      }
    }

  });

} else {
  // Do nothing!
  // console.log('Thing was not saved to the database.');


} 
}




// clear items to shopping cart


//calculate total
// calculate calc_bill
// $( "#myBill" ).load(function() {
//   // Handler for .load() called.
//    calc_bill();
// });
$(document).ready(function() {
  // calc_bill();
// });


  // $('#myTray').load("<?php echo base_url(); ?>order_controller/load_tray/<?php echo $orderId; ?>");
// live data search
function load_data_tray(query)
{
  $.ajax({
    // url:"<?php echo base_url(); ?>user_controller/fetch_med",
    url:"<?php echo base_url(); ?>order_controller/fetch_new_items_tray/<?php echo $pharm_id; ?>",
    method:"POST",
    data:{query:query},
    success:function(data){
        $('#below_search').html(data);
    }
})
}


// return search results dynamically
$('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
     load_data_tray(search);
 }
 else
 {
   $('#below_search').empty();
}
});
//    url:"<?php echo base_url(); ?>order_controller/load_tray/<?php echo $orderId; ?>",
//    method:"POST",
//      // data:$(this).serialize(),
//      data:{orderId:orderId},    
//      processData: false,
//      contentType: false,
//      cache: false,
//      success:function(data){
//       if (data!='') {
//         $('#myTray').html(data);
//       }
//     }

//   });






});



// finish processing order
// $('#orderConfirmModel').dialog({
//   autoOpen:false;
// });

// submit order
// $(document).on('click', '#clear_cart', function(){
//   if(confirm("Are you sure you want to clear cart?"))
//   {
//     $.ajax({
//       url:"<?php echo base_url(); ?>shop_controller/clear_cart",
//       success:function(data)
//       {
//         alert("Your cart has been clear...");
//         $('#cart_details').html(data);
//       }
//     });
//   }
//   else
//   {
//     return false;
//   }
// });










// console.log(currPayType);







</script>

