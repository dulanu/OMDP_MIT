<!-- <div class="row align-items-center"> -->
	<?php if($msg=$this-> session->flashdata('msg')): ?>
		<div class="alert alert-dismissible alert-success">  
			<?php echo $msg;?>
			<?php unset($_SESSION['msg']); ?>
			<?php echo "</br>";?>   
			<!-- <?php echo anchor('user_controller/main_inner_content_cust/', 'Clear',['class'=>'alert-link'])?> -->
			<a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_ongiong_pres_pharm/<?php echo $pharm_id; ?>')">Clear</a>
		</div>
	<?php endif;?>
	<div class="sales-report-area mt-5 mb-5">
		<!-- <div class="row"> -->
			<div class="col-md-6 col-sm-8 clearfix">
				<h3 >My Ongoing Prescription</h3>

			</div>
		</div>
		<!-- </div> -->
		<!-- </div> -->


		<div class="main-content-inner" id="results">

		</div>

		<script type="text/javascript">
			$(document).ready(function(){

				load_data();

				function load_data(query)
				{
					$.ajax({
						url:"<?php echo base_url(); ?>order_controller/fetch_prescription_ongoing_pharm/<?php echo $pharm_id; ?>",
						method:"POST",
						data:{query:query},
						success:function(data){
							$('#results').html(data);
						}
					})
				}

				$('#search_text').keyup(function(){
					var search = $(this).val();
					if(search != '')
					{
						load_data(search);
					}
					else
					{

					}
				});
			});
		</script>
