<?php  defined('BASEPATH') OR exit('No direct script access allowed');  
include_once('header.php');?>
<head>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->

  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
  <!-- <title>Welcome to Online Medicine Delivery Portal! </title> -->
</head>
<div class="page-title-area">
  <div class="row align-items-center">
    <div class="col-sm-1">
     <div class="logo">
      <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
    </div>
  </div>

  <div class="col-sm-6">
    <div class="breadcrumbs-area clearfix">
      <a href="index.html"> <h3 class="page-title pull-left">Online Medicine Delivery Portal</h3> </a>
    </div>


  </div>
</div>
</div>
<div class="container">
  <br>  <p class="text-center">Cashier Login for Online Medicine Delivery Portal! </p>
  <hr>

  <?php if($msg=$this-> session->flashdata('msg')): ?>
    <div class="alert alert-dismissible alert-success">  
      <?php echo $msg;?>
      <?php unset($_SESSION['msg']); ?>
      <?php echo "</br>";?>   
      <?php echo anchor('shop_controller/login', 'Clear',['class'=>'alert-link'])?>
    </div>
  <?php endif;?>  
  <div class="card">
    <article class="card-body">
      <!-- <a href="" class="float-right btn btn-outline-primary">Sign up</a> -->
      <?php echo anchor('', 'Sign Up',['class'=>'float-right btn btn-outline-primary'])?>
      <h4 class="card-title mb-4 mt-1">Sign in</h4>
      <!-- <form> -->
       <?php echo form_open('shop_controller/login_validator',['class' =>'form-horizontal']); ?> 
       <div class="form-group">
        <label>Your email</label>
        <input name="email" class="form-control" placeholder="myemail@gmail.com" type="email">
      </div> <!-- form-group// -->
      <div class="col-md-5">
        <?php echo form_error('email','<div class="text-danger">', '</div>');?>
      </div>
      <div class="form-group">
        <!-- <a class="float-right" href="#">Forgot Password?</a> -->
        <?php echo anchor('', 'Forgot Password',['class'=>'float-right'])?>
        <label>Your password</label>
        <input name="password" class="form-control" placeholder="******" type="password">
      </div> <!-- form-group// -->
      <div class="col-md-5">
        <?php echo form_error('password','<div class="text-danger">', '</div>');?>
      </div> 
      <div class="form-group">
        <div class="row">
        <label  class="col-lg-2 control-label">Login as a: </label>
      </div>
        <div class="row">
        <div class="col-lg-10">
          <select name="type" id="type">
         <!--    <option value="Customer">Customer</option> -->
            <option value="Cashier">Cashier</option>
            <option value="Manager">Manager</option>
            <!-- <option value="Admin">Admin</option> -->
          </select>
        </div> 
      </div>
      </div>
        <div class="form-group"> 
          <div class="checkbox">
            <label> <input type="checkbox"> Save password </label>
          </div> <!-- checkbox .// -->
        </div> <!-- form-group// -->  
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-block"> Login  </button>
          <button type="reset" class="btn btn-default btn-block">Clear</button>
        </div> <!-- form-group// -->                                                           
        <!-- </form> -->
        <?php echo form_close(); ?>
      </article>
    </div> <!-- card.// -->

    <!-- </aside> col.// -->
  </div>