           <!-- <div class="main-content-inner"> -->
            <!-- shopping cart area -->
<!--             <div class="card-rounded" id="div_cart" >
              <div class="card-body">
                <div class="col-lg-6 col-md-6">
                  <div id="cart_details">
                    <h3 align="center">Cart is Empty</h3>
                  </div>

                </div>
              </div>
            </div> -->
            <!-- market value area start -->
  <?php if($msg=$this-> session->flashdata('msg')): ?>
    <div class="alert alert-dismissible alert-success">  
      <?php echo $msg;?>
      <?php unset($_SESSION['msg']); ?>
      <?php echo "</br>";?>   
      <!-- <?php echo anchor('user_controller/main_inner_content_cust/', 'Clear',['class'=>'alert-link'])?> -->
      <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')">Clear</a>
    </div>
  <?php endif;?>


            <div class="row blog mt-5 mb-5">
              <!-- shopping cart -->
              <div class="col-md-12">
                <div class="card-rounded" id="div_cart" >
                  <div class="card-body">
                    <div class="col-lg-6 col-md-6">
                      <div id="cart_details">
                        <h3 align="center">Cart is Empty</h3>
                      </div>

                    </div>
                  </div>
                </div>
              </div>


              <div class="col-md-12">
               <div class="card">
                <div class="card-body">
                 <div class="d-sm-flex justify-content-between align-items-center">
                  <h4 class="header-title mb-0">Trending Offers</h4>
                  <select class="custome-select border-0 pr-3">
                   <option selected>Last 24 Hours</option>
                 </select>
               </div><div><br></div>
               <div id="blogCarousel" class="carousel slide" data-ride="carousel">

                <ol class="carousel-indicators">
                 <li data-target="#blogCarousel" data-slide-to="0" class="active"></li>
                 <li data-target="#blogCarousel" data-slide-to="1"></li>
               </ol>

               <!-- Carousel items -->
               <div class="carousel-inner">

                 <div class="carousel-item active">
                  <div class="row">
                   <div class="col-md-3">
                    <a href="#">
                     <img src="<?php echo base_url(); ?>images/offers/offer1.png" alt="Image" style="max-width:100%;">
                   </a>
                 </div>
                 <div class="col-md-3">
                  <a href="#">
                   <img src="<?php echo base_url(); ?>images/offers/offer2.jpg" alt="Image" style="max-width:100%;">
                 </a>
               </div>
               <div class="col-md-3">
                <a href="#">
                 <img src="<?php echo base_url(); ?>images/offers/offer3.jpg" alt="Image" style="max-width:100%;">
               </a>
             </div>
             <div class="col-md-3">
              <a href="#">
               <img src="<?php echo base_url(); ?>images/offers/offer4.jpg" alt="Image" style="max-width:100%;">
             </a>
           </div>
         </div>
         <!--.row-->
       </div>
       <!--.item-->

       <div class="carousel-item">
        <div class="row">
         <div class="col-md-3">
          <a href="#">
           <img src="<?php echo base_url(); ?>images/offers/offer5.png" alt="Image" style="max-width:100%;">
         </a>
       </div>
       <div class="col-md-3">
        <a href="#">
         <img src="<?php echo base_url(); ?>images/offers/offer6.jpg" alt="Image" style="max-width:100%;">
       </a>
     </div>
     <div class="col-md-3">
      <a href="#">
       <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
     </a>
   </div>
   <div class="col-md-3">
    <a href="#">
     <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
   </a>
 </div>
</div>
<!--.row-->
</div>
<!--.item-->

</div>
<!--.carousel-inner-->
</div>
<!--.Carousel-->
</div>
</div>
</div>
</div>
<!-- end of offer carousal -->

<!-- Carousel heading -->

<!-- heading end -->
<!-- Item carousel -->
<div class="card">
  <div class="card-body">
   <div class="d-sm-flex justify-content-between align-items-center"><h4 class="header-title mb-0">Best Sellers</h4></div>
 </div>
 <div class="container">
  <!-- <div class="card-body"> -->
    <!-- <div class="card-header">Overall Statistics</div> -->

    <div class="row">
      <div class="col-md-12">
        <div class="card-body">

          <div id="best_seller" class="carousel slide" data-ride="carousel" >
            <!-- Carousel indicators -->
                                     <!--    <ol class="carousel-indicators">
                                            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                            <li data-target="#myCarousel" data-slide-to="1"></li>
                                            <li data-target="#myCarousel" data-slide-to="2"></li>
                                          </ol>  -->  
                                          <!-- Wrapper for carousel items -->
                                          <div class="carousel-inner">
                                            <div class="item carousel-item active">
                                              <div class="row">
                                                <div class="col-sm-3">
                                                  <div class="thumb-wrapper">
                                                    <!-- <span class="wish-icon"><i class="fa fa-heart-o"></i></span> -->
                                                    <div class="img-box">
                                                      <img src="<?php echo base_url(); ?>images/panadol.png" class="img-fluid" alt="">                                 
                                                    </div>
                                                    <div class="thumb-content">
                                                      <h4>Panadol card</h4>                                 
                                                      <div class="star-rating">
                                                        <ul class="list-inline">
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                      </div>                                                       
                                                      <p class="item-price"> <b>LKR 369.00</b></p>
                                                      <a href="#" class="btn btn-primary">Add to Cart</a>
                                                    </div>                      
                                                  </div>
                                                </div>
                                                <div class="col-sm-3">
                                                  <div class="thumb-wrapper">
                                                    <!-- <span class="wish-icon"><i class="fa fa-heart-o"></i></span> -->
                                                    <div class="img-box">
                                                      <img src="<?php echo base_url(); ?>images/piriton.jpg" class="img-fluid" alt="Headphone">
                                                    </div>
                                                    <div class="thumb-content">
                                                      <h4>Piriton Syrup</h4>                                 
                                                      <div class="star-rating">
                                                        <ul class="list-inline">
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                      </div>
                                                      <p class="item-price"> <b>LKR 23.99</b></p>
                                                      <a href="#" class="btn btn-primary">Add to Cart</a>
                                                    </div>                      
                                                  </div>
                                                </div>      
                                                <div class="col-sm-3">
                                                  <div class="thumb-wrapper">
                                                    <!-- <span class="wish-icon"><i class="fa fa-heart-o"></i></span> -->
                                                    <div class="img-box">
                                                      <img src="<?php echo base_url(); ?>images/greentea.png" class="img-fluid" alt="Macbook">
                                                    </div>
                                                    <div class="thumb-content">
                                                      <h4>Millennium Green tea</h4>                                    
                                                      <div class="star-rating">
                                                        <ul class="list-inline">
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star-half-o"></i></li>
                                                        </ul>
                                                      </div>
                                                      <p class="item-price"><b>LKR 649.00</b></p>
                                                      <a href="#" class="btn btn-primary">Add to Cart</a>
                                                    </div>                      
                                                  </div>
                                                </div>                              
                                                <div class="col-sm-3">
                                                  <div class="thumb-wrapper">
                                                    <!-- <span class="wish-icon"><i class="fa fa-heart-o"></i></span> -->
                                                    <div class="img-box">
                                                      <img src="<?php echo base_url(); ?>images/vicks.jpg" class="img-fluid" alt="Nikon">
                                                    </div>
                                                    <div class="thumb-content">
                                                      <h4>Vicks Vapour Rub</h4>                                 
                                                      <div class="star-rating">
                                                        <ul class="list-inline">
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                      </div>
                                                      <p class="item-price"> <b>LKR 250.00</b></p>
                                                      <a href="#" class="btn btn-primary">Add to Cart</a>
                                                    </div>                      
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                            <div class="item carousel-item">
                                              <div class="row">
                                                <div class="col-sm-3">
                                                  <div class="thumb-wrapper">
                                                    <!-- <span class="wish-icon"><i class="fa fa-heart-o"></i></span> -->
                                                    <div class="img-box">
                                                      <img src="<?php echo base_url(); ?>images/hand_sant.jpg" class="img-fluid" alt="Play Station">
                                                    </div>
                                                    <div class="thumb-content">
                                                      <h4>Hand Sanitizers</h4>
                                                      <p class="item-price"><span>$169.00</span></p>
                                                      <div class="star-rating">
                                                        <ul class="list-inline">
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star"></i></li>
                                                          <li class="list-inline-item"><i class="fa fa-star-o"></i></li>
                                                        </ul>
                                                      </div>
                                                      <a href="#" class="btn btn-primary">Add to Cart</a>
                                                    </div>                      
                                                  </div>
                                                </div>

                                              </div>
                                            </div>
                                          </div>
                                          <!-- Carousel controls -->
                                          <a class="carousel-control-prev" href="#best_seller" data-slide="prev">
                                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                          </a>
                                          <a class="carousel-control-next" href="#best_seller" data-slide="next">
                                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                          </a>
                                        </div>
                                      </div>
                                    </div>
                                  </div>

                                </div>
                              </div>

                              <!-- end of top sellers  -->

                              <div class="card-body">
                                <!-- <div class="row"> -->

                                  <!-- </div> -->
                                </div>
                                <!-- sales report area start -->
                                <div class="card">
                                  <div class="card-body">
                                   <div class="d-sm-flex justify-content-between align-items-center"><h4 class="header-title mb-0">Stay Safe This Covid 19!</h4></div></div>
                                   <!-- <div class="sales-report-area mt-5 mb-5"> --><div class="card-body">

                                    <div class="row">
                                      <div class="col-md-4">
                                        <div class="single-report mb-xs-30">
                                          <div class="s-report-inner pr--20 pt--30 mb-3">
                                            <img src="<?php echo base_url(); ?>/images/covid_essentails.png" alt="Image" style="max-width:100%;">
                                          </div>

                                        </div>
                                      </div>
                                      <div class="col-md-4">
                                        <div class="single-report mb-xs-30">
                                          <div class="s-report-inner pr--20 pt--30 mb-3">
                                            <img src="<?php echo base_url(); ?>/images/facemask.png" alt="Image" style="max-width:100%;">
                                          </div>

                                        </div>
                                      </div>
                                      <div class="col-md-4">
                                        <div class="single-report">
                                          <div class="s-report-inner pr--20 pt--30 mb-3">
                                            <img src="<?php echo base_url(); ?>images/order_online.png" alt="Image" style="max-width:100%;">
                                          </div>

                                        </div>
                                      </div>

                                    </div>
                                  </div>
                                </div>
                                <!-- sales report area end -->
                                <!-- sales report area end -->

                                <!-- end of item cart carousal -->
                                <!-- overview area end -->

 <script type="text/javascript">
 

// loac cart 
$('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_cart");


//cear cart
// $(document).on('click', '#clear_cart', function(){
//  if(confirm("Are you sure you want to clear cart?"))
//  {
//    $.ajax({
//      url:"<?php echo base_url(); ?>shop_controller/clear_cart",
//      success:function(data)
//      {
//        alert("Your cart has been clear...");
//        $('#cart_details').html(data);
//      }
//    });
//  }
//  else
//  {
//    return false;
//  }
// });

</script>
        		<!-- </div> -->