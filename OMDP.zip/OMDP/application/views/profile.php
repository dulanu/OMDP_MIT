<!-- <div class="gradiant-bg" > -->
	<div class="card-body">
		<div class="row">
			<!-- <h4 class="header-title mb-0">Dashboard</h4> -->
		</div>
	</div>
	<div class="card-bordered">
		<div class="card-header">View Your Profile</div>	
		<div class="card-body" align="center">
			<!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
			<div class="card-text">Profile Image</div>		
			<!-- <table class="single-table">  -->
				<div class="dataTables_wrapper" >
					<table class="dbkit-table">
						<!-- <table class="trd-history-tabs"> -->

							

							<?php foreach ($query->result_array() as $row): ?>	
								<div class="col-sm-6 clearfix">	
									<img  class="mv-icon" src="<?php echo $row['profile']; ?>">
								</div>
								<tr>
									<th>First Name</th>
									<td><?php echo $row['fName'];?></td>
								</tr>
								<tr>
									<th>Last Name</th>
									<td><?php echo $row['lName'];?></td>
								</tr>
								<tr>
									<th>Email Adress</th>
									<td><?php echo $row['userEmail'];?></td>
								</tr>
								<tr>
									<th>Mobile Number</th>
									<td><?php echo $row['userMobile'];?></td>
								</tr>
								<tr>
									<th>Gender</th>
									<td><?php echo $row['gender'];?></td>
								</tr>
								<tr>
									<th>National Id</th>
									<td><?php echo $row['userNIC'];?></td>
								</tr>
								<tr>
									<th>User Type</th>
									<td><?php echo $row['userType'];?></td>
								</tr>

							<?php endforeach; ?>
						</table>
					</div>
				</div>

			</div>


