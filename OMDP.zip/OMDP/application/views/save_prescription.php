<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
include_once('header.php');

?>
<?php if($msg=$this-> session->flashdata('msg')): ?>
  <div class="alert alert-dismissible alert-success">  
    <?php echo $msg;?>
    <?php unset($_SESSION['msg']); ?>
    <?php echo "</br>";?>   
    <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/save_prescription')">Continue Adding</a>
  </div>
<?php endif;?>  
<!-- <div class="container"> -->
  <br />
  <h3 align="center">Upload and Save Your Prescription</h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <div class="panel-body">
    <?php echo form_open_multipart('',array('id' => 'myform')); ?>
    <fieldset>
      <!-- <legend>Register New User </legend> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">Prescription Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="prescription_name" placeholder="Eg :Daily Diabets Dose 1">
        </div>
        <div class="col-md-5">
          <?php echo form_error('prescription_name','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Upload  prescription</label>
        <div class="col-lg-10">
         <div class="drop-zone">
          <span class="drop-zone__prompt">Drop file here or click to upload</span>
          <input type="file" name="prescription_image" class="drop-zone__input">
        </div>
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_image','<div class="text-danger">', '</div>');?>
      </div>
    </div>
 <!--    <div class="form-group">
      <label class="col-lg-3 control-label">Upload Precription</label>
      <div class="col-lg-10">
        <input type="file" id="myFile" name="prescription_image"> 
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_image','<div class="text-danger">', '</div>');?>
      </div> 
    </div>
 -->
    <div class="form-group">
      <label  class="col-lg-3 control-label">Prescription comments</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="prescription_comments" placeholder="Eg : Please send enough for one month">
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_comments','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Delivery Address Line1 :</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="prescription_adress1" placeholder="No 28/25,">
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_adress1','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Delivery Address Line2 :</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="prescription_adress2" placeholder="Rosmean Place">
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_adress2','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Delivery Address 3</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="prescription_adress3" placeholder="Colombo 7">
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_adress3','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-2 control-label">Notification Email</label>
      <div class="col-lg-10">
        <input type="text" class="form-control" name="prescription_email" placeholder="Eg : sendMyorder@gmail.com">
      </div>
      <div class="col-md-5">
        <?php echo form_error('prescription_email','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Prescription Urgency</label>
      <div class="col-lg-10">
        <select name="prescription_urgency" id="type">
          <option value="Minimum">Minimum</option>
          <option value="Moderate">Moderate</option>
          <option value="Urgent">Urgent</option>
          <option value="Critical">Critical</option>
        </select>
      </div>              
      <div class="col-md-5">
        <?php echo form_error('prescription_urgency','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group"> 
      <!-- <div class="container"> -->
        <div class="col-md-8">
          <div class="row">
            <div class="checkbox">
              <label> <input type="checkbox"> I hereby confirm that the precription I have uploaded is valid and issued by a registered Physician in Sri Lanka </label>
            </div> <!-- checkbox .// -->
          </div>
        </div>
      <!-- </div> -->
    </div>
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
        <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary']);?>

        <button type="reset" class="btn btn-default">Clear</button>

      </div>
    </div>
    <div class="form-group">      
    </div>
  </fieldset>
  <?php echo form_close(); ?>
</div>
</div>
<!-- </div> -->



<script type="text/javascript">
  console.log('<?php echo $prescription_uid; ?>');

  $('#myform').submit(function(e){
   e.preventDefault(); 
     var formData= new FormData(this); //create new formdata
     console.log('<?php echo $prescription_uid; ?>');
     // formData.append('prescription_uid','<?php echo $prescription_uid; ?>'); //append new variable to pharm data
     $.ajax({
       url:"<?php echo base_url(); ?>shop_controller/add_prescription/<?php echo $prescription_uid; ?>",
       method:"POST",
     // data:$(this).serialize(),
     data:formData,
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
         // $("#med_manufact_date").datepicker();  
         // $("#med_exp_date").datepicker(); 
         //focus top
         // $('#top_heading').focus();
       }
     }

   });

   });



</script>
<script src="<?php echo base_url(); ?>shop_controller/assets/js/vendor"></script>
<!-- for image uploader -->

<!-- </body>
</body> -->