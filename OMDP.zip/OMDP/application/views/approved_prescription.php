<!-- <div class="row align-items-center"> -->
	<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script> 
	<div class="sales-report-area mt-5 mb-5">
		<!-- <div class="row"> -->
			<div class="col-md-6 col-sm-8 clearfix">
				<h3 >My Approved Prescription</h3>

			</div>
		</div>
		<!-- </div> -->
		<!-- </div> -->

		<div class="main-content-inner" id="results">

		</div>

		<script type="text/javascript">
			$(document).ready(function(){

				load_data();

				function load_data(query)
				{
					$.ajax({
						url:"<?php echo base_url(); ?>order_controller/fetch_approved_prescription/<?php echo $customerId; ?>",
						method:"POST",
						data:{query:query},
						success:function(data){
							$('#results').html(data);
						}
					})
				}

				$('#search_text').keyup(function(){
					var search = $(this).val();
					if(search != '')
					{
						load_data(search);
					}
					else
					{

					}
				});

				// open dialog box

				// function openCustomerDialog(){

				// 	$('#presApproveModal').modal("show");

				// }
			});
		</script>

	<!-- 	<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
		<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script> -->
