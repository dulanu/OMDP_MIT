   

<!-- <div class="main-content-inner">   -->
    <!-- sales card area -->
    <div class="card-body">
        <div class="row">
            <h4 class="header-title mb-0">Dashboard</h4>
        </div>
    </div>
    <!-- <div class="sales-report-area mt-5 mb-5">  -->
        <div class="card">
            <div class="card-header">Overall Statistics</div>
            <div class="card-body">
                <div class="row">
                   <div class="col-md-3 mb-3">
                    <div class="card bg-primary text-white h-100">
                        <div class="card-body py-5" ><h1  id="total_orders">0</h1></div>
                        <div class="card-footer d-flex">
                         Total Orders
                         <span class="ms-auto">
                          <i class="bi bi-chevron-right"></i>
                      </span>
                  </div>
              </div>
          </div>
          <div class="col-md-3 mb-3">
            <div class="card bg-success text-white h-100">
              <div class="card-body py-5" ><h1  id="active_session"></h1></div>
              <div class="card-footer d-flex">
                 Active Logins
                 <span class="ms-auto">
                  <i class="bi bi-chevron-right"></i>
              </span>
          </div>
      </div>
  </div>
  <div class="col-md-3 mb-3">
    <div class="card bg-warning text-white h-100">
      <div class="card-body py-5"><h1  id="open_pharmacies">0</h1></div>
      <div class="card-footer d-flex">
         Open Pharmacies 
         <span class="ms-auto">
          <i class="bi bi-chevron-right"></i>
      </span>
  </div>
</div>
</div>
<div class="col-md-3 mb-3">
    <div class="card bg-danger text-white h-100">
      <div class="card-body py-5">Primary Card</div>
      <div class="card-footer d-flex">
        Total Value
        <span class="ms-auto">
          <i class="bi bi-chevron-right"></i>
      </span>
  </div>
</div>
</div>
</div> 
</div>
</div>
<!-- </div> --> 
<div class="card-body">
    <div class="row">

    </div>
</div>
<!-- Bar Chart area   -->
<div class="container-fluid">

    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">Bar Chart</div>
                <div class="card-body">

                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">Pie Chart</div>
                <div class="card-body">
                    <div class="chart-container pie-chart">
                        <canvas id="pie_chart"></canvas>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-header">Doughnut Chart</div>
                <div class="card-body">
                    <div class="chart-container pie-chart">
                        <canvas id="doughnut_chart"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- sales report area start -->
<div class="sales-report-area mt-5 mb-5">
    <div class="row">
        <div class="col-md-4">
            <div class="single-report mb-xs-30">
                <div class="s-report-inner pr--20 pt--30 mb-3">
                    <img src="<?php echo base_url(); ?>/images/covid_essentails.png" alt="Image" style="max-width:100%;">
                </div>

            </div>
        </div>
        <div class="col-md-4">
            <div class="single-report mb-xs-30">
                <div class="s-report-inner pr--20 pt--30 mb-3">
                    <img src="<?php echo base_url(); ?>/images/facemask.png" alt="Image" style="max-width:100%;">
                </div>

            </div>
        </div>
        <div class="col-md-4">
            <div class="single-report">
                <div class="s-report-inner pr--20 pt--30 mb-3">
                    <img src="<?php echo base_url(); ?>images/order_online.png" alt="Image" style="max-width:100%;">
                </div>

            </div>
        </div>

    </div>
</div>
<!-- sales report area end -->

<!-- overview area end -->
<!-- market value area start -->
<div class="row blog mt-5 mb-5">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body">
                <div class="d-sm-flex justify-content-between align-items-center">
                    <h4 class="header-title mb-0">Trending Items</h4>
                    <select class="custome-select border-0 pr-3">
                        <option selected>Last 24 Hours</option>
                    </select>
                </div><div><br></div>
                <div id="blogCarousel" class="carousel slide" data-ride="carousel">

                    <ol class="carousel-indicators">
                        <li data-target="#blogCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#blogCarousel" data-slide-to="1"></li>
                    </ol>

                    <!-- Carousel items -->
                    <div class="carousel-inner">

                        <div class="carousel-item active">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                            </div>
                            <!--.row-->
                        </div>
                        <!--.item-->

                        <div class="carousel-item">
                            <div class="row">
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                                <div class="col-md-3">
                                    <a href="#">
                                        <img src="http://placehold.it/250x250" alt="Image" style="max-width:100%;">
                                    </a>
                                </div>
                            </div>
                            <!--.row-->
                        </div>
                        <!--.item-->

                    </div>
                    <!--.carousel-inner-->
                </div>
                <!--.Carousel-->
            </div>
        </div>
    </div>
</div>
<!-- </div> -->
<script type="text/javascript">
    // $(document).ready(function(){  

       adminDash();

       function adminDash(){
        //     $.ajax({
        //         url:"<?php echo base_url(); ?>admin_controller/totalRegUsers",
        //         method:"POST",
        //     // data:totalReg,
        //     data:$(this).serialize(),
        //     success:function(data){
        //         $('#reg_users').text(data);
        //         // console.log(data);
        //     }
        // });


        $.ajax({
            url:"<?php echo base_url(); ?>admin_controller/ActiveSessions",
            method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
                $('#active_session').text(data);
                // console.log(data);
            }
        });

    }

        // refresh content every 5 seconds
        $(function() {
            setInterval(adminDash, 5000);
        });
// }
    // });


</script>

