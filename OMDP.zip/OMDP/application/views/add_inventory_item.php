<?php if($msg=$this-> session->flashdata('msg')): ?>
  <div class="alert alert-dismissible alert-success">  
    <?php echo $msg;?>
    <?php unset($_SESSION['msg']); ?>
    <?php echo "</br>";?>   
    <!-- <?php echo anchor('admin_controller/pharm_reg', 'Continue Adding',['class'=>'alert-link'])?> -->
    <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/add_inventory_item')">Continue Adding</a>
  </div>
<?php endif;?>  
<!-- <div id="reg_form" class="container"> -->
  <br />
  <h3 align="center" id="top_heading">Add Inventory to Your Pharmacy </h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <!-- <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_reg')">Refresh</a> -->

   <div class="panel-body"> 
    <?php echo form_open_multipart('',array('id' => 'myform')); ?>
    <fieldset>
      <!-- <legend>Register New Customer</legend> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">Item Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="med_item_name" >
        </div>
        <div class="col-md-5">
          <?php echo form_error('med_item_name','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Item Brand</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="med_item_brand" >
        </div>
        <div class="col-md-5">
          <?php echo form_error('med_item_brand','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Select Item Type</label>
        <div class="col-lg-10" id="div_item_type_drop">
<!--           <select name="med_item_type" id="type">
            <option value="Diabetes">Diabetes</option>
            <option value="Mother and Baby Care">Mother and Baby Care</option>
            <option value="Covid Essentials">Covid Essentials</option>
            <option value="Personal Care">Personal Care</option>
          </select> -->
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Select Item Subtype</label>
        <div class="col-lg-10" id="div_item_subtype_drop">
<!--           <select name="med_item_subtype" id="type">
            <option value="Customer">Sugar Substitute</option>
            <option value="Cashier">Ayurvedic</option>
            <option value="Manager">Sugar Management</option>
            <option value="Admin">Equipment</option>
          </select> -->
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Item Specifcation</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="med_item_spec" >
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Item Comments</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="med_comments" >
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
<!--       <div class="form-group">
        <label  class="col-lg-3 control-label">Address : Line 3</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="address_line3" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
        </div>  
      </div> -->
      <div class="form-group">
        <label  class="col-lg-3 control-label">Number of Units</label>
        <div class="col-lg-10">
          <input type="number" class="form-control" name="med_stock" >
        </div>
        <div class="col-md-5">
          <?php echo form_error('manager_id','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Unit Price of Item(LKR)</label>
        <div class="col-lg-10">
          <input type="number" class="form-control" name="med_unit_price" step="0.01">
        </div>
        <div class="col-md-5">
          <?php echo form_error('manager_id','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label class="col-lg-3 control-label">Add Item Image</label>
        <div class="col-lg-10">
          <input type="file" id="myFile" name="med_item_image"> 
        </div>
        <div class="col-md-5">
          <?php echo form_error('profile','<div class="text-danger">', '</div>');?>
        </div> 
      </div>
 <!--      <div class="form-group">
        <label  class="col-lg-2 control-label">Confirm Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="conf_password" placeholder="xxxxxxxxxx">
        </div>              
        <div class="col-md-5">
          <?php echo form_error('conf_password','<div class="text-danger">', '</div>');?>
        </div>  
      </div> -->
      <div class="form-group" >
        <label  class="col-lg-3 control-label">Date of Manufacture</label>
        <div class="container"> 
          <div class="row">
            <div class="col-md-3"> 
              <input type="text" class="form-control" id="med_manufact_date" name="med_manufact_date" >
            </div>
 <!--            <div class="col-md-5">  
             <input type="button" name="filter1" id="filter1" value="Chose" class="btn btn-info" />  
           </div>  -->
         </div>
       </div>
       <div class="col-md-5">
        <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Date of Expiry</label>
      <div class="container">
        <div class="row">
          <div class="col-md-3"> 
            <input type="text" class="form-control" id="med_exp_date" name="med_exp_date" >
          </div>
 <!--          <div class="col-md-5">  
           <input type="button" name="filter2" id="filter2" value="Chose" class="btn btn-info" />  
         </div>  -->
       </div>
     </div>
     <div class="col-md-5">
      <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
    </div>  
  </div>
  <div class="form-group"> 
    <div class="container">
      <div class="col-md-8">
        <div class="row">
          <div class="checkbox">
            <label> <input type="checkbox"> I have checked that the item details are correct. Can proceed to Add Item </label>
          </div> <!-- checkbox .// -->
        </div>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-lg-10 col-lg-offset-2">
     <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary','id'=>'formSubmit']);?> 
     <button type="reset" class="btn btn-default">Clear</button>

   </div>
 </div>     
</div>
</fieldset>
<?php echo form_close(); ?>
</div>
</div>
<!-- </div> -->
<!-- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script> -->
<!-- <script type="text/javascript" src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>  
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">   -->

  <script type="text/javascript">
  // $(document).ready(function(){ 





    $('#myform').submit(function(e){
     e.preventDefault(); 
     // console.log($('#med_manufact_date').va)


     man_date=$("#med_manufact_date").val();
     exp_date=$("#med_exp_date").val();
     console.log(man_date);
     console.log(exp_date);
     if(exp_date <= man_date){
       alert("Expiry Date cannot be older or equal to Manufacture date");
     }
     else{
       // console.log($("#med_manufact_date").val());
     var formData= new FormData(this); //create new formdata
     formData.append('med_pharmacy_id','<?php echo $med_pharmacy_id; ?>'); //append new variable to pharm data
     $.ajax({
       url:"<?php echo base_url(); ?>shop_controller/add_med_item_manger/",
       method:"POST",
     // data:$(this).serialize(),
     data:formData,
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
         // $("#med_manufact_date").datepicker();  
         // $("#med_exp_date").datepicker(); 
         //focus top
         // $('#top_heading').focus();
       }
     }

   });

   }



 });  

// load main items of item types
$.ajax({
  url:"<?php echo base_url(); ?>shop_controller/load_type_item",
  method:"POST",
  data:$(this).serialize(),
  dataType:"html",
  success:function(data){
    if (data!='') {
     $('#div_item_type_drop').html(data);
     getsubtypes();
   }
 }

});

//on change output value for subtypes
$('#div_item_type_drop').on('change', function() {
  getsubtypes();
});



// load subtypes for main type
function getsubtypes(){

  // var itemType=$('#div_item_type_drop option:selected').text();

  var itemType=$('#div_item_type_drop option:selected').text();

  console.log(itemType);
  $.ajax({
    url:"<?php echo base_url(); ?>shop_controller/load_subtype_item",
    method:"POST",
     // data:itemType,
     data:{itemType:itemType},
     dataType:"html",
     success:function(data){
      if (data!='') {
       $('#div_item_subtype_drop').html(data);
     }
   }

 });



}

//div_item_subtype_drop







// initialize datepicker
$(document).ready(function(){ 
 $.datepicker.setDefaults({  
  dateFormat: 'yy-mm-dd'   
}); 

 $(function(){  
  $("#med_manufact_date").datepicker();  
  $("#med_exp_date").datepicker();  
});  

// });

  // $('body').on('focus',".med_exp_date", function(){
  //   $(this).datepicker();
});

</script>


<!-- --data:$(this).serialize(), -->




