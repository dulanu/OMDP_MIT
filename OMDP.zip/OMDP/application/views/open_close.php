<!-- <div class="gradiant-bg" > -->
	<div class="card-body">
		<div class="row">
			<!-- <h4 class="header-title mb-0">Dashboard</h4> -->
		</div>
	</div>
	<div class="card-bordered">
		<div class="card-header">Your Pharmacy  Profile</div>	
		<div class="card-body" align="center">
			<!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
			<div class="card-text">Pharmacy Image</div>		
			<!-- <table class="single-table">  -->
				<div class="table-responsive" id="driver_table">		
					<!-- <table class="dbkit-table" column-width="50px" > -->
						<table id="pharm_details"  width="100%" >
							<!-- <table class="trd-history-tabs"> -->

								<col style="width:20%">
								<col style="width:40%">


								<?php foreach ($query->result_array() as $row): ?>	
									<div class="col-sm-6 clearfix">	
										<img  class="mv-icon" src="<?php echo $row['pharm_logo']; ?>">
									</div>
									<tr>
										<th height="60px">Pharmacy Name</th>
										<td><?php echo $row['pharm_name'];?></td>
									</tr>
									<tr>
										<th height="60px">Pharmacy Registration</th>
										<td><?php echo $row['pharm_registration_no'];?></td>
									</tr>
									<tr>
										<th height="60px">Pharmacy Email</th>
										<td><?php echo $row['pharm_email'];?></td>
									</tr>
									<tr>
										<th height="60px">Current Status</th>
										<td id="pharm_status"></td>
									</tr>
									<tr>
										<th height="60px">Open or Close</th>
										<td><button type="button" class="btn btn-success" id="open_button" aria-pressed="false" autocomplete="off">
											Open Pharmacy
										</button>
										<button type="button" class="btn btn-danger" id="close_button" aria-pressed="false" autocomplete="off">
											Close Pharmacy
										</button></td>
									</tr>
								<!-- <tr>
									<th>National Id</th>
									<td><?php echo $row['userNIC'];?></td>
								</tr>
								<tr>
									<th>User Type</th>
									<td><?php echo $row['userType'];?></td>
								</tr> -->

							<?php endforeach; ?>
						</table>
					</div>
				</div>

			</div>


			<script type="text/javascript">
				var pharm_status="<?php echo $row['pharm_status']; ?>";
				if(pharm_status=='open'){
					$('#pharm_status').html('<span class="badge badge-pill badge-success" id="submit_count">open</span>');
					$('#open_button').prop( "disabled", true );
					$('#close_button').prop( "disabled", false );

				}
				else{
					$('#pharm_status').html('<span class="badge badge-pill badge-danger" id="submit_count">closed</span>');
				}


			</script>


