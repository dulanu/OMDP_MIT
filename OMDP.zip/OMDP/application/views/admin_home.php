<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
include_once('header.php');

?>

<body onload="$('#main_content_inner').load('<?php echo base_url(); ?>admin_controller/main_inner_content_admin')">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
          <![endif]-->
          <!-- preloader area start -->
          <div id="preloader">
           <div class="loader"></div>
         </div>
         <!-- preloader area end -->
         <!-- page container area start -->
         <div class="page-container">
           <!-- sidebar menu area start -->
           <div class="sidebar-menu">
            <div class="sidebar-header">
             <div class="logo">
              <a href="index.html"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
            </div>
            <h4 class="user-name dropdown-toggle" align="center">Admin Portal</h4>
          </div>
          <div class="main-menu">
           <div class="menu-inner">
            <nav>
             <ul class="metismenu" id="menu">
              <li class="active">
                <a id="homeLink" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/main_inner_content_admin')"  aria-expanded="true"><i class="ti-home"></i><span>Dashboard</span></a>

             </li>
             <li class="active">
               <a href="javascript:void(0)" aria-expanded="true"><i class="ti-slice"></i><span>Pharmacies</span></a>
               <ul class="collapse">
                <li class="active"><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_reg/<?php echo $profile; ?>')">Add Pharmacy</a></li>
                <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_edit')">Edit Pharmacy</a></li>
                <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/del_pharm')">Delete Pharmacy</a></li>
              </ul>
            </li>
            <li>
             <a href="javascript:void(0)" aria-expanded="true"><i class="ti-user"></i><span>Users
             </span></a>
             <ul class="collapse">
              <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/user_reg')">Add Users</a></li>
              <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/user_edit')">Edit Users</a></li>
              <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/user_del')">Delete Users</a></li>
            </ul>
          </li>
          <li>
           <!-- <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Reminders</span></a> -->
           <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/view_profile/<?php echo $userId; ?>')" aria-expanded="true"><i class="ti-user"></i><span>Profile</span></a>
           <ul class="collapse">
            <li><a href="#">View Profile</a></li>
            <li><a href="#">Edit Profile</a></li>
            <!-- <li><a href="#">xxxxxxxxxxxxx</a></li> -->
          </ul>
        </li>

      </ul>
    </nav>
  </div>
</div>
</div>
<!-- sidebar menu area end -->
<!-- main content area start -->
<div class="main-content">
  <!-- header area start -->
  <div class="header-area">
   <div class="row align-items-center">
    <!-- nav and search button -->
    <div class="col-md-6 col-sm-8 clearfix">
     <div class="nav-btn pull-left">
      <span></span>
      <span></span>
      <span></span>
    </div>
 <!--          <div class="search-box pull-left">
              <form action="#">
                 <input type="text" name="search" placeholder="Search Your Medicine Here" required>
                 <i class="ti-search"></i>
             </form>
           </div> -->
         </div>
         <!-- profile info & task notification -->
         <div class="col-md-6 col-sm-4 clearfix">
           <ul class="notification-area pull-right">
            <li id="full-view"><i class="ti-fullscreen"></i></li>
            <li id="full-view-exit"><i class="ti-zoom-out"></i></li>
            <li class="dropdown">
             <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
              <span>x</span>
            </i>
            <div class="dropdown-menu bell-notify-box notify-box">
              <span class="notify-title">You have new notification <a href="#">view all</a></span>
              <div class="nofity-list">
               <a href="#" class="notify-item">
                <div class="notify-thumb"><i class="ti-key btn-danger"></i></div>
                <div class="notify-text">
                 <p>xxxxxxxxxxxxxx</p>
                 <span>xxxxxxxxx</span>
               </div>
             </a>

           </div>
         </div>
       </li>

       <li class="settings-btn">
         <i class="ti-shopping-cart"></i>
       </li>
     </ul>
   </div>
 </div>
</div>
<!-- header area end -->
<!-- page title area start -->
<div class="page-title-area">
 <div class="row align-items-center">
  <div class="col-sm-6">
   <div class="breadcrumbs-area clearfix">
    <a href="index.html"> <h3 class="page-title pull-left">Online Medicine Delivery Portal</h3> </a>
  </div>


</div>
<div class="col-sm-6 clearfix">
 <div class="user-profile pull-right">
  <img class="avatar user-thumb" src="<?php echo $profile; ?>" alt="avatar">
  <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php echo $username; ?> <i class="fa fa-angle-down"></i></h4>
  <div class="dropdown-menu">
   <a class="dropdown-item" href="#">Settings</a>
   <a class="dropdown-item" href="<?php echo base_url(); ?>admin_controller/logout/<?php echo $sessionId; ?>/<?php echo $userId; ?>">Log Out</a>
 </div>
</div>
</div>
</div>
</div>
<!-- page title area end -->
<!-- <div id="main_profile_inner" class="main-content-inner"></div> -->

<!-- <div id="main_profile_inner" class="table-bordered"></div> -->

<!-- <div id="main_profile_inner" class="main-content-inner"></div>  -->
<div id="main_content_inner" class="main-content-inner">  
 <!-- sales report area start -->
 
</div>

</div>

</div>
</div>
<!-- main content area end -->
<!-- footer area start-->
<footer>
 <div class="footer-area">
  <p>© Copyright 2021. All right reserved.</a>.</p>
</div>
</footer>
<!-- footer area end-->
</div>
<!-- page container area end -->
<!-- offset area start -->

<!-- offset area end -->
<!-- jquery latest version -->
<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
<!-- bootstrap 4 js -->
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/metisMenu.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/jquery.slicknav.min.js"></script>

<!-- start chart js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
<!-- start highcharts js -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<!-- start zingchart js -->
<script src="https://cdn.zingchart.com/zingchart.min.js"></script>
<script type="text/javascript">

  // $(document).ready(function(){

   $('#blogCarousel').carousel({
    interval: 5000
  });


  // $('#main_content_inner').load('<?php echo base_url(); ?>admin_controller/main_inner_content_admin');
  // $('#main_content_inner').load("<?php echo base_url(); ?>admin_controller/main_inner_content_admin");
  

// });
</script>
<!-- all line chart activation -->
<script src="<?php echo base_url(); ?>assets/js/line-chart.js"></script>
<!-- all pie chart -->
<script src="<?php echo base_url(); ?>assets/js/pie-chart.js"></script>
<!-- others plugins -->
<script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
<script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>

</body>

</html>
