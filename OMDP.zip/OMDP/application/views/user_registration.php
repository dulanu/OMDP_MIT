  <?php
  defined('BASEPATH') OR exit('No direct script access allowed');
  include_once('header.php');
  ?>
  
  <!DOCTYPE html>
  <html>
  <head>
   <title>Complete User Registration and Login System in Codeigniter</title>
   <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" /> -->
 </head>
 <body>
  <div class="page-title-area">
    <div class="row align-items-center">
      <div class="col-sm-1">
       <div class="logo">
        <a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
      </div>
    </div>

    <div class="col-sm-6">
      <div class="breadcrumbs-area clearfix">
        <a href="index.html"> <h3 class="page-title pull-left">Online Medicine Delivery Portal</h3> </a>
      </div>


    </div>
  </div>
</div>
<?php if($msg=$this-> session->flashdata('msg')): ?>
  <div class="alert alert-dismissible alert-success">  
    <?php echo $msg;?>
    <?php unset($_SESSION['msg']); ?>
    <?php echo "</br>";?>   
    <?php echo anchor('user_controller/registration', 'Continue Adding',['class'=>'alert-link'])?>
  </div>
<?php endif;?>  
<div class="container">
  <br />
  <h3 align="center">User Registration for OMDP</h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <div class="panel-body">
    <?php echo form_open_multipart('user_controller/register_validator',['class' =>'form-horizontal']); ?>
    <fieldset>
      <!-- <legend>Register with OMDP</legend> -->
       <div class="form-group">
          <label  class="col-lg-2 control-label">Upload  a profile picture</label>
          <div class="col-lg-10">
           <div class="drop-zone">
            <span class="drop-zone__prompt" >Drop file here or click to upload</span>
            <input type="file" id="myFile" name="profile" class="drop-zone__input">
          </div>
        </div>
        <div class="col-md-5">
          
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">First Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="fname" placeholder="First Name">
        </div>
        <div class="col-md-5">
          <?php echo form_error('fname','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Last Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="lname" placeholder="Last Name">
        </div>
        <div class="col-md-5">
          <?php echo form_error('lname','<div class="text-danger">', '</div>');?>
        </div>
      </div>
     <!--  <div class="form-group">
        <label  class="col-lg-2 control-label">Address</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="address" placeholder="Address">
        </div>
        <div class="col-md-5">
          <?php echo form_error('address','<div class="text-danger">', '</div>');?>
        </div>      
      </div> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">Email</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="email" placeholder="Eg : xxx@maildomain.com">
        </div>
        <div class="col-md-5">
          <?php echo form_error('email','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Valid NIC</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="nic" placeholder="Eg : 923395678V">
        </div>
        <div class="col-md-5">
          <?php echo form_error('nic','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Mobile</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="mobile" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label class="col-lg-2 control-label">Gender</label>
        <div class="col-lg-10">
          <div class="radio">
            <label>
              <input type="radio" name="gender" id="optionsRadios1" value="Male" checked="">
              Male
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" name="gender" id="optionsRadios2" value="Female">
              Female
            </label>
          </div>
        </div>
      </div>
    
      <div class="form-group">
        <label  class="col-lg-2 control-label">Enter Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="password" placeholder="xxxxxxxxxx">
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Confirm Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="conf_password" placeholder="xxxxxxxxxx">
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <div class="col-lg-10 col-lg-offset-2">
          <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary']);?>

          <button type="reset" class="btn btn-default">Clear</button>
          
        </div>
      </div>
      <div class="form-group">
        <div class="col-lg-10 col-lg-offset-2">       
          <?php echo anchor('user_controller/login', 'Already Registered?',['class'=>'float-left'])?>  
        </div>
      </div>
    </fieldset>
    <?php echo form_close(); ?>
  </div>
</div>
</div>
<footer>
  <div class="footer-area">
    <p>© Copyright 2021. All right reserved.</a>.</p>
  </div>
</footer>
</body>
<script src="<?php echo base_url(); ?>/assets/js/custom.js"></script> 