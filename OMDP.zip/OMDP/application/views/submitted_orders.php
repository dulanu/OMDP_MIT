<!-- <div class="row align-items-center"> -->
	<div class="sales-report-area mt-5 mb-5">
		<!-- <div class="row"> -->
			<div class="col-md-6 col-sm-8 clearfix">
				<h3 >My Submitted Prescriptions</h3>

			</div>
		</div>
		<!-- </div> -->
		<!-- </div> -->

		<div class="main-content-inner" id="results">

		</div>

		<script type="text/javascript">
			$(document).ready(function(){

				load_data();

				function load_data(query)
				{
					$.ajax({
						url:"<?php echo base_url(); ?>order_controller/fetch_submitted_order/<?php echo $customerId; ?>",
						method:"POST",
						data:{query:query},
						success:function(data){
							$('#results').html(data);
						}
					})
				}

				$('#search_text').keyup(function(){
					var search = $(this).val();
					if(search != '')
					{
						load_data(search);
					}
					else
					{

					}
				});
			});
		</script>
