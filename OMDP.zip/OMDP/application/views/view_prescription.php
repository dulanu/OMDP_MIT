<!-- <div class="gradiant-bg" > -->
	<div class="card-body">
		<div class="row">
			<!-- <h4 class="header-title mb-0">Dashboard</h4> -->
		</div>
	</div>
	<div class="card-bordered">
		<div class="card-header">Your Prescription</div>	
		<div class="card-body" align="center">
			<!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
			<!-- <div class="card-text">Prescription</div>		 -->
			<!-- <table class="single-table">  -->
				<div class="dataTables_wrapper" >
					<table class="dbkit-table">
						<!-- <table class="trd-history-tabs"> -->

							

							<?php foreach ($query->result_array() as $row): ?>	
								<div class="col-sm-6 clearfix">	
									<img  class="mv-icon" src="<?php echo $row['prescription_image']; ?>">
								</div>
								<tr>
									<th>Precription Comments</th>
									<td><?php echo $row['prescription_comments'];?></td>
								</tr>
								<tr>
									<th>Precription Urgency</th>
									<td><?php echo $row['prescription_urgency'];?></td>
								</tr>
								<tr>
									<th>Precription Email</th>
									<td><?php echo $row['prescription_email'];?></td>
								</tr>
								<tr>
									<th>Added Date</th>
									<td><?php echo $row['prescription_createdate'];?></td>
								</tr>
								<tr>
									<th>Delivery Address</th>
									<td><?php echo $row['prescription_adress1'];?></td>
								</tr>
								<tr>
									<th>Street</th>
									<td><?php echo $row['prescription_adress2'];?></td>
								</tr>
								<tr>
									<th>City</th>
									<td><?php echo $row['prescription_adress3'];?></td>
								</tr>

							<?php endforeach; ?>
						</table>
					</div>
				</div>

			</div>


