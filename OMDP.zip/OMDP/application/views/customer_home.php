 <?php 
 defined('BASEPATH') OR exit('No direct script access allowed');
 include('header.php');


 ?>

 <!-- <header> -->

<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>  

<!-- </header> -->

<body onload="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
          <![endif]-->
          <!-- preloader area start -->
          <div id="preloader">
           <div class="loader"></div>
         </div>
         <!-- preloader area end -->
         <!-- page container area start -->
         <div class="page-container">
           <!-- sidebar menu area start -->
           <div class="sidebar-menu">
            <div class="sidebar-header">
             <div class="logo">
              <a href="index.html"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
            </div>
            <h4 class="user-name dropdown-toggle" align="center">Customer Portal for</h4>
            <h3 class="user-name dropdown-toggle" align="center"><b><?php echo $username; ?></b></h3>
          </div>
          <div class="main-menu">
           <div class="menu-inner">
            <nav>
             <ul class="metismenu" id="menu">
              <li class="active">
               <a id="homeLink" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')"  aria-expanded="true"><i class="ti-home"></i><span>Home</span></a>

             </li>
             <li class="active">
               <a href="javascript:void(0)" aria-expanded="true"><i class="ti-receipt"></i><span>My Prescriptions</span></a>
               <ul class="collapse">
                <li class="active"><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/save_prescription/<?php echo $userId; ?>')">Save Prescrition</a></li>
                <li><a href="#">Edit Prescriptions</a></li>
                <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/remove_prescription/<?php echo $userId; ?>')">Delete Prescriptions</a></li>  
              </ul>
            </li>
            <li class="active">
             <a href="javascript:void(0)" aria-expanded="true"><i class="ti-receipt"></i><span>Prescriptions Requests</span><span class="badge badge-pill badge-warning" id="prescription_notif"></span><span class="badge badge-pill badge-danger" id="prescription_reviewing"></a>
               <ul class="collapse">
                <li class="active"><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_submitted_order/<?php echo $userId; ?>')">Submitted Orders<span class="badge badge-pill badge-info" id="submit_count"></span></a></li>
                <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_reviewing_prescription/<?php echo $userId; ?>')">Reviewing Prescriptions<span class="badge badge-pill badge-danger" id="review_count"></a></li>
                 <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_approved_prescription/<?php echo $userId; ?>')">Pending Prescriptions<span class="badge badge-pill badge-warning" id="approve_count"></a></li>

                 </ul>
               </li>
               <li>
                 <a href="javascript:void(0)"  aria-expanded="true"><i class="ti-shopping-cart"></i><span>My Orders
                 </span><span class="badge badge-pill badge-warning" id="order_notif"></span><span class="badge badge-pill badge-info" id="dispatch_count"></a>
                   <ul class="collapse">

                    <li class="active"><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_current_order/<?php echo $userId; ?>')">Pending Orders<span class="badge badge-pill badge-warning" id="order_count"></span></a></li>
                    <!-- <li><a href="#">Current Orders</a></li> -->
                    <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_dispatched_order/<?php echo $userId; ?>')">Dispatched Orders<span class="badge badge-pill badge-info" id="dispatched_count"></a></li>

                      <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_completed_order/<?php echo $userId; ?>')">Completed Orders</a></li>
                    </ul>
                  </li>
                  <li>
                   <!-- <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Reminders</span></a> -->
                   <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/view_profile/<?php echo $userId; ?>')" aria-expanded="true"><i class="ti-user"></i><span>Profile</span></a>
                   <ul class="collapse">
                    <!-- <li><a href="#">View Profile</a></li> -->
                    <li><a href="#">Edit Profile</a></li>
                    <!-- <li><a href="#">xxxxxxxxxxxxx</a></li> -->
                  </ul>
                </li>

              </ul>
            </nav>
          </div>
        </div>
      </div>
      <!-- sidebar menu area end -->
      <!-- main content area start -->
      <div class="main-content">
        <!-- header area start -->
        <div class="header-area">
         <div class="row align-items-center">
          <!-- nav and search button -->
          <div class="col-md-6 col-sm-8 clearfix">
           <div class="nav-btn pull-left">
            <span></span>
            <span></span>
            <span></span>
          </div>
<!--                   <div class="search-box pull-left">
                      <form action="#">
                         <input type="text" name="search" id="search_text" placeholder="Search Your Medicine Here" required>
                         <i class="ti-search"></i>
                     </form>
                   </div> -->
                   <div class="row align-items-center">
                    <div class="breadcrumbs-area clearfix">
                      <a href="<?php echo base_url(); ?>"> <h4 class="page-title pull-left">Online Medicine Delivery Portal</h4> </a>
                    </div>
                  </div>
                </div>
                <!-- profile info & task notification -->
                <div class="col-md-6 col-sm-4 clearfix">
                 <ul class="notification-area pull-right">
                  <li id="upload_prescription"><a class="btn btn-success" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/upload_prescription/<?php echo $userId; ?>')"role="button">Submit Prescritpion</a></li>
                  <li id="full-view"><i class="ti-fullscreen"></i></li>
                  <li id="full-view-exit"><i class="ti-zoom-out"></i></li>
                  <li class="dropdown">
                   <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
                    <span>x</span>
                  </i>
                  <div class="dropdown-menu bell-notify-box notify-box">
                    <span class="notify-title">You have new notification <a href="#">view all</a></span>
                    <div class="nofity-list">
                     <a href="#" class="notify-item">
                      <div class="notify-thumb"><i class="ti-key btn-danger"></i></div>
                      <div class="notify-text">
                       <p>xxxxxxxxxxxxxx</p>
                       <span>xxxxxxxxx</span>
                     </div>
                   </a>

                 </div>
               </div>
             </li>

             <li class="settings-btn" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/current_order')"><i class="ti-shopping-cart"><span>x</span></i>

             </li>
           </ul>
         </div>
       </div>
     </div>
     <!-- header area end -->
     <!-- page title area start -->
     <div class="page-title-area">
       <div class="row align-items-center">
        <div class="col-sm-6">
 <!--        					<div class="breadcrumbs-area clearfix">
        						<a href="index.html"> <h4 class="page-title pull-left">Online Medicine Delivery Portal</h4> </a>
        					</div> -->
                  <div class="search-box pull-left">
                    <form idaction="#">
                      <input type="text" name="search" id="search_text" placeholder="Search Your Medicine Here" required>
                      <i class="ti-search"></i>
                    </form>
                  </div>


                </div>
                <div class="col-sm-6 clearfix">
                 <div class="user-profile pull-right">
                  <img class="avatar user-thumb" src="<?php echo $profile; ?>" alt="avatar">
                  <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php echo $username; ?> <i class="fa fa-angle-down"></i></h4>
                  <div class="dropdown-menu">
                   <a class="dropdown-item" href="#">Settings</a>
                   <a class="dropdown-item" href="<?php echo base_url(); ?>user_controller/logout/<?php echo $sessionId; ?>/<?php echo $userId; ?>">Log Out</a>
                 </div>
               </div>
             </div>
           </div>
         </div>
         <!-- item categorie nav  bar -->

         <!-- item categoried end -->
         <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light"></nav> -->
         <!-- page title area end -->

         <!-- nav bar item categries -->

         <!-- nav bar item categoried end --> 
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <!-- <nav class="navbar navbar-dark bg-dark"> -->
            <!-- <a class="navbar-brand" href="#">Navbar</a> -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item dropdown">
                  <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                  <a class="nav-link dropdown-toggle" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/list_type_items/Baby\+and\+Mother\+Care/')" id="baby_n_mother_care" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Baby and Mother Care
                  </a>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#">Skin and Bath essentials</a>
                    <a class="dropdown-item" href="#">Food ad Milk Essentials</a>
                    <!-- <div class="dropdown-divider"></div> -->
                    <a class="dropdown-item" href="#">Baby Diaper</a>
                    <a class="dropdown-item" href="#">Feeding and Oral</a>
                    <a class="dropdown-item" href="#">Health Care</a>
                    <a class="dropdown-item" href="#">Mother Care</a>
                    <a class="dropdown-item" href="#">Baby Wipes</a>
                    <a class="dropdown-item" href="#">Pregnancy Care</a>
                  </div>
                </li>
                    <!--   <li class="nav-item active">
                        <a class="nav-link" href="#"> Diabetes<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/list_type_items/Diabetes/')" id="diabetic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Diabetes
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Diabetes Ayurvedic</a>
                          <a class="dropdown-item" href="#">Sugar Substitutes</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Sugar Management Supplements</a>
                          <a class="dropdown-item" href="#">Diabetic Equipment</a>
                          <!-- <a class="dropdown-item" href="#">Diabetic Devices</a> -->
                        </div>
                      </li>
 <!--                    <li class="nav-item active">
                        <a class="nav-link" href="#"> Ayurvedic<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/list_type_items/Ayurvedic/')" id="ayurvedic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Ayurvedic
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/list_type_items/Ayurvedic/')"> Food Supplements</a>
                          <a class="dropdown-item" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/list_all_items/Ayurvedic')">Immunity</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/list_all_items')">Health Care</a>
                          <!-- <a class="dropdown-item" href="#">Diabetic Equipment</a> -->
                        </div>
                      </li>
            <!--         <li class="nav-item dropdown">
                        <a class="nav-link " href="#"> Health-Care<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="personal_care" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Personal Care
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Body Care</a>
                          <a class="dropdown-item" href="#"> Eye Care</a>
                          <a class="dropdown-item" href="#"> Home Care</a>
                          <a class="dropdown-item" href="#"> Face Care</a>
                          <a class="dropdown-item" href="#"> Hair Care</a>
                          <a class="dropdown-item" href="#">Men Care</a>
                          <a class="dropdown-item" href="#">Skin Care</a>
                          <a class="dropdown-item" href="#">Women Care</a>
                          <a class="dropdown-item" href="#">Oral Care</a>
                        </div>
                      </li>
<!--                     <li class="nav-item active">
                        <a class="nav-link " href="#"> Nutrition<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="nutrition_supplement" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Nutrition and Supplements
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Nutrition Drinks</a>
                          <a class="dropdown-item" href="#">Multi Vitamins</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Speciality Suppliments</a>
                          <a class="dropdown-item" href="#">Protein Suppliments</a>
                          <a class="dropdown-item" href="#">Health and Food</a>
                        </div>
                      </li>
<!--                     <li class="nav-item active">
                        <a class="nav-link " href="#"> Suppliments<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="covid_essentials" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Covid 19 Essentials
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Hand Sanitizers</a>
                          <a class="dropdown-item" href="#">Hand Washes</a>
                          <a class="dropdown-item" href="#">Devices</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Masks</a>
                          <a class="dropdown-item" href="#">Disinfectants</a>
                          <a class="dropdown-item" href="#">Immunity Boosters</a>
                        </div>
                      </li>

                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="health_condition" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Health Condition
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Bone and joint</a>
                          <a class="dropdown-item" href="#">Live</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Kidney</a>
                          <a class="dropdown-item" href="#">Stomach</a>
                          <a class="dropdown-item" href="#">Diabetic</a>
                          <a class="dropdown-item" href="#">Lung</a>
                          <a class="dropdown-item" href="#">Mental</a>
                          <a class="dropdown-item" href="#">Cold and Fever</a>
                          <a class="dropdown-item" href="#">Weight</a>
                          <a class="dropdown-item" href="#">Cardial</a>
                          <a class="dropdown-item" href="#">Immunity</a>
                          <a class="dropdown-item" href="#">Pain relief</a>
                        </div>
                      </li>
 <!--                    <li class="nav-item active">
                        <a class="nav-link " href="#"> Pharmacies </a>
                      </li> -->

                    </ul>
                  </div>  
                </nav>


                <!-- nav bar item category end -->



                <!-- <div id="main_profile_inner" class="main-content-inner"></div>  -->
                <div id="main_content_inner" class="main-content-inner">  
                 <!-- sales report area start -->
                 <!-- page title area end -->
                 <!-- <div class="main-content-inner"> -->
                  <!-- sales report area start -->

                </div>

              </div>




            </div>
          </div>

        </div>
      </div>

      <!-- modal for submit prescriptions -->
      <div id="presApproveModal" class="modal fade">  
        <div class="modal-dialog modal-lg">  
         <div class="modal-content">  
          <div class="modal-header">  
           <!-- <button type="button" class="close" data-dismiss="modal">&times;</button>   -->
           <h4 class="modal-title" id="model_title">Quotation Details</h4> 
           <button type="button" class="close" data-dismiss="modal">&times;</button> 
         </div>  
         <div class="modal-body" id="order_details">  
         </div>  
         <div class="modal-footer"> 
           <!-- <button type="button" id="accept_pres" class="btn btn-success">Accept Offer</button>  -->
           <!-- <button type="button" class="btn btn-danger">Reject Offer</button> -->
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
         </div>  
       </div>  
     </div>  
   </div> 
   <!-- main content area end -->
   <!-- footer area start-->
   <footer>
     <div class="footer-area">
      <p>© Copyright 2021. All right reserved.</a>.</p>
      <!-- </div> -->
    </footer>
    <!-- footer area end-->
    <!-- </div> -->
    <!-- page container area end -->
    <!-- offset area start -->

    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script> 
    
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script> 

    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.slicknav.min.js"></script>

    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
     $('#blogCarousel').carousel({
      interval: 5000
    });
  </script>
  <!-- all line chart activation -->
  <script src="<?php echo base_url(); ?>assets/js/line-chart.js"></script>
  <!-- all pie chart -->
  <script src="<?php echo base_url(); ?>assets/js/pie-chart.js"></script>
  <!-- others plugins -->
  <script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){

        //if empty go to home page


// live data search
function load_data(query)
{
  $.ajax({
    // url:"<?php echo base_url(); ?>user_controller/fetch_med",
    url:"<?php echo base_url(); ?>user_controller/fetch_new_items",
    method:"POST",
    data:{query:query},
    success:function(data){
      $('#main_content_inner').html(data);
    }
  })
}

// open modal dialog box to customer

// $('.cust_order_model').click(function(){
//   var orderId = $(this).attr("id"); 
//        $('#presApproveModal').modal("show");


// });

// return search results dynamically
$('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
 }
 else
 {
   $('#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')
 }
});

// carousel refresh
$('#best_seller').carousel({
  interval: 5000
});



});

// loac cart 
$('#cart_details').load("<?php echo base_url(); ?>shop_controller/<?php echo $userId; ?>");

// clear items to shopping cart
//cear cart
$(document).on('click', '#clear_cart', function(){
  if(confirm("Are you sure you want to clear cart?"))
  {
    $.ajax({
      url:"<?php echo base_url(); ?>shop_controller/clear_cart",
      success:function(data)
      {
        alert("Your cart has been Cleared!");
        $('#cart_details').html(data);
      }
    });
  }
  else
  {
    return false;
  }
});


// remove item from cart_details 
$(document).on('click', '.remove_inventory', function(){
  var row_id = $(this).attr("id");
  if(confirm("Are you sure you want to remove this?"))
  {
   $.ajax({
    url:"<?php echo base_url(); ?>shop_controller/remove_cart_item",
    method:"POST",
    data:{row_id:row_id},
    success:function(data)
    {
     alert("Product removed from Cart");
     $('#cart_details').html(data);
   }
 });
 }
 else
 {
   return false;
 }
});

//proceed to checkout
function checkoutOrder(){
  var userId="<?php echo $userId; ?>";
  $.ajax({
    // url:"<?php echo base_url(); ?>user_controller/fetch_med",    
    // url:"<?php echo base_url(); ?>shop_controller/checkout",
    url:"<?php echo base_url(); ?>shop_controller/checkout/",
    method:"POST",
    data:{userId:userId},
    success:function(data){
      $('#main_content_inner').html(data);
    }
  })

}


// open dialog box prescriptions
function openCustomerDialog(orderId){

    // var userId="<?php echo $userId; ?>";
    var orderId=orderId;
    $.ajax({

      url:"<?php echo base_url(); ?>order_controller/fetch_modal_quote_prescription/",
      method:"POST",
      data:{orderId:orderId},
      success:function(data){
        $('#order_details').html(data);
        $('#presApproveModal').modal("show");
      }
    })

  }


// open dialog box prescriptions
function openItemDetailDialog(med_item_id){

    // var userId="<?php echo $userId; ?>";
    var med_item_id=med_item_id;
    $.ajax({

      url:"<?php echo base_url(); ?>order_controller/fetch_modal_item_description/",
      method:"POST",
      data:{med_item_id:med_item_id},
      success:function(data){
        $('#model_title').html("Product Details");
        $('#order_details').html(data);
        $('#presApproveModal').modal("show");
      }
    })

  }


// fetch item description modal


// proceed order
function proceedOrder(orderId,pharm_id){
  var orderId=orderId;
  var pharm_id=pharm_id;

  $.ajax({
    url:"<?php echo base_url(); ?>order_controller/placeOrder",
    method:"POST",
    data:{orderId:orderId,pharm_id:pharm_id},
    success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
      
    }
  })
  

}


// accept prescription quotation customer
// $('#accept_pres').click(function(){

//    var orderId=$("#modal_prescription_table span.modal_prescription_orderid").text();
//    console.log($orderId);


// });




function checkoutPrescription(){
  var userId="<?php echo $userId; ?>";
  $.ajax({
    // url:"<?php echo base_url(); ?>user_controller/fetch_med",    
    // url:"<?php echo base_url(); ?>shop_controller/checkout",
    url:"<?php echo base_url(); ?>shop_controller/checkout/",
    method:"POST",
    data:{userId:userId},
    success:function(data){
      $('#main_content_inner').html(data);
    }
  })

}
// function checkout($userId){
//     $.ajax({
//     // url:"<?php echo base_url(); ?>user_controller/fetch_med",
//     url:"<?php echo base_url(); ?>shop_controller/checkout",
//     method:"POST",
//     data:{userId:userId},
//     success:function(data){
//       $('#main_content_inner').html(data);
//     }
//   })

// }

//proceed to checkout
function continueShopping(){
  var userId="<?php echo $userId; ?>";
  $.ajax({
    // url:"<?php echo base_url(); ?>user_controller/fetch_med",    
    // url:"<?php echo base_url(); ?>shop_controller/checkout",
    url:"<?php echo base_url(); ?>user_controller/main_inner_content_cust/",
    method:"POST",
    data:{userId:userId},
    success:function(data){
      $('#main_content_inner').html(data);
    }
  })

}

 // get current order count
 notifCations();

 function notifCations(){



  // get approved prescriptions
  $.ajax({
    url:"<?php echo base_url(); ?>order_controller/get_approve_presc_count/<?php echo $userId; ?>",
    method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#prescription_notif').text('New');
                // console.log(data);}
                $('#approve_count').text(data);

              }
              else{
                $('#prescription_notif').text('');
                // console.log(data);}
                $('#approve_count').text('');
              }
            }
          });


  // get notification of  submitted Prescriptions
  $.ajax({
    url:"<?php echo base_url(); ?>order_controller/get_submit_presc_count/<?php echo $userId; ?>",
    method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                // $('#prescription_notif').text('New');
                // console.log(data);}
                $('#submit_count').text(data);

              }
              else{
                // $('#prescription_notif').text('');
                // console.log(data);}
                $('#submit_count').text('');
              }
            }
          });

// get reviewing prescriptions
$.ajax({
  url:"<?php echo base_url(); ?>order_controller/get_review_presc_count/<?php echo $userId; ?>",
  method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#prescription_reviewing').text(data);
                // console.log(data);}
                $('#review_count').text(data);

              }
              else{
                $('#prescription_reviewing').text('');
                // console.log(data);}
                $('#review_count').text('');
              }
            }
          });


// get pending orders
$.ajax({
  url:"<?php echo base_url(); ?>order_controller/get_current_count/<?php echo $userId; ?>",
  method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#order_notif').text('New');
                // console.log(data);}
                $('#order_count').text(data);

              }
              else{
                $('#order_notif').text('');
                // console.log(data);}
                $('#order_count').text('');
              }
            }
          });



$.ajax({
  url:"<?php echo base_url(); ?>order_controller/get_dispatch_count/<?php echo $userId; ?>",
  method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#dispatch_count').text(data);
                // console.log(data);}
                $('#dispatched_count').text(data);

              }
              else{
                $('#dispatch_count').text('');
                // console.log(data);}
                $('#dispatched_count').text('');
              }
            }
          });

}

        // refresh content every 5 seconds
        $(function() {
          setInterval(notifCations, 5000);
        });


      </script>
    </body>

    </html>
