 <?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 include_once('header.php');
 ?>

 

 <!-- <div id="reg_form" class="container"> -->
  <br />
  <h3 align="center">Edit Pharmacy Details</h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <!-- <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_reg')">Refresh</a> -->

   <div class="panel-body"> 
    <?php echo form_open_multipart('',array('id' => 'myform')); ?>
    <fieldset>
      <!-- <legend>Register New Customer</legend> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">Pharmacy Name</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="pharm_name" placeholder="Eg : New Pharmacy Ltd(Pvt)"> -->
          <?php echo form_input(['name'=>'pharm_name','class'=>'form-control','value'=>set_value('pharm_name',$data->pharm_name)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_name','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Pharmacy Email</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="pharm_email" placeholder="Eg : xxx@maildomain.com"> -->
          <?php echo form_input(['name'=>'pharm_email','class'=>'form-control','value'=>set_value('pharm_email',$data->pharm_email)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_email','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Pharmacy Telephone</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="pharm_phone" placeholder="Eg : 01123456677"> -->
          <?php echo form_input(['name'=>'pharm_phone','class'=>'form-control','value'=>set_value('pharm_phone',$data->pharm_phone)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_phone','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Pharmacy Registration</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="pharm_registration_no" placeholder="Eg: REG/XX/XXXXXX"> -->
          <?php echo form_input(['name'=>'pharm_registration_no','class'=>'form-control','value'=>set_value('pharm_registration_no',$data->pharm_registration_no)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_registration_no','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Pharmacy Address : Line 1</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="address_line1" placeholder="Eg : 0703466551"> -->
          <?php echo form_input(['name'=>'address_line1','class'=>'form-control','value'=>set_value('address_line1',$data->address_line1)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Address : Line 2</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="address_line2" placeholder="Eg : 0703466551"> -->
          <?php echo form_input(['name'=>'address_line2','class'=>'form-control','value'=>set_value('address_line2',$data->address_line2)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('address_line2','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Address : Line 3</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="address_line3" placeholder="Eg : 0703466551"> -->
          <?php echo form_input(['name'=>'address_line3','class'=>'form-control','value'=>set_value('address_line3',$data->address_line3)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
<!--       <div class="form-group">
        <label class="col-lg-3 control-label">Update Display Logo</label>
        <div class="col-lg-10">
          <input type="file" id="myFile" name="profile"> 
        </div>
        <div class="col-md-5">
          <?php echo form_error('profile','<div class="text-danger">', '</div>');?>
        </div> 
      </div> --> 
      <div class="form-group">
        <div class="col-lg-10 col-lg-offset-2">
         <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary','id'=>'formSubmit']);?> 
         <button type="reset" class="btn btn-default">Clear</button>

       </div>
     </div>     
   </div>
 </fieldset>
 <?php echo form_close(); ?>
</div>
</div>
<!-- </div> -->
<script type="text/javascript">

  $('#myform').submit(function(e){
   e.preventDefault();  
   $.ajax({
     url:"<?php echo base_url(); ?>/admin_controller/update_pharm_info/<?php echo $data->pharm_id; ?>",
     method:"POST",
     data:$(this).serialize(),
     // data:{data:data},
     dataType:"html",
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });
   
 });  
</script>

<!-- --data:$(this).serialize(), -->




