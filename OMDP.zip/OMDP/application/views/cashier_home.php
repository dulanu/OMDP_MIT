  <?php 
  defined('BASEPATH') OR exit('No direct script access allowed');
  include_once('header.php');

  ?>
 <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script> 

  <body onload="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')">
    <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
          <![endif]-->
          <!-- preloader area start -->
          <div id="preloader">
           <div class="loader"></div>
         </div>
         <!-- preloader area end -->
         <!-- page container area start -->
         <div class="page-container">
           <!-- sidebar menu area start -->
           <div class="sidebar-menu">
            <div class="sidebar-header">
             <div class="logo">
              <a href="index.html"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
              <h4 class="user-name dropdown-toggle" align="center">Pharmacist Portal for</h4>
              <h3 class="user-name dropdown-toggle" align="center"><b><?php echo $pharm_name; ?></b></h3>
            </div>
          </div>
          <div class="main-menu">
           <div class="menu-inner">
            <nav>
             <ul class="metismenu" id="menu">
              <li class="active">
               <a id="homeLink" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')"  aria-expanded="true"><i class="ti-home"></i><span>Home</span></a>

             </li>
             <li class="active">
               <a href="javascript:void(0)" aria-expanded="true"><i class="ti-receipt"></i><span>Prescriptions</span><span class="badge badge-pill badge-warning" id="pres_notif"></span><span class="badge badge-pill badge-danger" id="reviewing_count"></span></a>
               <ul class="collapse">
                <li class="active"><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_incoming_pres_pharm/<?php echo $pharm_id; ?>')">Incoming Prescrition<span class="badge badge-pill badge-warning" id="pres_count"></span></a></li>
                <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_ongiong_pres_pharm/<?php echo $pharm_id; ?>')">Pending Prescriptions<span class="badge badge-pill badge-danger" id="review_count"></span></a></li>
                <!-- <li><a href="#">Completed Prescriptions</a></li> -->
              </ul>
            </li>
            <li>
             <a href="javascript:void(0)"  aria-expanded="true"><i class="ti-shopping-cart"></i><span>My Orders
             </span></span><span class="badge badge-pill badge-warning" id="order_notif"></span><span class="badge badge-pill badge-primary" id="ongoinged_count"></span></a>
             <ul class="collapse">
              <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_current_order_pharm/<?php echo $pharm_id; ?>')">Incoming Orders<span class="badge badge-pill badge-warning" id="order_count"></span></a></li>
              <li class="active"><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_ongoing_order_pharm/<?php echo $pharm_id; ?>')">Pending Order<span class="badge badge-pill badge-primary" id="ongoing_count"></span></a></li>
              <!-- <li><a href="#">Current Orders</a></li> -->
              <li><a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/get_completed_order_pharm/<?php echo $pharm_id; ?>')">Completed Orders</a></li>
              <!-- <li><a href="#">Pending Orders</a></li> -->
              <!-- <li><a href="#">Incoming Orders</a></li> -->
            </ul>
          </li>
          <li>
           <!-- <a href="javascript:void(0)" aria-expanded="true"><i class="ti-pie-chart"></i><span>Reminders</span></a> -->
           <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/view_profile/<?php echo $userId; ?>')" aria-expanded="true"><i class="ti-user"></i><span>Profile</span></a>
           <ul class="collapse">
            <!-- <li><a href="#">View Profile</a></li> -->
            <li><a href="#">Edit Profile</a></li>
            <!-- <li><a href="#">xxxxxxxxxxxxx</a></li> -->
          </ul>
        </li>

      </ul>
    </nav>
  </div>
</div>
</div>
<!-- sidebar menu area end -->
<!-- main content area start -->
<div class="main-content">
  <!-- header area start -->
  <div class="header-area">
   <div class="row align-items-center">
    <!-- nav and search button -->
    <div class="col-md-6 col-sm-8 clearfix">
     <div class="nav-btn pull-left">
      <span></span>
      <span></span>
      <span></span>
    </div>
<!--                   <div class="search-box pull-left">
                      <form action="#">
                         <input type="text" name="search" id="search_text" placeholder="Search Your Medicine Here" required>
                         <i class="ti-search"></i>
                     </form>
                   </div> -->
                   <div class="row align-items-center">
                    <div class="breadcrumbs-area clearfix">
                      <a href="<?php echo base_url(); ?>"> <h4 class="page-title pull-left">Online Medicine Delivery Portal</h4> </a>
                    </div>
                  </div>
                </div>
                <!-- profile info & task notification -->
                <div class="col-md-6 col-sm-4 clearfix">
                 <ul class="notification-area pull-right">
                  <!-- <li id="upload_prescription"><a class="btn btn-success" href="#" role="button">Upload Prescritpion</a></li> -->
                  <li id="full-view"><i class="ti-fullscreen"></i></li>
                  <li id="full-view-exit"><i class="ti-zoom-out"></i></li>
                  <li class="dropdown">
                   <i class="ti-bell dropdown-toggle" data-toggle="dropdown">
                    <span>x</span>
                  </i>
                  <div class="dropdown-menu bell-notify-box notify-box">
                    <span class="notify-title">You have new notification <a href="#">view all</a></span>
                    <div class="nofity-list">
                     <a href="#" class="notify-item">
                      <div class="notify-thumb"><i class="ti-key btn-danger"></i></div>
                      <div class="notify-text">
                       <p>xxxxxxxxxxxxxx</p>
                       <span>xxxxxxxxx</span>
                     </div>
                   </a>

                 </div>
               </div>
             </li>

             <li class="settings-btn" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/load_cart')"><i class="ti-shopping-cart"></i>

             </li>
           </ul>
         </div>
       </div>
     </div>
     <!-- header area end -->
     <!-- page title area start -->
     <div class="page-title-area">
       <div class="row align-items-center">
        <div class="col-sm-6">
 <!--        					<div class="breadcrumbs-area clearfix">
        						<a href="index.html"> <h4 class="page-title pull-left">Online Medicine Delivery Portal</h4> </a>
        					</div> -->
                  <div class="search-box pull-left">
                    <form idaction="#">
                      <input type="text" name="search" id="search_text" placeholder="Search Your Medicine Here" required>
                      <i class="ti-search"></i>
                    </form>
                  </div>


                </div>
                <div class="col-sm-6 clearfix">
                 <div class="user-profile pull-right">
                  <img class="avatar user-thumb" src="<?php echo $profile; ?>" alt="avatar">
                  <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php echo $username; ?> <i class="fa fa-angle-down"></i></h4>
                  <div class="dropdown-menu">
                   <a class="dropdown-item" href="#">Settings</a>
                   <a class="dropdown-item" href="<?php echo base_url(); ?>shop_controller/logout/<?php echo $sessionId; ?>/<?php echo $userId; ?>">Log Out</a>
                 </div>
               </div>
             </div>
           </div>
         </div>
         <!-- item categorie nav  bar -->

         <!-- item categoried end -->
         <!-- <nav class="navbar navbar-expand-lg navbar-light bg-light"></nav> -->
         <!-- page title area end -->

         <!-- nav bar item categries -->

         <!-- nav bar item categoried end --> 
         <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <!-- <nav class="navbar navbar-dark bg-dark"> -->
            <!-- <a class="navbar-brand" href="#">Navbar</a> -->
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item dropdown">
                  <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                  <a class="nav-link dropdown-toggle" href="#" id="babyCare" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Baby-Care
                  </a>
                  <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="#"> Food and Milk Essentials</a>
                    <a class="dropdown-item" href="#">Bath and Skin Essentials</a>
                    <!-- <div class="dropdown-divider"></div> -->
                    <a class="dropdown-item" href="#">Diapers and Nappy</a>
                    <a class="dropdown-item" href="#">Baby Wipes</a>
                    <a class="dropdown-item" href="#">Baby Food</a>
                    <a class="dropdown-item" href="#">Mother Care</a>
                  </div>
                </li>
                    <!--   <li class="nav-item active">
                        <a class="nav-link" href="#"> Diabetes<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="diabeticCare" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Diabetes
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Diabetes Ayurvedic</a>
                          <a class="dropdown-item" href="#">Sugar Substitutes</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Nutrition Supplements</a>
                          <a class="dropdown-item" href="#">Diabetic Equipment</a>
                          <a class="dropdown-item" href="#">Diabetic Devices</a>
                        </div>
                      </li>
 <!--                    <li class="nav-item active">
                        <a class="nav-link" href="#"> Ayurvedic<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="ayurvedic" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Ayurvedic
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Food Supplements</a>
                          <a class="dropdown-item" href="#">Immunity</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>user_controller/list_all_items')">Health Care</a>
                          <!-- <a class="dropdown-item" href="#">Diabetic Equipment</a> -->
                        </div>
                      </li>
            <!--         <li class="nav-item dropdown">
                        <a class="nav-link " href="#"> Health-Care<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="personal_care" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Personal Care
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Hair Care</a>
                          <a class="dropdown-item" href="#">Men Care</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Women Care</a>
                          <a class="dropdown-item" href="#">Oral Care</a>
                        </div>
                      </li>
<!--                     <li class="nav-item active">
                        <a class="nav-link " href="#"> Nutrition<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="nutrition_supplement" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Nutrition & Supplements
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Nutrition Drinks</a>
                          <a class="dropdown-item" href="#">Multi Vitamins</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Speciality Suppliments</a>
                          <a class="dropdown-item" href="#">Protein Suppliments</a>
                        </div>
                      </li>
<!--                     <li class="nav-item active">
                        <a class="nav-link " href="#"> Suppliments<p>   </p> </a>
                      </li> -->
                      <li class="nav-item dropdown">
                        <!-- <a class="nav-link" href="#"> Baby-Care<p>   </p></a> -->
                        <a class="nav-link dropdown-toggle" href="#" id="covid_essentials" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Covid 19 Essentials
                        </a>
                        <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#"> Hand Sanitizers</a>
                          <a class="dropdown-item" href="#">Hand Washes</a>
                          <!-- <div class="dropdown-divider"></div> -->
                          <a class="dropdown-item" href="#">Masks</a>
                          <a class="dropdown-item" href="#">Gloves</a>
                          <a class="dropdown-item" href="#">Immunity Boosters</a>
                        </div>
                      </li>
 <!--                    <li class="nav-item active">
                        <a class="nav-link " href="#"> Pharmacies </a>
                      </li> -->

                    </ul>
                  </div>  
                </nav>


                <!-- nav bar item category end -->



                <!-- <div id="main_profile_inner" class="main-content-inner"></div>  -->
                <div id="main_content_inner" class="main-content-inner">  
                 <!-- sales report area start -->
                 <!-- page title area end -->
                 <!-- <div class="main-content-inner"> -->
                  <!-- sales report area start -->

                </div>

              </div>




            </div>
          </div>

        </div>
      </div>
      <!-- main content area end -->
      <!-- open dialog box -->
      <div id="presApproveModal" class="modal fade">  
        <div class="modal-dialog modal-lg">  
         <div class="modal-content">  
          <div class="modal-header">  
           <!-- <button type="button" class="close" data-dismiss="modal">&times;</button>   -->
           <h4 class="modal-title" id="model_title"></h4> 
           <button type="button" class="close" data-dismiss="modal">&times;</button> 
         </div>  
         <div class="modal-body" id="order_details">  
         </div>  
         <div class="modal-footer"> 
           <!-- <button type="button" id="accept_pres" class="btn btn-success">Accept Offer</button>  -->
           <!-- <button type="button" class="btn btn-danger">Reject Offer</button> -->
           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
         </div>  
       </div>  
     </div>  
   </div> 
   <!-- footer area start-->
   <footer>
     <div class="footer-area">
      <p>© Copyright 2021. All right reserved.</a>.</p>
      <!-- </div> -->
    </footer>
    <!-- footer area end-->
    <!-- </div> -->
    <!-- page container area end -->
    <!-- offset area start -->

    <!-- offset area end -->
    <!-- jquery latest version -->
    <script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script>


    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/metisMenu.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.slicknav.min.js"></script>

    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
     $('#blogCarousel').carousel({
      interval: 5000
    });
  </script>
  <!-- all line chart activation -->
  <script src="<?php echo base_url(); ?>assets/js/line-chart.js"></script>
  <!-- all pie chart -->
  <script src="<?php echo base_url(); ?>assets/js/pie-chart.js"></script>
  <!-- others plugins -->
  <script src="<?php echo base_url(); ?>assets/js/plugins.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/scripts.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){

        //if empty go to home page


// live data search
// function load_data(query)
// {
//   $.ajax({
//     // url:"<?php echo base_url(); ?>user_controller/fetch_med",
//     url:"<?php echo base_url(); ?>order_controller/fetch_new_items/<?php echo $pharm_id; ?>",
//     method:"POST",
//     data:{query:query},
//     success:function(data){
//         $('#main_content_inner').html(data);
//     }
// })
// }






// // return search results dynamically
// $('#search_text').keyup(function(){
//   var search = $(this).val();
//   if(search != '')
//   {
//      load_data(search);
//  }
//  else
//  {
//    $('#main_content_inner').load('<?php echo base_url(); ?>user_controller/main_inner_content_cust')
// }
// });

// carousel refresh
$('#best_seller').carousel({
  interval: 5000
});



});

// loac cart 
$('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_cart");

// clear items to shopping cart
//cear cart
$(document).on('click', '#clear_cart', function(){
  if(confirm("Are you sure you want to clear cart?"))
  {
    $.ajax({
      url:"<?php echo base_url(); ?>shop_controller/clear_cart",
      success:function(data)
      {
        alert("Your cart has been clear...");
        $('#cart_details').html(data);
      }
    });
  }
  else
  {
    return false;
  }
});


// finish processing order
//proceed to checkout

// open view dialog 
function viewPrescriptionDialogBox(orderId){

    // var userId="<?php echo $userId; ?>";
    var orderId=orderId;
    $.ajax({

      url:"<?php echo base_url(); ?>order_controller/fetch_modal_view_prescription/",
      method:"POST",
      data:{orderId:orderId},
      success:function(data){
        $('#model_title').html("Prescription for Order Id:" + orderId);
        $('#order_details').html(data);
        $('#presApproveModal').modal("show");
      }
    })

  }


// view item information Pharmacist
// open dialog box prescriptions
function openItemDetailDialog(med_item_id){

    // var userId="<?php echo $userId; ?>";
    var med_item_id=med_item_id;
    $.ajax({

      url:"<?php echo base_url(); ?>order_controller/fetch_modal_item_description/",
      method:"POST",
      data:{med_item_id:med_item_id},
      success:function(data){
        $('#model_title').html("Product Details");
        $('#order_details').html(data);
        $('#presApproveModal').modal("show");
      }
    })

  }


// check items before approve order
function checkItemsDialogOrderPharm(orderId){
  var orderId=orderId;
  $.ajax({

    url:"<?php echo base_url(); ?>order_controller/fetch_modal_incoming_order_pharm/",
    method:"POST",
    data:{orderId:orderId},
    success:function(data){
      $('#model_title').html("Items for Order Id:" + orderId);
      $('#order_details').html(data);
      $('#presApproveModal').modal("show");
    }
  })


}


// notif in side menu // get current order count
notifCations();

function notifCations(){


        // get new Prescriptions count  pres_count
        $.ajax({
          url:"<?php echo base_url(); ?>order_controller/get_incoming_pres_count_pharm/<?php echo $pharm_id; ?>",
          method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#pres_notif').text('New');
                // console.log(data);}
                $('#pres_count').text(data);

              }
              else{
                $('#pres_notif').text('');
                // console.log(data);}
                $('#pres_count').text('');
              }
            }
          });

        //get reviewing prescription count

            // get new Prescriptions count  pres_count
            $.ajax({
              url:"<?php echo base_url(); ?>order_controller/get_reviewing_pres_count_pharm/<?php echo $pharm_id; ?>",
              method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#reviewing_count').text(data);
                // console.log(data);}
                $('#review_count').text(data);

              }
              else{
                $('#reviewing_count').text('');
                // console.log(data);}
                $('#review_count').text('');
              }
            }
          });



// get new orders count
$.ajax({
  url:"<?php echo base_url(); ?>order_controller/get_current_count_pharm/<?php echo $pharm_id; ?>",
  method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                $('#order_notif').text('New');
                // console.log(data);}
                $('#order_count').text(data);

              }
              else{
                $('#order_notif').text('');
                // console.log(data);}
                $('#order_count').text('');
              }
            }
          });



           // get ongoing orders
           $.ajax({
            url:"<?php echo base_url(); ?>order_controller/get_ongoing_count_pharm/<?php echo $pharm_id; ?>",
            method:"POST",
            // data:totalReg,
            data:$(this).serialize(),
            success:function(data){
              if(data > 0){ 

                // $('#order_notif').text('New');
                $('#ongoinged_count').text(data);
                // console.log(data);}
                $('#ongoing_count').text(data);

              }
              else{
                $('#ongoinged_count').text('');
                // console.log(data);}
                $('#ongoing_count').text('');
              }
            }
          });

         }





        // refresh content every 5 seconds
        $(function() {
          setInterval(notifCations, 5000);
        });


      </script>
    </body>

    </html>
