<?php if($msg=$this-> session->flashdata('msg')): ?>
  <div class="alert alert-dismissible alert-success">  
    <?php echo $msg;?>
    <?php unset($_SESSION['msg']); ?>
    <?php echo "</br>";?>   
    <!-- <?php echo anchor('shop_controller/add_inventory_item', 'Continue Adding',['class'=>'alert-link'])?> -->
    <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>shop_controller/update_item_manager/<?php echo $pharm_id; ?>')">Continue Adding</a>
  </div>
<?php endif;?>  
<!-- <div id="reg_form" class="container"> -->
  <br />
  <h3 align="center" id="top_heading">Edit Inventory Item Details</h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <!-- <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_reg')">Refresh</a> -->

   <div class="panel-body"> 
    <?php echo form_open_multipart('',array('id' => 'myform')); ?>
    <fieldset>
      <!-- <legend>Register New Customer</legend> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">Item Name</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="med_item_name" > -->
          <?php echo form_input(['name'=>'med_item_name','class'=>'form-control','value'=>set_value('med_item_name',$data->med_item_name)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('med_item_name','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Item Brand</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="med_item_brand" > -->
          <?php echo form_input(['name'=>'med_item_brand','class'=>'form-control','value'=>set_value('med_item_brand',$data->med_item_brand)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('med_item_brand','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Select Item Type</label>
        <div class="col-lg-10">
          <select name="med_item_type" id="medicineTypeDrop">
            <option value="Diabetes">Diabetes</option>
            <option value="Mother and Baby Care">Mother and Baby Care</option>
            <option value="Covid Essentials">Covid Essentials</option>
            <option value="Personal Care">Personal Care</option>
          </select>
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Select Item Subtype</label>
        <div class="col-lg-10">
          <select name="med_item_subtype" id="medicineSubTypeDrop">
            <option value="Customer">Sugar Substitute</option>
            <option value="Cashier">Ayurvedic</option>
            <option value="Manager">Sugar Management</option>
            <option value="Admin">Equipment</option>
          </select>
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Item Specifcation</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="med_item_spec" > -->
          <?php echo form_input(['name'=>'med_item_spec','class'=>'form-control','value'=>set_value('med_item_spec',$data->med_item_spec)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Item Comments</label>
        <div class="col-lg-10">
          <!-- <input type="text" class="form-control" name="med_comments" > -->
          <?php echo form_input(['name'=>'med_comments','class'=>'form-control','value'=>set_value('med_comments',$data->med_comments)]);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
<!--       <div class="form-group">
        <label  class="col-lg-3 control-label">Address : Line 3</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="address_line3" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
        </div>  
      </div> -->
      <div class="form-group">
        <label  class="col-lg-3 control-label">Number of Units</label>
        <div class="col-lg-10">
          <!-- <input type="number" class="form-control" name="med_stock" > -->
          <?php echo form_input(['name'=>'med_stock','class'=>'form-control','value'=>set_value('med_stock',$data->med_stock)]);?>

        </div>
        <div class="col-md-5">
          <?php echo form_error('manager_id','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Unit Price of Item(LKR)</label>
        <div class="col-lg-10">
          <!-- <input type="number" class="form-control" name="med_unit_price" step="0.01"> -->
          <?php echo form_input(['name'=>'med_unit_price','class'=>'form-control','value'=>set_value('med_unit_price',$data->med_unit_price),'step'=>'0.01']);?>
        </div>
        <div class="col-md-5">
          <?php echo form_error('manager_id','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label class="col-lg-3 control-label">Current Image</label>
        <div class="col-lg-10">
          <!-- <input type="file" id="myFile" name="med_item_image">  -->
          <!-- <?php echo form_input(['name'=>'med_item_image','class'=>'form-control','value'=>set_value('med_item_image',$data->med_item_image)]);?> -->
          <img class="avatar user-thumb" id="curr_img" src="<?php echo $data->med_item_image; ?>" alt="avatar">
        </div>
        <div class="col-md-5">
          <?php echo form_error('profile','<div class="text-danger">', '</div>');?>
        </div> 
      </div>

 <!--      <div class="form-group">
        <label  class="col-lg-2 control-label">Confirm Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="conf_password" placeholder="xxxxxxxxxx">
        </div>              
        <div class="col-md-5">
          <?php echo form_error('conf_password','<div class="text-danger">', '</div>');?>
        </div>  
      </div> -->
      <div class="form-group" >
        <label  class="col-lg-3 control-label">Date of Manufacture</label>
        <div class="container"> 
          <div class="row">
            <div class="col-md-3"> 
              <!-- <input type="text" class="form-control" id="med_manufact_date" name="med_manufact_date" > -->
              <?php echo form_input(['name'=>'med_manufact_date','class'=>'form-control','value'=>set_value('med_manufact_date',$data->med_manufact_date),'disabled'=> 'disabled']);?>
            </div>
 <!--            <div class="col-md-5">  
             <input type="button" name="filter1" id="filter1" value="Chose" class="btn btn-info" />  
           </div>  -->
         </div>
       </div>
       <div class="col-md-5">
        <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
      </div>  
    </div>
    <div class="form-group">
      <label  class="col-lg-3 control-label">Date of Expiry</label>
      <div class="container">
        <div class="row">
          <div class="col-md-3"> 
            <!-- <input type="text" class="form-control" id="med_exp_date" name="med_exp_date" > -->
            <?php echo form_input(['name'=>'med_exp_date','class'=>'form-control','value'=>set_value('med_exp_date',$data->med_exp_date),'disabled'=> 'disabled']);?>
          </div>
 <!--          <div class="col-md-5">  
           <input type="button" name="filter2" id="filter2" value="Chose" class="btn btn-info" />  
         </div>  -->
       </div>
     </div>
     <div class="col-md-5">
      <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
    </div>  
  </div>
  <div class="form-group"> 
    <div class="container">
      <div class="col-md-8">
        <div class="row">
          <div class="checkbox">
            <label> <input type="checkbox"> I have checked that the item details are correct. Can proceed to Edit Item </label>
          </div> <!-- checkbox .// -->
        </div>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-lg-10 col-lg-offset-2">
     <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary','id'=>'formSubmit']);?> 
     <button type="reset" class="btn btn-default">Clear</button>

   </div>
 </div>     
</div>
</fieldset>
<?php echo form_close(); ?>
</div>
</div>


  <script type="text/javascript">
  // $(document).ready(function(){ 
    $('#myform').submit(function(e){
     e.preventDefault(); 
     var formData= new FormData(this); //create new formdata
     formData.append('med_pharmacy_id','<?php echo $med_pharmacy_id; ?>'); //append new variable to pharm data
     //if no profile image is chosen set the input value to current value
     // if($('#new_img').val()==''){
     //   $('#new_img').val($('#curr_img').prop('src'));
     // }

     $.ajax({
       url:"<?php echo base_url(); ?>shop_controller/update_item_info/<?php echo $data->med_item_id; ?>/",
       method:"POST",
     // data:$(this).serialize(),
     data:formData,
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
         // $("#med_manufact_date").datepicker();  
         // $("#med_exp_date").datepicker(); 
         //focus top
         // $('#top_heading').focus();
       }
     }

   });

   });  


    


// initialize datepicker
$(document).ready(function(){ 



// Set value in the drop down types
$("#medicineTypeDrop option[value='<?php echo $data->med_item_type; ?>']").prop('selected', true); 


// medicineSubTypeDrop set value in subtype
$("#medicineSubTypeDrop option[value='<?php echo $data->med_item_subtype; ?>']").prop('selected', true);


$.datepicker.setDefaults({  
  dateFormat: 'yy-mm-dd'   
}); 

$(function(){  
  $("#med_manufact_date").datepicker();  
  $("#med_exp_date").datepicker();  
});  


// });

  // $('body').on('focus',".med_exp_date", function(){
  //   $(this).datepicker();
});

</script>


<!-- --data:$(this).serialize(), -->




