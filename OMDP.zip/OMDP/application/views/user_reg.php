  <?php
  defined('BASEPATH') OR exit('No direct script access allowed');
  include_once('header.php');
  ?>
  

<?php if($msg=$this-> session->flashdata('msg')): ?>
  <div class="alert alert-dismissible alert-success">  
    <?php echo $msg;?>
    <?php unset($_SESSION['msg']); ?>
    <?php echo "</br>";?>   
    <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/user_reg')">Continue Adding</a>
  </div>
<?php endif;?>  
<div class="container">
  <br />
  <h3 align="center">User Registration for OMDP</h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <div class="panel-body">
    <?php echo form_open_multipart('',array('id' => 'myform')); ?>
    <fieldset>
      <!-- <legend>Register New User </legend> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">First Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="fname" placeholder="First Name">
        </div>
        <div class="col-md-5">
          <?php echo form_error('fname','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Last Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="lname" placeholder="Last Name">
        </div>
        <div class="col-md-5">
          <?php echo form_error('lname','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Email</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="email" placeholder="Eg : xxx@maildomain.com">
        </div>
        <div class="col-md-5">
          <?php echo form_error('email','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Valid NIC</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="nic" placeholder="Eg : 923395678V">
        </div>
        <div class="col-md-5">
          <?php echo form_error('nic','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Mobile</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="mobile" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label class="col-lg-2 control-label">Gender</label>
        <div class="col-lg-10">
          <div class="radio">
            <label>
              <input type="radio" name="gender" id="optionsRadios1" value="male" checked="">
              Male
            </label>
          </div>
          <div class="radio">
            <label>
              <input type="radio" name="gender" id="optionsRadios2" value="female">
              Female
            </label>
          </div>
        </div>
      </div>
      <div class="form-group">
        <label class="col-lg-2 control-label">Upload Avatar</label>
        <div class="col-lg-10">
         <input type="file" id="myFile" name="profile"> 
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Select User Type</label>
        <div class="col-lg-10">
          <select name="type" id="type">
            <option value="Customer">Customer</option>
            <option value="Cashier">Cashier</option>
            <option value="Manager">Manager</option>
            <option value="Admin">Admin</option>
          </select>
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Enter Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="password" placeholder="xxxxxxxxxx">
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Confirm Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="conf_password" placeholder="xxxxxxxxxx">
        </div>              
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <div class="col-lg-10 col-lg-offset-2">
          <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary']);?>

          <button type="reset" class="btn btn-default">Clear</button>
          
        </div>
      </div>
      <div class="form-group">      
      </div>
    </fieldset>
    <?php echo form_close(); ?>
  </div>
</div>
</div>



<script type="text/javascript">

// Override Defualt submit function - and load data in the div main container
  $('#myform').submit(function(e){
   e.preventDefault();  
   $.ajax({
     url:"<?php echo base_url(); ?>admin_controller/pharm_admin_reg_validator",
     method:"POST",
     // data:$(this).serialize(),
     data:new FormData(this),
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });
   
 });  
</script>
<!-- </body>
</body> -->