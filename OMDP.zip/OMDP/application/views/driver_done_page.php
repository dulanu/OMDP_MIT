<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
include_once('header.php');

?>

<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"> -->
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> -->
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>

<div class="page-title-area">
	<div class="row align-items-center">
		<div class="col-sm-1">
			<div class="logo">
				<a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>assets/images/icon/logo.png" alt="logo"></a>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="breadcrumbs-area clearfix">
				<a href="index.html"> <h3 class="page-title pull-left">Online Medicine Delivery Portal</h3> </a>
			</div>


		</div>
	</div>
</div>

<?php if($msg=$this-> session->flashdata('msg')): ?>
	<div class="alert alert-dismissible alert-success" role="alert" id="alert">  
		<?php echo $msg;?>
		<?php unset($_SESSION['msg']); ?>
		<?php echo "</br>";?>   
		<!-- <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/accept_package/<?php echo $orderId; ?>/<?php echo $order_pharm_id; ?>')">Clear</a> -->
		<!-- <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a> -->
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
	</div>
<?php endif;?>
<!-- <div class="gradiant-bg" > -->



</div>
<div class="card-body">
	<div class="row">
		<!-- <h4 class="header-title mb-0">Dashboard</h4> -->
	</div>
</div>
<div class="card-bordered" >
	<div class="card-header" ><h4 align="center"><?php echo "Your Have successfully delivered ". $orderId; ?></h4></div>	
	<div class="card-body" align="center" id="main_content_inner" >
		<!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
		<!-- <div class="card-text"><?php echo "Your are delivering order " .$orderId; ?></div>		 -->
		<!-- <table class="single-table">  -->
			<!-- <div class="dataTables_wrapper" > -->
				<div class="table-responsive" id="driver_table">		
					<!-- <table class="dbkit-table" column-width="50px" > -->
						<table  width="80%" >
							<!-- <table class="trd-history-tabs"> -->

								<col style="width:20%">
								<col style="width:40%">


						<!-- 		<div class="col-sm-6 clearfix">	
									<img  class="mv-icon" src="<?php echo $row['profile']; ?>">
								</div> -->
								<tr>
									<th height="60px">Customer Name</th>
									<td><?php echo $recepient_name. " ".$customer_lname; ?></td>
								</tr>
								<tr>
									<th height="60px">Customer Email</th>
									<td><?php echo $recepient_email ; ?></td>
								</tr>
								<tr>
									<th height="60px" >Order Pharmacy Name</th>
									<td><?php echo $order_pharm_id;?></td>
								</tr>
								<tr>
									<th height="60px">Customer Mobile Number</th>
									<td><?php echo $order_mobile;?></td>
								</tr>
								<tr>
									<th height="60px">Delivery Address</th>
									<td><?php echo $order_address1;?></td>

								</tr>

								<tr><td height="60px"></td><td><?php echo $order_address2; ?></td></tr>
								<tr><td height="60px"></td><td><?php echo $order_address3; ?></td></tr>
								<tr>
									<th height="60px">Order Status</th>
									<td id="delivery_status"><b><?php echo $order_status ;?></b></td>

								</tr>
								<!-- <tr> -->
									
							<!-- 		<td colspan="2"><a href="<?php echo base_url(); ?>order_controller/arrive_location/<?php echo $orderId; ?>/<?php echo $order_pharm_id;?>"  id="order_arrived" class="btn btn-primary btn-lg btn-block">Order Arrived</td> -->
										<!-- <td></td>/ -->
									<!-- </tr> -->
									<tr>

										<td height="10px" colspan="2"></td>
										<!-- <td></td>/ -->
									</tr>
							<!-- 		<tr>
										<td colspan="2" id="complete_order_td"><a href="javascript:void(0)" onclick=""  class="btn btn-success btn-lg btn-block" id="complete_order">Complete Order</td>



										</tr> -->



									</table>

								</div>
							</div>

						</div>

						<script type="text/javascript">


							// $('.alert').alert()
							// $(" .alert").alert('close');
							// $("#complete_order").prop( "disabled", true );

							$(document).ready(function() {
								
								// $('#closeLink').click(function () {
									// $('#alert').alert('close');

								// });
								// $("#order_arrived").on('click', function () {
								// 	$('#order_arrived').click(function() {								
								// 	console.log("done");
								// 	$('#delivery_status').html("<b>Arrived</b>");
								// 	$(this).prop( "disabled", true );

								// 	orderId='<?php echo $orderId; ?>';
								// 	order_pharm_id='<?php echo $order_pharm_id;?>';

								// 	$.ajax({
								// 		url:"<?php echo base_url(); ?>order_controller/arrive_location/<?php echo $orderId; ?>/<?php echo $order_pharm_id;?>",
								// 		method:"POST",     // data:$(this).serialize(),
								// 		data:{orderId:orderId,order_pharm_id:order_pharm_id},  
								// 		success:function(data){
								// 			if (data!='') {
								// 				// $('#alert').html(data);
								// 				// alert("done");
								// 			}
								// 		}

								// 	});
								// });




								// $("#complete_order").prop( "disabled", true );
							});
						</script>


