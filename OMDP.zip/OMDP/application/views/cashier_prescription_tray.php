<script src="<?php echo base_url(); ?>assets/js/vendor/jquery-2.2.4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/js/popper.min.js"></script> 

 
 <!-- <div class="gradiant-bg" > -->
 	
 	<div class="card-body" >
 		<div class="row">
      <!-- <p><?php echo $orderId; ?></p> -->

    </div>
  </div>
  <div class="row" id="below_search">
    <!-- <p><?php echo $orderId; ?></p> -->

  </div>
  <div class="row" >
    <!-- shopping cart -->
    <div class="col-md-6">
      <div class="card-rounded" id="div_cart" >
       <div class="card-body">
        <!-- <div class="col-sm-8"> -->
         <div id="cart_details">
          <h3 align="center">Cart is Empty</h3>
        </div>

        <!-- </div> -->
      </div>
    </div>
  </div>
  <div class="col-md-6" id="myTray">
    <!--   </div></div> --> <div class="card-rounded" id="div_cart" >
      <div class="card-header"><h4 class="header-title mb0">Preview The prescription</h4></div>
      <div class="card-body">
         <?php echo form_open_multipart('',array('id' => 'myform')); ?>
                <fieldset>
        <div class="dataTables_wrapper" >
          <table class="dbkit-table">
            <!-- <table class="trd-history-tabs"> -->

              <col style="width:20%">
              <col style="width:40%">


              <div class="col-sm-6 clearfix"> 
                <img  class="mv-icon" align="center" src="<?php echo $prescription_image; ?>">
                </div>
        <!--         <tr>
                  <th >Pharamcy Name</th>
                  <td><?php echo $prescription_pharm_name; ?></td>
                </tr> -->
                <tr>
                  <th >Urgency</th>
                  <td><?php echo $prescription_urgency; ?></td>
                </tr>
                <tr>
                  <th >Comments</th>
                  <td><?php echo $prescription_comments; ?></td>
                </tr>
                <tr>
                  <th >Pharmacy Comments</th>
                  <!-- <td><?php echo $order_address1.','; ?></td> -->
                </tr>
                <tr>
                  <!-- <th>Pharmacy Comments</th> -->
                  <td colspan="2">  <div class="form-group">
                    <!-- <label  class="col-lg-3 control-label">Additional Comments</label> -->
                    <div class="col-lg-12">
                      <!-- <input type="text" class="form-control" name="landmarks" placeholder="Eg : Near the Bauddhaloka Temple"> -->
                      <textarea id="prescription_pharm_comment" name="prescription_pharm_comment" placeholder="Eg : Near the Bauddhaloka Temple" class="form-control" required rows="4"></textarea>
                    </div>               
                  </div>  
                </td>
              </tr>
              <tr>
                <!-- <th>National Id</th> -->
                <!-- <td ></td><td><?php echo $order_address3; ?></td> -->
                <td><div class="form-group">
                  <div class="col-lg-12 col-lg-offset-2">
                    <?php echo form_submit(['name'=>'submit','value'=> 'Complete Order','class'=>'btn btn-primary']);?>

                    <button type="reset" class="btn btn-default">Clear</button>

                  </div>
                </div></td>
              </tr>
  <!--               <tr>
                  <th>User Type</th>
                  <td><?php echo $orderId; ?></td>
                </tr> -->


              </table>
            </fieldset>
            <?php echo form_close(); ?>
          </div>
        </div>
      </div>
    </div>
    <!-- Modal -->

    <!-- shopping cart -->


    <!-- Modal -->


  </div>


<!--  		<div class="col-sm-8">
 			<div class="card-rounded" id="div_cart" >
 				<div class="card-body">
 					<div class="col-sm-7">
 						<div id="cart_details">
 							<h3 align="center">Cart is Empty</h3>
 						</div>

 					</div>
 				</div>
 			</div>
 		</div> -->





    <script type="text/javascript">
	// loac cart 
  $('#cart_details').load("<?php echo base_url(); ?>order_controller/load_cart");

  
  // console.log(pharm_id);
  // console.log(orderId);
// $.ajax({
  // var orderId="<?php echo $orderId; ?>";
  // $.ajax({
  //   url:"<?php echo base_url(); ?>order_controller/load_tray_prescription/<?php echo $orderId; ?>",
  //   method:"POST",
  //   data:{orderId:orderId},
  //   success:function(data){
  //     $('#myTray').html(data);
  //   }
  // });
  // myTray


//   function finishProcess(){

//     var orderId="<?php echo $orderId; ?>";
//     var pharm_id="<?php echo $pharm_id; ?>";
//     console.log(pharm_id);
//     console.log(orderId);

//     if (confirm('Please double check the items. Are you sure you want to finish  order processing? ')) {



//       $.ajax({

//        url:"<?php echo base_url(); ?>order_controller/finishProcess/<?php echo $orderId; ?>/<?php echo $pharm_id; ?>",
//        method:"POST",
//      // data:$(this).serialize(),
//      data:{orderId:orderId,pharm_id:pharm_id},    
//      processData: false,
//      contentType: false,
//      cache: false,
//      success:function(data){
//       if (data!='') {
//         $('#main_content_inner').html(data);
//       }
//     }

//   });

//     } else {
//   // Do nothing!
//   // console.log('Thing was not saved to the database.');
// } 
// }






// clear items to shopping cart


//calculate total
// calculate calc_bill
// $( "#myBill" ).load(function() {
//   // Handler for .load() called.
//    calc_bill();
// });
$(document).ready(function() {
  // calc_bill();
// });

// $('#finish_button_div').empty();

// calculate


  // $('#myTray').load("<?php echo base_url(); ?>order_controller/load_tray/<?php echo $orderId; ?>");
// live data search
function load_data_tray(query)
{
  $.ajax({
    // url:"<?php echo base_url(); ?>user_controller/fetch_med",
    url:"<?php echo base_url(); ?>order_controller/fetch_new_items_tray/<?php echo $pharm_id; ?>",
    method:"POST",
    data:{query:query},
    success:function(data){
      $('#below_search').html(data);
    }
  })
}


// return search results dynamically
$('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data_tray(search);
 }
 else
 {
   $('#below_search').empty();

 }
});



// console.log(item_total);

function calc_bill(){
  
  var item_total = $("#shopping_cart_table span.cart_total_span").text();
  var delivery_charge=50;
  var discount_price=parseFloat(item_total)*(0.15);
  // console.log(discount_price); 



  var final_total_bill=parseFloat(item_total) + parseFloat(delivery_charge) - parseFloat(discount_price);

  // grant_total_charge
  // $('#grant_total_charge').html(final_total_bill);

  return parseFloat(final_total_bill);


}



// submit quotation
$('#myform').submit(function(e){
 e.preventDefault(); 

if (confirm('You are about to place the submit request.Proceed with the order?')) {


  var orderId="<?php echo $orderId; ?>";
  var pharm_id="<?php echo $pharm_id; ?>";
  var order_final_bill=calc_bill();
  var prescription_pharm_comment=$('textarea#prescription_pharm_comment').val();
  console.log(prescription_pharm_comment);
  
   var fd=new FormData(this);
   fd.append('orderId',orderId);
   fd.append('pharm_id',pharm_id);
   fd.append('order_final_bill',order_final_bill);
   fd.append('prescription_pharm_comment',prescription_pharm_comment);
   // console.log(fd.get(prescription_pharm_comment));

   $.ajax({

   url:"<?php echo base_url(); ?>order_controller/sendQuote",
   method:"POST",
     // data:$(this).serialize(),
     data:fd,    
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });

}else{

}

 }); //





});



// finish processing order
// $('#orderConfirmModel').dialog({
//   autoOpen:false;
// });

// submit order
// $(document).on('click', '#clear_cart', function(){
//   if(confirm("Are you sure you want to clear cart?"))
//   {
//     $.ajax({
//       url:"<?php echo base_url(); ?>shop_controller/clear_cart",
//       success:function(data)
//       {
//         alert("Your cart has been clear...");
//         $('#cart_details').html(data);
//       }
//     });
//   }
//   else
//   {
//     return false;
//   }
// });










// console.log(currPayType);







</script>

