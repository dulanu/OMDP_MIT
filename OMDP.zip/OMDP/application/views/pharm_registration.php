 <?php
 defined('BASEPATH') OR exit('No direct script access allowed');
 include_once('header.php');
 ?>

 

 

 <?php if($msg=$this-> session->flashdata('msg')): ?>
  <div class="alert alert-dismissible alert-success">  
    <?php echo $msg;?>
    <?php unset($_SESSION['msg']); ?>
    <?php echo "</br>";?>   
    <!-- <?php echo anchor('admin_controller/pharm_reg', 'Continue Adding',['class'=>'alert-link'])?> -->
    <a href="javascript:void(0)" class="alert-link" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_reg')">Continue Adding</a>
  </div>
<?php endif;?>  
<!-- <div id="reg_form" class="container"> -->
  <br />
  <h3 align="center">Pharmacy Registration for OMDP</h3>
  <br />
  <div class="panel panel-default">
   <!-- <div class="panel-heading">Register</div> -->
   <!-- <a href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>admin_controller/pharm_reg')">Refresh</a> -->

   <div class="panel-body"> 
    <?php echo form_open_multipart('',array('id' => 'myform')); ?>
    <fieldset>
      <!-- <legend>Register New Customer</legend> -->
      <div class="form-group">
        <label  class="col-lg-2 control-label">Pharmacy Name</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="pharm_name" placeholder="Eg : New Pharmacy Ltd(Pvt)">
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_name','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Pharmacy Email</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="pharm_email" placeholder="Eg : xxx@maildomain.com">
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_email','<div class="text-danger">', '</div>');?>
        </div>
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Pharmacy Telephone</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="pharm_phone" placeholder="Eg : 01123456677">
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_phone','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Pharmacy Registration</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="pharm_registration_no" placeholder="Eg: REG/XX/XXXXXX">
        </div>
        <div class="col-md-5">
          <?php echo form_error('pharm_registration_no','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Pharmacy Address : Line 1</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="address_line1" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Address : Line 2</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="address_line2" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('address_line2','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Address : Line 3</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="address_line3" placeholder="Eg : 0703466551">
        </div>
        <div class="col-md-5">
          <?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-3 control-label">Manager ID</label>
        <div class="col-lg-10">
          <input type="text" class="form-control" name="manager_id" placeholder="Enter manager userid">
        </div>
        <div class="col-md-5">
          <?php echo form_error('manager_id','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label class="col-lg-3 control-label">Upload Display Logo</label>
        <div class="col-lg-10">
          <input type="file" id="myFile" name="profile"> 
        </div>
        <div class="col-md-5">
          <?php echo form_error('profile','<div class="text-danger">', '</div>');?>
        </div> 
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Enter Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="password" placeholder="xxxxxxxxxx">
        </div>
        <div class="col-md-5">
          <?php echo form_error('password','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <label  class="col-lg-2 control-label">Confirm Password</label>
        <div class="col-lg-10">
          <input type="password" class="form-control" name="conf_password" placeholder="xxxxxxxxxx">
        </div>              
        <div class="col-md-5">
          <?php echo form_error('conf_password','<div class="text-danger">', '</div>');?>
        </div>  
      </div>
      <div class="form-group">
        <div class="col-lg-10 col-lg-offset-2">
         <?php echo form_submit(['name'=>'submit','value'=> 'Submit','class'=>'btn btn-primary','id'=>'formSubmit']);?> 
         <button type="reset" class="btn btn-default">Clear</button>

       </div>
     </div>     
   </div>
 </fieldset>
 <?php echo form_close(); ?>
</div>
</div>
<!-- </div> -->
<script type="text/javascript">

  $('#myform').submit(function(e){
   e.preventDefault();  
   $.ajax({
     url:"<?php echo base_url(); ?>admin_controller/register_pharm_validator",
     method:"POST",
     // data:$(this).serialize(),
     data:new FormData(this),
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });
   
 });  
</script>

<!-- --data:$(this).serialize(), -->




