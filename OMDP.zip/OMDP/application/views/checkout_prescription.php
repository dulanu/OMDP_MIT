 <?php 
 defined('BASEPATH') OR exit('No direct script access allowed');
 include_once('header.php');

 ?>

 
 <!-- <div class="gradiant-bg" > -->
 	
 	<div class="card-body">
 		<div class="row">

 		</div>
 	</div>
 	<div class="row">

 		<div class="col-md-6">
 			<div class="card-rounded">
 				<div class="card-header"><h4 class="header-title mb0">Enter additional details</h4></div>	
        <!-- <div class="card-header"><h4 class="header-title mb0"><?php echo $userId; ?></h4></div> -->
 				<div class="card-body" >
 					<!-- <img  src="<?php echo base_url(); ?>/images/<?php echo $profile; ?>"  -->
 					<!-- <div class="card-text">Test</div>	 -->
 					<?php echo form_open_multipart('',array('id' => 'myform')); ?>
 					<fieldset>
 						<!-- <legend>Register New User </legend> -->
 						<div class="form-group">
 							<label  class="col-lg-2 control-label">First Name</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="customer_fname" placeholder="First Name">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('fname','<div class="text-danger">', '</div>');?>
 							</div>
 						</div>
 						<div class="form-group">
 							<label  class="col-lg-2 control-label">Last Name</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="customer_lname" placeholder="Last Name">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('lname','<div class="text-danger">', '</div>');?>
 							</div>
 						</div>
 						<div class="form-group">
 							<label  class="col-lg-2 control-label">Email</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="order_email" placeholder="Eg : xxx@maildomain.com">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('email','<div class="text-danger">', '</div>');?>
 							</div>  
 						</div> 	
            <div class="form-group">
              <label  class="col-lg-2 control-label">Mobile Number</label>
              <div class="col-lg-12">
                <input type="text" class="form-control" name="order_mobile" placeholder="Eg : 0703466551">
              </div>
              <div class="col-md-5">
                <?php echo form_error('email','<div class="text-danger">', '</div>');?>
              </div>  
            </div>		
 						<div class="form-group">
 							<label  class="col-lg-3 control-label">Delivery Address : Line 1</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="order_address1" placeholder="Eg : No 35/a,">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('mobile','<div class="text-danger">', '</div>');?>
 							</div>  
 						</div>
 						<div class="form-group">
 							<label  class="col-lg-3 control-label">Address : Line 2</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="order_address2" placeholder="Eg : 0703466551">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('address_line2','<div class="text-danger">', '</div>');?>
 							</div>  
 						</div>
 						<div class="form-group">
 							<label  class="col-lg-3 control-label">Address : Line 3</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="order_address3" placeholder="Eg : 0703466551">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('address_line3','<div class="text-danger">', '</div>');?>
 							</div>  
 						</div>
 						<div class="form-group">
 							<label  class="col-lg-3 control-label">Land Marks</label>
 							<div class="col-lg-12">
 								<input type="text" class="form-control" name="order_landmarks" placeholder="Provide some landmarks">
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('order_landmarks','<div class="text-danger">', '</div>');?>
 							</div>  
 						</div>
 						<div class="form-group">
 							<label  class="col-lg-3 control-label">Additional Comments</label>
 							<div class="col-lg-12">
 								<!-- <input type="text" class="form-control" name="landmarks" placeholder="Eg : Near the Bauddhaloka Temple"> -->
 								<textarea name="order_comments" placeholder="Eg : Near the Bauddhaloka Temple" class="form-control" required rows="8"></textarea>
 							</div>
 							<div class="col-md-5">
 								<?php echo form_error('order_comments','<div class="text-danger">', '</div>');?>
 							</div>  
 						</div>

 						<div class="form-group">
 							<div class="col-lg-12 col-lg-offset-2">
 								<?php echo form_submit(['name'=>'submit','value'=> 'Proceed to Payment','class'=>'btn btn-primary']);?>

 								<button type="reset" class="btn btn-default">Clear</button>

 							</div>
 						</div>
 						<div class="form-group">      
 						</div>
 					</fieldset>
 					<?php echo form_close(); ?>
 					
 		<!-- 			<a id="test" href="javascript:void(0)" onclick="$('div#main_content_inner').load('<?php echo base_url(); ?>order_controller/testOrder/<?php echo $userId; ?>')"  aria-expanded="true"><i class="ti-home"></i><span>Test Link</span></a> -->
 				</div>

 			</div>
 		</div>
 		<div class="col-md-6">
 			<div class="card-rounded" id="div_cart" >
 				<div class="card-body">
 					<!-- <div class="col-sm-8"> -->
 						<div id="cart_details">
 							<h3 align="center">Cart is Empty</h3>
 						</div>

 						<!-- </div> -->
 					</div>
 				</div>
 			</div>
 		</div>


<!--  		<div class="col-sm-8">
 			<div class="card-rounded" id="div_cart" >
 				<div class="card-body">
 					<div class="col-sm-7">
 						<div id="cart_details">
 							<h3 align="center">Cart is Empty</h3>
 						</div>

 					</div>
 				</div>
 			</div>
 		</div> -->





 <script type="text/javascript">
	// loac cart 
	$('#cart_details').load("<?php echo base_url(); ?>shop_controller/load_cart");

// clear items to shopping cart

  $('#myform').submit(function(e){
   e.preventDefault();  
   var fd=new FormData(this);
   fd.append('customerId','<?php echo $userId; ?>');
   $.ajax({
     url:"<?php echo base_url(); ?>order_controller/proceedPayment/<?php echo $userId; ?>",
     method:"POST",
     // data:$(this).serialize(),
     data:fd,
     // dataType:"html",
     processData: false,
     contentType: false,
     cache: false,
     success:function(data){
      if (data!='') {
        $('#main_content_inner').html(data);
      }
    }

  });
   
 }); 





</script>

