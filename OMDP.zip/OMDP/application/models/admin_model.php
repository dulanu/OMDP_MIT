	<?php

	class admin_model extends CI_Model{

     // update total reg users in admin dash
		public function regUserCount(){
			$this->db->where('userType','Customer');
			$query = $this->db->get('users');
			return $query->num_rows();
		}


		public function ActiveSessionCount(){
			$this->db->where('status','Active');
			$query = $this->db->get('login_session');
			return $query->num_rows();
		}


		// get total orders today
		public function TotalOrdersPharm($pharm_id){
			
			$sql="SELECT count(*) as total from orders where order_pharm_id=".$pharm_id;
			$result=$this->db->query($sql);
			return $result ->row()->total;
		}


		// get pharm info
		public function view_pharm_profile($pharm_id){
			$this->db->where('pharm_id' ,$pharm_id);
			$query = $this->db->get('pharmacy');
			if($query->num_rows() >0){
				return $query;
			}
		}


		// total order completed
		public function totalCompletePharm($pharm_id){
			$sql="SELECT count(*) as total from orders where order_pharm_id=".$pharm_id." and order_status='completed'";
			$result=$this->db->query($sql);
			return $result ->row()->total;

		}

		// total pending 
		public function totalPendingPharm($pharm_id){
			$sql="SELECT count(*) as total from orders where order_pharm_id=".$pharm_id." and order_status in ('pending','submitted')";
			$result=$this->db->query($sql);
			return $result ->row()->total;
		}

		public function TotalDispachedPharm($pharm_id){
			$sql="SELECT count(*) as total from orders where order_pharm_id=".$pharm_id." and order_status='dispatched'";
			$result=$this->db->query($sql);
			return $result ->row()->total;
		}


		// get total prescriptions Pharmac
		public function TotalPrescriptionsPharm($pharm_id){
			$sql="SELECT count(*) as total from orders where order_pharm_id=".$pharm_id." and is_prescription='Y' and  order_status='completed'";
			$result=$this->db->query($sql);
			return $result ->row()->total;

		}

		


		// get total revenue pharm 
		public function TotalRevenuePharm($pharm_id){
			$sql="SELECT sum(order_final_bill) as total_revenue from orders where order_pharm_id=".$pharm_id." and  order_status='completed'";
			$result=$this->db->query($sql);
			return $result ->row()->total_revenue;

		}

		// get pie chart data orders
		public function getpieChart($pharm_id){

			$sql="SELECT order_status,count(orderId) as total from orders where order_pharm_id=".$pharm_id." and order_status in ('pending','completed','dispatched') group by order_status" ;

			$query=$this->db->query($sql);

			return $query;



		}


		// get bar chart item data  
		public function getBarChartItems($pharm_id){
			$sql="SELECT med_item_name AS item_name,sum(order_item_quantity) AS total from order_items where pharm_id=".$pharm_id." group by med_item_name order by sum(order_item_quantity) desc limit 5" ;

			$query=$this->db->query($sql);

			return $query;

		}

		//get line chart items
		public function getLineChartItems($pharm_id){
			$sql="SELECT order_timesatmp as day,sum(order_final_bill) as sales FROM `orders` WHERE order_pharm_id=".$pharm_id." and order_timesatmp  BETWEEN DATE_SUB(NOW(), INTERVAL 20 DAY) and now()  group by day(order_timesatmp)";

			$query=$this->db->query($sql);

			return $query;

		}

		// get sales maxdb_report
		public function fetch_sales_report($pharm_id){
			$sql="SELECT order_timesatmp as month,sum(order_final_bill) as sales FROM `orders` WHERE order_pharm_id=".$pharm_id." and order_timesatmp  BETWEEN DATE_SUB(NOW(), INTERVAL 3 month) and now() and order_status='completed' group by month(order_timesatmp)";

			$query=$this->db->query($sql);

			return $query;
		}


		// fetch report items
		public function fetch_report_items($pharm_id){
			$sql="select m.med_item_name as item_name,sum(i.order_item_quantity) as noof_items,sum(i.order_item_subtotal) as total_sales from 
			order_items i , medicine_items m , orders o
			where i.med_item_id=m.med_item_id and i.orderId=o.orderId
			and m.med_pharmacy_id=".$pharm_id."
			and o.order_timesatmp  BETWEEN DATE_SUB(NOW(), INTERVAL 3 month) and now()
			and o.order_status='completed' group by m.med_item_id order by sum(i.order_item_subtotal) desc;";

			$query=$this->db->query($sql);

			return $query;

		}


		// get line chart orders
		public function getLineChartOrders($pharm_id){
			$sql="SELECT order_timesatmp as day,count(orderId) as orders FROM `orders` WHERE order_pharm_id=".$pharm_id." and order_timesatmp  BETWEEN DATE_SUB(NOW(), INTERVAL 20 DAY) and now()  group by day(order_timesatmp)";

			$query=$this->db->query($sql);

			return $query;
		}


		// get total item pharm count
		public function TotalItemsPharm($pharm_id){
			$sql="SELECT sum(med_stock) as total_items from medicine_items where med_pharmacy_id=".$pharm_id;
			$query=$this->db->query($sql);

			return $query->row()->total_items;

		}

		// get in stock items in pharm
		public function InStockItemsPharm($pharm_id){
			$sql="SELECT med_item_id as instock_items from medicine_items where med_pharmacy_id=".$pharm_id. " and med_stock > 0";
			$query=$this->db->query($sql);

			return $query->num_rows();

		}

		// run short items 
		public function runShortItemsPharm($pharm_id){
			$sql="SELECT med_item_id as instock_items from medicine_items where med_pharmacy_id=".$pharm_id. " and med_stock < 20";
			$query=$this->db->query($sql);

			return $query->num_rows();

		}



		// get out of stock items
		public function outofStockItemsPharm($pharm_id){
			$sql="SELECT med_item_id as instock_items from medicine_items where med_pharmacy_id=".$pharm_id. " and med_stock = 0";
			$query=$this->db->query($sql);

			if ($query->num_rows()>0){
				return $query->num_rows();
			}			

		}



			// Insert to Pharmacy - Register Pharmacy
		public function add_inventory_item($data){
			return $this->db->insert('medicine_items',$data);
		}

	}

	?>
