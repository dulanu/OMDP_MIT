<?php

class order_model extends CI_Model{


	public function getPharmfromOrder($orderId){
		$this->db->where('orderId', $orderId);
		$query = $this->db->get('order_items');
		return $query ->row()->pharm_id;

	}



	public function completeOrder($orderId,$order_payment_method,$order_final_bill,$order_pharm_id,$order_timesatmp){
		$this->db->where('orderId',$orderId);
			// $this->db->where('userId',$userId);
		$data = array('order_status' => "pending",
			'order_payment_method' => $order_payment_method,
			'order_final_bill' => $order_final_bill,
			'order_pharm_id' => $order_pharm_id,
			'order_timesatmp' => $order_timesatmp );

		return $this->db->update('orders',$data);

	}

// complete order precription
	public function completeOrderPrecription($orderId,$order_payment_method,$order_status,$order_pharm_id,$order_timesatmp){
		$this->db->where('orderId',$orderId);
			// $this->db->where('userId',$userId);
		$data = array('order_status' => $order_status,
			'order_payment_method' => $order_payment_method,
			// 'order_final_bill' => $order_final_bill,
			'order_pharm_id' => $order_pharm_id,
			'order_timesatmp' => $order_timesatmp );

		return $this->db->update('orders',$data);

	}

    // fetch pending orders original
	// public function fetch_current_order($customerId){
	// 	$this->db->select("*");
	// 	$this->db->from("orders");
	// 	$data = array('customerId' => $customerId, 
	// 		'order_status' => 'pending');
	// 	$this->db->where($data);
	// 	$this->db->order_by('order_timesatmp', 'DESC');

	// 	return $this->db->get();

	// }


	// fetch pending orders new
	public function fetch_current_order($customerId){
		$this->db->select('o.*,p.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$data = array('o.customerId' => $customerId, 
			'o.order_status' => 'pending');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get();

	}

		// fetch pending orders new
	public function fetch_reviewing_presc($customerId){
		$this->db->select('o.*,p.*,q.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$this->db->join('prescription q', 'q.prescription_id=o.prescription_id', 'left');
		$data = array('o.customerId' => $customerId, 
			'o.order_status' => 'reviewing',
			'o.is_prescription' => 'Y');
		$this->db->where($data);
		$this->db->order_by('o.order_timesatmp', 'DESC');	

		return $this->db->get();

	}


			// fetch approved prescriptions new
	public function fetch_approved_presc($customerId){
		$this->db->select('o.*,p.*,q.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$this->db->join('prescription q', 'q.prescription_id=o.prescription_id', 'left');
		$data = array('o.customerId' => $customerId, 
			'o.order_status' => 'approved',
			'o.is_prescription' => 'Y');
		$this->db->where($data);
		$this->db->order_by('o.order_timesatmp', 'DESC');	

		return $this->db->get();

	}


	// update inventory
	public function update_inventory($orderId){

		$sql="CALL update_inventory(?)";
		$data  = array('orderId' => $orderId );
 		return $this->db->query($sql,$data);

	}


// fetch submitted prescription
	public function fetch_submitted_order($customerId){
		$this->db->select('o.*,p.*,q.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$this->db->join('prescription q', 'q.prescription_id=o.prescription_id', 'left');
		$data = array('o.customerId' => $customerId, 
			'o.order_status' => 'submitted',
			'o.is_prescription' => 'Y');
		$this->db->where($data);
		$this->db->order_by('o.order_timesatmp', 'DESC');	

		return $this->db->get();

	}



	 // fetch submitted prescription original
	// public function fetch_submitted_order($customerId){
	// 	$this->db->select("*");
	// 	$this->db->from("orders");
	// 	$data = array('customerId' => $customerId, 
	// 		'order_status' => 'submitted',
	// 		'is_prescription' => 'Y');
	// 	$this->db->where($data);
	// 	$this->db->order_by('order_timesatmp', 'DESC');

	// 	return $this->db->get();

	// }


// get dispatched orders customers original
	
	// public function fetch_dispatched_order($customerId){
	// 	$this->db->select("*");
	// 	$this->db->from("orders");

	// 	$this->db->where('customerId',$customerId);
	// 	$where = '(order_status="dispatched" or order_status = "on the way")';
	// 	$this->db->where($where);
	// 	$this->db->order_by('order_status', 'ASC');
	// 	$this->db->order_by('order_timesatmp', 'DESC');

	// 	return $this->db->get();

	// }

// get dispatched orders customers orders new
	public function fetch_dispatched_order($customerId){
		$this->db->select('o.*,p.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$where = '(o.order_status="dispatched" or o.order_status = "on the way") and o.customerId='.$customerId;
		// $data = array('o.customerId' => $customerId, 
		// 	'o.order_status' => 'pending');
		$this->db->where($where);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get();

	}

	// fetch incoming orders pharm
	public function fetch_incoming_order_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'pending');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get();

	}

// fetch incoming prescription pharmacy
	public function fetch_incoming_presc_pharm($pharm_id){
		$this->db->select('o.*,p.*,q.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$this->db->join('prescription q', 'q.prescription_id=o.prescription_id', 'left');
		$data = array('o.order_pharm_id' => $pharm_id, 
			'o.order_status' => 'submitted',
			'o.is_prescription' => 'Y');
		$this->db->where($data);
		$this->db->order_by('o.order_timesatmp', 'DESC');	

		return $this->db->get();
	}


// fetch all order prescription
	public function fetch_all_order_presc_pharm($orderId){
		$this->db->select('o.*,p.*,q.*,r.*');
		$this->db->from('orders as o'); 	
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$this->db->join('prescription q', 'q.prescription_id=o.prescription_id', 'left');
		$this->db->join('order_prescription r', 'r.orderId=o.orderId', 'left');
		$data = array('o.orderId' => $orderId, 
			'o.is_prescription' => 'Y');
		$this->db->where($data);		
		$this->db->order_by('o.order_timesatmp', 'DESC');	

		return $this->db->get()->row();
	}


	// send quotation
	public function sendQuote($orderId,$order_pharm_id,$prescription_pharm_comment,$order_final_bill,$order_updateTimeStamp,$order_status){
		$this->db->where('orderId',$orderId);
			// $this->db->where('order_pharm_id',$order_pharm_id);
		$data = array('order_status' => $order_status,	
			'order_final_bill'=> $order_final_bill,		
			'order_updateTimeStamp' => $order_updateTimeStamp );

		if($this->db->update('orders',$data)){

			$this->db->where('orderId',$orderId);
			$where=array('prescription_pharm_comment' => $prescription_pharm_comment );

			return $this->db->update('order_prescription',$where);

		}
		



	}



	public function curr_order_count($customerId){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('customerId' => $customerId, 
			'order_status' => 'pending');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}


	// get current prescription count  submit_pres_count
	public function submit_pres_count($customerId){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('customerId' => $customerId, 
			'order_status' => 'submitted');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}


	// get reviewing  prescription count review_pres_count
	public function review_pres_count($customerId){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('customerId' => $customerId, 
			'order_status' => 'reviewing');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}

	// get approved prescription count approve_pres_count
		public function approve_pres_count($customerId){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('customerId' => $customerId, 
			'order_status' => 'approved');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}


	// dispatch_order_count
	public function dispatch_order_count($customerId){
		$this->db->select("*");
		$this->db->from("orders");

		$this->db->where('customerId',$customerId);
		$where = '(order_status="dispatched" or order_status = "on the way")';
		$this->db->where($where);
		$this->db->order_by('order_status', 'ASC');
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}

// get all pharmacies

	public function getAllPharm(){
			// $this->db->where('med_item_id',$med_item_id);
			// $this->db->select("type_name");
		$query= $this->db->get('pharmacy');
		if($query->num_rows() > 0)  
		{  
			return $query;  
		}  


	}


// add to prescription table 
			// insert into order item table
	public function add_prescrip_table($data){
		return $this->db->insert('order_prescription',$data);
	}


//get all prescription	
	public function getAllPrescription(){
			// $this->db->where('med_item_id',$med_item_id);
			// $this->db->select("type_name");
		$query= $this->db->get('prescription');
		if($query->num_rows() > 0)  
		{  
			return $query;  
		}  


	}



//getMyPrescription

	public function getMyPrescription($userId){
		$this->db->where('prescription_uid',$userId);
		$query=$this->db->get('prescription');
		if($query->num_rows() > 0)  
		{  
			return $query;  
		}  

	}


	//auto fill form

	public function getOnePrescription($prescription_id){
		$this->db->where('prescription_id ',$prescription_id );
		$query=$this->db->get('prescription');
		if($query->num_rows() > 0)  
		{  
			return $query;  
		}  

	}
// fetch live data
	function fetch_live_data($query,$pharm_id)
	{
		$this->db->select('m.*,p.pharm_name,p.pharm_id');
		$this->db->from('medicine_items as m');
		$conditionz='m.med_pharmacy_id=p.pharm_id AND p.pharm_id="'.$pharm_id.'"';
		$this->db->join('pharmacy as p', $conditionz);
            // $query = $this->db->query($sql);
	        // $query = $this->db->get();
		if($query != '')
		{
			$this->db->like('m.med_item_name', $query);
			$this->db->or_like('m.med_item_type', $query);
			$this->db->or_like('m.med_item_brand', $query);
			$this->db->or_like('m.med_item_image', $query);
			$this->db->or_like('m.med_comments', $query);
				// $this->db->or_like('p.pharm_name', $query);				
		}
		$this->db->where('p.pharm_id',$pharm_id);
		$this->db->order_by('m.med_item_id', 'DESC');
		return $this->db->get();
	}



	public function curr_order_count_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'pending');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}

	// get current prescription count pharm
	public function curr_pres_count_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'submitted');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}


	// get reviwing prescription count  review_pres_count_pharm
	public function review_pres_count_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'reviewing');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();

	}



	// ongoing_order_count_pharm
	public function ongoing_order_count_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'preparing');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get()->num_rows();


	}

	// fetch_ongoing_presc_pharm

// update order status to preparing
	public function updateOrderStatus($orderId,$order_status,$order_timesatmp){
		$this->db->where('orderId',$orderId);
			// $this->db->where('order_pharm_id',$order_pharm_id);
		$data = array('order_status' => $order_status,
			'order_updateTimeStamp' => $order_timesatmp );
		return $this->db->update('orders',$data);

	}


//finishProcessOrder

	public function finishProcessOrder($orderId,$order_status,$order_timesatmp){
		$this->db->where('orderId',$orderId);
			// $this->db->where('order_pharm_id',$order_pharm_id);
		$data = array('order_status' => $order_status,
			'order_updateTimeStamp' => $order_timesatmp );
		return $this->db->update('orders',$data);

	}

// acceptOrderPackeg	
	public function acceptOrderPackeg($orderId,$order_status,$order_timesatmp){
		$this->db->where('orderId',$orderId);
			// $this->db->where('order_pharm_id',$order_pharm_id);
		$data = array('order_status' => $order_status,
			'order_updateTimeStamp' => $order_timesatmp );
		return $this->db->update('orders',$data);

	}


// fetch_completed_order original
	// public function fetch_completed_order($customerId){
	// 	$this->db->select("*");
	// 	$this->db->from("orders");
	// 	$data = array('customerId' => $customerId, 
	// 		'order_status' => 'completed');
	// 	$this->db->where($data);
	// 	$this->db->order_by('order_timesatmp', 'DESC');

	// 	return $this->db->get();

	// }

// fetch completed new
	public function fetch_completed_order($customerId){
		$this->db->select('o.*,p.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$data = array('o.customerId' => $customerId, 
			'o.order_status' => 'completed');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get();

	}	

	// fetch_completed_order pharmacy
	public function fetch_completed_order_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'completed');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get();

	}

	// fetch_ongoing_order_pharm
	public function fetch_ongoing_order_pharm($pharm_id){
		$this->db->select("*");
		$this->db->from("orders");
		$data = array('order_pharm_id' => $pharm_id, 
			'order_status' => 'preparing');
		$this->db->where($data);
		$this->db->order_by('order_timesatmp', 'DESC');

		return $this->db->get();

	}

// fetch_ongoing_presc_pharm
	public function fetch_ongoing_presc_pharm($pharm_id){
		$this->db->select('o.*,p.*,q.*');
		$this->db->from('orders as o'); 
		$this->db->join('pharmacy p','p.pharm_id=o.order_pharm_id', 'left');
		$this->db->join('prescription q', 'q.prescription_id=o.prescription_id', 'left');
		$data = array('o.order_pharm_id' => $pharm_id, 
			'o.order_status' => 'reviewing',
			'o.is_prescription' => 'Y');
		$this->db->where($data);
		$this->db->order_by('o.order_timesatmp', 'DESC');	

		return $this->db->get();

	}



	public function fetch_all_modal_item_desc($med_item_id){
		// $this->db->select('m.*,p.*');
		// $this->db->from('medicine_items as m'); 
		// $this->db->join('pharmacy p','p.pharm_id=m.med_pharmacy_id', 'left');
		// // $this->db->join('prescription p', 'p.pharm_id=m.med_pharmacy_id ', 'left');
		// $data = array('m.med_item_id' => $med_item_id);
		// $this->db->where($data);
		// $this->db->order_by('o.order_timesatmp', 'DESC');

		$sql="SELECT m.*,p.* from medicine_items m, pharmacy p where m.med_pharmacy_id=p.pharm_id and m.med_item_id=".$med_item_id;	

		return $this->db->query($sql)->row();


	}



	// get all order details
	public function getOrderAll($orderId){
		$this->db->where('orderId', $orderId);
		$query = $this->db->get('orders');
		return $query -> row();

	}

	public function getOrderAllNew($orderId){
		$this->db->select('o.*,p.*');
		$this->db->from('orders as o');
		$conditionz='o.order_pharm_id=p.pharm_id AND o.orderId="'.$orderId.'"';
		$this->db->join('pharmacy as p', $conditionz);
		// $this->db->where('orderId', $orderId);
		$query = $this->db->get();
		return $query -> row();

	}



	public function getPrescriptionId($orderId){
		$this->db->where('orderId', $orderId);
		$query = $this->db->get('order_prescription');
		return $query -> row();

	}

		// get all order details
	public function getOrderAlltoTray($orderId){
		$this->db->where('orderId', $orderId);
		$query = $this->db->get('order_items');
			// return $query->row();
		if($query->num_rows() >0){
			return $query;
		}

	}




	// get pharm name
	public function getPharmAll($order_pharm_id){
		$this->db->where('pharm_id', $order_pharm_id);
		$query = $this->db->get('pharmacy');
		return $query -> row();

	}



}
