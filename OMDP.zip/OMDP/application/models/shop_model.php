	<?php

	class shop_model extends CI_Model{

     //get all items in the database
		// public function getMedicItems(){			
		// 	$query = $this->db->get('medicine_items');
		// 	if($query->num_rows() > 0){
		// 		return $query;
		// 	}
		// }


		// public function ActiveSessionCount(){
		// 	$this->db->where('status','Active');
		// 	$query = $this->db->get('login_session');
		// 	return $query->num_rows();
		// }

		// Insert to Pharmacy - Register Pharmacy
		public function add_inventory_item($data){
			return $this->db->insert('medicine_items',$data);
		}

		// get items for edit
		//send pharmacy data to update form
		public function getItemEdit($med_item_id){
			$this->db->where('med_item_id', $med_item_id);
			$query = $this->db->get('medicine_items');
			return $query -> row();

		}

		// check stock
		public function check_item_stock($med_item_id){
			$this->db->where('med_item_id',$med_item_id);
			$query=$this->db->get('medicine_items');
			return $query->row()->med_stock;
		}


		// Fetch Live Users
		function fetch_live_items($query,$med_pharmacy_id)
		{
			$this->db->select("*");
			$this->db->from("medicine_items");
			$this->db->where('med_pharmacy_id',$med_pharmacy_id);
			if($query != '')
			{
				$this->db->like('med_item_name', $query);
				$this->db->or_like('med_item_brand', $query);
				$this->db->or_like('med_item_type', $query);
				$this->db->or_like('med_item_subtype', $query);
				$this->db->or_like('med_item_spec', $query);
				$this->db->or_like('med_comments', $query);
				// $this->db->or_like('med_comments', $query);				
			}
			
			$this->db->order_by('med_item_name', 'ASC');

			return $this->db->get();
		}


		// Fetch Live precription
		function fetch_live_prescips($query,$prescription_uid)
		{
			$this->db->select("*");
			$this->db->from("prescription");
			$this->db->where('prescription_uid',$prescription_uid);
			if($query != '')
			{
				$this->db->like('prescription_name', $query);
				$this->db->or_like('prescription_comments', $query);
				$this->db->or_like('prescription_urgency', $query);
				$this->db->or_like('prescription_adress1', $query);
				$this->db->or_like('prescription_adress2', $query);
				$this->db->or_like('prescription_adress3', $query);
				// $this->db->or_like('med_comments', $query);				
			}
			
			$this->db->order_by('prescription_createdate', 'DESC');

			return $this->db->get();
		}


		// get item types
		public function getItemType(){
			// $this->db->where('med_item_id',$med_item_id);
			// $this->db->select("type_name");
			$query= $this->db->get('medicine_types');
			if($query->num_rows() > 0)  
			{  
				return $query;  
			}  
			
			
		}


		public function getItemsubType($type_name){
			
		// this is sub_query
			// select pharm_name from pharmacy
// where manager_id in (SELECT userId from users where userEmail='deadpool3@marvel.com');
			$this->db->select('type_id');
			$this->db->from('medicine_types');
			$this->db->where('type_name', $type_name);			
			$sub_query = $this->db->get_compiled_select();
			// $sub_query = $this->db->get_compiled_select();
			$this->db->select('*');
			$this->db->from('medicine_sub_types');
			$this->db->where("type_id IN ($sub_query)", NULL, FALSE);
			// $query_string='select pharm_name from pharmacy where manager_id in (SELECT userId from users where userEmail=\''.$userEmail.'\');'
			$query=$this->db->get();
			
			// return $query ;
			if($query->num_rows() > 0){
				return $query;
			}			

		}


// get all items

		public function getMedicItems(){  
	  // $sql='select m.med_item_id,m.med_item_name,m.med_item_type,m.med_item_brand,p.pharm_name from medicine_items m , pharmacy p where m.med_pharmacy_id=p.pharm_id'  ;  
			$this->db->select('m.*,p.pharm_name');
			$this->db->from('medicine_items as m');
			$this->db->join('pharmacy as p', 'm.med_pharmacy_id=p.pharm_id');
      // $query = $this->db->query($sql);
			$query = $this->db->get();

			if($query->num_rows() > 0){
				return $query;
			}
		}

// get tyoe of items
		public function getTypeofItems($med_item_type){  
	  // $sql='select m.med_item_id,m.med_item_name,m.med_item_type,m.med_item_brand,p.pharm_name from medicine_items m , pharmacy p where m.med_pharmacy_id=p.pharm_id'  ;  
			$this->db->select('m.*,p.pharm_name,p.pharm_id');
			$this->db->from('medicine_items as m');
			$this->db->join('pharmacy as p', 'm.med_pharmacy_id=p.pharm_id');
			$this->db->where('m.med_item_type',$med_item_type);
      // $query = $this->db->query($sql);
			$query = $this->db->get();

			if($query->num_rows() > 0){
				return $query;
			}
		}




		// remove medicine item manager
		// Remove Pharmacy in Admin Module		
		public function removeItemMgr($med_item_id){
			$this->db->where('med_item_id',$med_item_id);
			return $this->db->delete('medicine_items');

		}

		// remove prescription
		public function removePrecription($prescription_id){
			$this->db->where('prescription_id',$prescription_id);
			return $this->db->delete('prescription');

		}



		// view precription select row
		// retrieve user data - User profile
		public function view_prescription($prescription_id){
			$this->db->where('prescription_id',$prescription_id);
			$query = $this->db->get('prescription');
			if($query->num_rows() >0){
				return $query;
			}

		}

		 // submit new values in the user update form
		public function updateItemInfo($med_item_id,$data){
			$this->db->where('med_item_id', $med_item_id);
			return $this->db->update('medicine_items',$data);

		}


		// add prescription
		public function add_prescription($data){
			return $this->db->insert('prescription',$data);
		}


		// insert into order item table
		public function add_order_item($data){
			return $this->db->insert('order_items',$data);
		}

				// insert into order presrcriptoipn item table
		public function add_prescrip_table($data){
			return $this->db->insert('order_prescription',$data);
		}

				// insert into order item table
		public function add_order_table($data){
			return $this->db->insert('orders',$data);
		}


		public function getPharmfromOrder($orderId){
			$this->db->where('orderId', $orderId);
			$query = $this->db->get('order_items');
			if($query->num_rows() >0){
				return $query ->row()->pharm_id;
			}
			// return $query->num_rows();

		}

	}


