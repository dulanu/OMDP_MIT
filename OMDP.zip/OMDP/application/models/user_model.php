	<?php

	class user_model extends CI_Model{


// Insert to Users - Register User
		public function regsiter_user($data){
			return $this->db->insert('users',$data);
		}


// Insert to Pharmacy - Register Pharmacy
		public function regsiter_pharmacy($data){
			return $this->db->insert('pharmacy',$data);
		}

     // Validate User during Login 
		public function can_login($email, $password)  
		{  
			$this->db->where('userEmail', $email);  
			$this->db->where('password', $password);  
			$query = $this->db->get('users');  
           //SELECT * FROM users WHERE username = '$username' AND password = '$password'  
			if($query->num_rows() > 0)  
			{  
				return true;  
			}  
			else  
			{  
				return false;       
			}  
		}

// Fetch data for Live Search
		// function fetch_live_data($query)
		// {
		// 	$this->db->select("*");
		// 	$this->db->from("medicine_items");
		// 	if($query != '')
		// 	{
		// 		$this->db->like('med_item_name', $query);
		// 		$this->db->or_like('med_item_type', $query);
		// 		$this->db->or_like('med_item_brand', $query);
		// 		$this->db->or_like('med_item_image', $query);
		// 		$this->db->or_like('med_comments', $query);				
		// 	}
		// 	$this->db->order_by('med_item_id', 'DESC');
		// 	return $this->db->get();
		// }


// Fetch Live Users
		function fetch_live_user($query)
		{
			$this->db->select("*");
			$this->db->from("users");
			if($query != '')
			{
				$this->db->like('fName', $query);
				$this->db->or_like('lName', $query);
				$this->db->or_like('userEmail', $query);
				$this->db->or_like('userType', $query);
				// $this->db->or_like('med_comments', $query);				
			}
			$this->db->order_by('fName', 'ASC');
			return $this->db->get();
		}

// Fetch Live Pharmacy
		// Fetch data for Live Search
		function fetch_live_pharm($query)
		{
			$this->db->select("*");
			$this->db->from("pharmacy");
			if($query != '')
			{
				$this->db->like('pharm_name', $query);
				$this->db->or_like('pharm_email', $query);
				$this->db->or_like('pharm_phone', $query);
				$this->db->or_like('address_line1', $query);
				$this->db->or_like('address_line2', $query);
				$this->db->or_like('address_line3', $query);				
			}
			$this->db->order_by('pharm_name', 'ASC');
			return $this->db->get();
		}

// fetch live meds new
		function fetch_live_data($query)
		{
			$this->db->select('m.*,p.pharm_name,p.pharm_id');
			$this->db->from('medicine_items as m');
			$this->db->join('pharmacy as p', 'm.med_pharmacy_id=p.pharm_id');
            // $query = $this->db->query($sql);
	        // $query = $this->db->get();
			if($query != '')
			{
				$this->db->like('m.med_item_name', $query);
				$this->db->or_like('m.med_item_type', $query);
				$this->db->or_like('m.med_item_brand', $query);
				$this->db->or_like('m.med_item_image', $query);
				$this->db->or_like('m.med_comments', $query);
				$this->db->or_like('p.pharm_name', $query);				
			}
			$this->db->order_by('m.med_item_id', 'DESC');
			return $this->db->get();
		}


//get all user details
		public function getUserAll($userEmail){
			$this->db->where('userEmail', $userEmail);
			$query = $this->db->get('users');
			return $query->row();

		} 

// get pharmacy of user type cashier or manager
		public function getManagerPharm($userEmail){
			
		// this is sub_query
			// select pharm_name from pharmacy
// where manager_id in (SELECT userId from users where userEmail='deadpool3@marvel.com');
			$this->db->select('userId');
			$this->db->from('users');
			$this->db->where('userEmail', $userEmail);			
			$sub_query = $this->db->get_compiled_select();
			// $sub_query = $this->db->get_compiled_select();
			$this->db->select('*');
			$this->db->from('pharmacy');
			$this->db->where("manager_id IN ($sub_query)", NULL, FALSE);
			// $query_string='select pharm_name from pharmacy where manager_id in (SELECT userId from users where userEmail=\''.$userEmail.'\');'
			$query=$this->db->get();
			
			// return $query->row();
			if($query->num_rows() > 0){
				return $query->row();
			}			

		}



// get cashier email id
		// get pharmacy of user type cashier or manager
		public function getCashierPharm($userEmail){
			
		// this is sub_query
			// select pharm_name from pharmacy
// where manager_id in (SELECT userId from users where userEmail='deadpool3@marvel.com');
			$this->db->select('user_pharmId');
			$this->db->from('users');
			$this->db->where('userEmail', $userEmail);			
			$sub_query = $this->db->get_compiled_select();
			// $sub_query = $this->db->get_compiled_select();
			$this->db->select('*');
			$this->db->from('pharmacy');
			$this->db->where("pharm_id IN ($sub_query)", NULL, FALSE);
			// $query_string='select pharm_name from pharmacy where manager_id in (SELECT userId from users where userEmail=\''.$userEmail.'\');'
			$query=$this->db->get();
			
			// return $query->row();
			if($query->num_rows() > 0){
				return $query->row();
			}			

		}


// get first name
		public function getFName($userEmail){
			$this->db->where('userEmail', $userEmail);
			$query = $this->db->get('users');
			return $query->row()->fName;

		} 

// get userid
		public function getUid($userEmail){
			$this->db->where('userEmail', $userEmail);
			$query = $this->db->get('users');
			return $query->row()->userId;

		} 

// get profile pic to customer homepage
		public function getProPic($userEmail){
			$this->db->where('userEmail', $userEmail);
			$query = $this->db->get('users');
			return $query->row()->profile;

		} 


//send pharmacy data to update form
		public function getPharmEdit($pharm_id){
			$this->db->where('pharm_id', $pharm_id);
			$query = $this->db->get('pharmacy');
			return $query -> row();

		}



//send user data for update from admin module
		public function getUserEdit($userId){
			$this->db->where('userId', $userId);
			$query = $this->db->get('users');
			return $query -> row();

		}



// submit new values in the pharmacy update form 
		public function updatePharmInfo($pharm_id,$data){
			$this->db->where('pharm_id', $pharm_id);
			return $this->db->update('pharmacy',$data);

		}

 // submit new values in the user update form
		public function updateUserInfo($userId,$data){
			$this->db->where('userId', $userId);
			return $this->db->update('users',$data);

		}


// when login insert into login session
		public function createSession($data){
			return $this->db->insert('login_session',$data);
		}

// update session status as logout
		public function completeLogOut($sessionId,$userId,$logoutTime){
			$this->db->where('sessionId',$sessionId);
			$this->db->where('userId',$userId);
			$data = array('status' => "logout",
				'logoutTime' => $logoutTime );
			return $this->db->update('login_session',$data);

		}

// retrieve user data - User profile
		public function view_profile($userId){
			$this->db->where('userId',$userId);
			$query = $this->db->get('users');
			if($query->num_rows() >0){
				return $query;
			}

		}

// Remove User admin module		
		public function removeUserAdmin($userId){
			$this->db->where('userId',$userId);
			return $this->db->delete('users');

		}

// Remove Pharmacy in Admin Module		
		public function removePharmAdmin($pharm_id){
			$this->db->where('pharm_id',$pharm_id);
			return $this->db->delete('pharmacy');

		}

// uplod Image path
		public function uploadImage($data){
			return $this->db->insert('user_mages',$data);
		}

// get all medicine items
		public function getMedicItems(){  
	  // $sql='select m.med_item_id,m.med_item_name,m.med_item_type,m.med_item_brand,p.pharm_name from medicine_items m , pharmacy p where m.med_pharmacy_id=p.pharm_id'  ;  
			$this->db->select('m.*,p.pharm_name');
			$this->db->from('medicine_items as m');
			$this->db->join('pharmacy as p', 'm.med_pharmacy_id=p.pharm_id');
      // $query = $this->db->query($sql);
			$query = $this->db->get();

			if($query->num_rows() > 0){
				return $query;
			}
		}


	}



	?>
